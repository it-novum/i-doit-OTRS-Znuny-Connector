<?PHP

/**
 * i-doit OTRSSYNC isys_module_otrssync__autoload
 *
 * @package     Modules
 * @subpackage  OTRSSYNC
 * @author      IT-Novum
 * @copyright   IT-Novum GmbH
 */
class isys_module_otrssync__autoload extends isys_module_manager_autoload
{
    /**
     * Method initialise autoloader and tries to load classes by name automatically
     *
     * @param   String classname
     * @return  Boolean true or false
     * @author  IT-NOVUM
     */
    public static function init($p_classname)
    {
        //autload the mail class from libraries
        if (strpos($p_classname, 'isys_library_mail') !== 0) {
            $res = explode("\\",$p_classname);
            $p_classname = $res[count($res)-1];
            $l_path = DS . 'var'. DS . 'www' . DS . 'html'. DS . 'idoit'. DS . 'src' . DS . 'classes' . DS . 'libraries' . DS . $p_classname . '.class.php';
        }
        if ($p_classname === 'isys_auth_otrssync')
        {
            $l_path = '/src/classes/modules/otrssync/auth/isys_auth_otrssync.class.php';
        } // if
        //try to autoload all other classes given
        if (!empty($l_path)) {
            if (parent::include_file($l_path)) {
                isys_caching::factory('autoload')->set($p_classname, $l_path);
                return true;
            }
        }
        return false;
    }
}
