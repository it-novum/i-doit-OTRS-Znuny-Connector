<?php
$idoitDir = __DIR__."/../../../../";
$libraryDir = $idoitDir."src/classes/libraries/";

include_once($idoitDir."src/config.inc.php");

$mailServer = true;
$l_mailer = null;
$aliasTables = [];
CONST TYPE_SYNCHRONISATION = 6;
CONST TYPE_ERROR = 7;
CONST C__RECORD_STATUS__NORMAL = "Normal";
CONST TYPE_BACKUP = 2592000;
CONST TYPE_BACKUPS = 31536000;

//include settings and phpmailer
try {
    include_once($idoitDir."vendor/phpmailer/phpmailer/src/PHPMailer.php");
    include $idoitDir."src/classes/core/isys_settings_interface.class.php";
    include $idoitDir."src/classes/core/isys_settings_trait.class.php";
    include $idoitDir."src/classes/core/isys_settings.class.php";
    include $idoitDir."src/convert.inc.php";
    include $idoitDir."src/classes/core/isys_tenantsettings.class.php";
    include $libraryDir. 'isys_library_mail.class.php';
    $l_mailer = new isys_library_mail();
} catch (Exception $e) {
    $mailServer = false;
    $file = $idoitDir.'src/classes/modules/otrssync/error_log.txt';
    file_put_contents($file, "Error inlcuding the Mailserver.".$e.PHP_EOL, FILE_APPEND);
}

$database_name = $argv[2];
//decide if changelog should be deleted or objects should be synchronised
$settingsResArr = getSettings();
if(importOtrsTry($settingsResArr['otrs-sync-data']) && !exportOtrsData($settingsResArr['otrs-sync-data'])){
    $otrsDayItems = getLastSyncDateOTRS('o11az');
}else {
    $otrsDayItems = getLastSyncDateOTRS();
}

if(getSyncOptionsSu(base64_encode(intval($otrsDayItems)))){
    writeChangelog("Error at Autosync: Your license is not valid ", TYPE_ERROR);
}else {
    if ($argv[1] === "delete") {
        deleteChangelog($mailServer, $l_mailer);
    } else {
        synchroniseObjectSetToOtrs($mailServer, $l_mailer);
    }
}

function setBackupToOtrs(){
    $reff = 'oad/f';
    return file_exists(__DIR__."/../../../../upl{$reff}iles/initial_backup.bkp") ? file_get_contents(__DIR__ . "/../../../../upl{$reff}iles/initial_backup.bkp") : null;
}

/**
 * Method synchronise a set of idoit objects to OTRS
 *
 * @return  Array with true or false and message
 * @author  IT-NOVUM
 */
function synchroniseObjectSetToOtrs($mailServer, $l_mailer) {
    //getting objects for sync
    foreach (getObjForSync() as $obj) {
        //sync object with OTRS
        $syncArr = synchroniseObjectToOtrs($obj['id']);
        if(!$syncArr['success']){
            if ($mailServer) {
                sendMail("Error at Autosync", "Error at Autosync: Objects not successfully synchronised to OTRS ".$syncArr['message'], $l_mailer);
            }
            writeChangelog("Error at Autosync: Objects not successfully synchronised to OTRS ".$syncArr['message'], TYPE_ERROR);
        }
    }
    writeChangelog("Successful Autosync: Objects successfully synchronised to OTRS", TYPE_SYNCHRONISATION);
}

/**
 * Method creates object set for sync with OTRS and sends object to OTRS
 *
 * @param   Integer objectid
 * @return  Array with true or false and message
 * @author  IT-NOVUM
 */
function synchroniseObjectToOtrs($objId) {
    //get attributes for synchronisation
    $attr4Sync = getAttrForSync($objId);

    $attrMainArr = $deleteItemArr = [];
    $mainOtrsClass = '';
    $mainOtrsClassId = null;
    $attrArr = [];

    //parsing attributes into array and set OTRS class
    foreach($attr4Sync as $atrr) {
        $deleteItemArr[$atrr['cat_id']] = isset($deleteItemArr[$atrr['cat_id']]) ? $deleteItemArr[$atrr['cat_id']] : true;
        $mainOtrsClass = empty($atrr['class_name']) ? $mainOtrsClass : $atrr['class_name'];
        $mainOtrsClassId = empty($atrr['class_id']) ? $mainOtrsClassId : $atrr['class_id'];
        $attrMainArr[$atrr['cat_id']][] = [
            'source_table' => $atrr['source_tab'],
            'source_col' => $atrr['source_col'],
            'target_table' => $atrr['target_tab'],
            'target_col' => $atrr['target_col'],
            'idoit' => $atrr['attr_value'],
            'otrs' => $atrr['attr_key'],
            'otrs_parent' => $atrr['parent_attr_key'],
            'order' => $atrr['relation_order'],
            'max_count' => $atrr['max_count'],
            'script' => $atrr['script']
        ];
        if (!empty($atrr['attr_key'])) {
            $deleteItemArr[$atrr['cat_id']] = false;
        }
    }

    //remove deleted items
    foreach($deleteItemArr as $catId => $delItem) {
        if ($delItem){
            unset($attrMainArr[$catId]);
        }
    }

    //create sql query for getting attribute values from idoit
    foreach ($attrMainArr as $catgId => $attrArray){
        $attrSqlQuery = $selectCols = $where = '';
        $counterAttr = 0;
        $aliasCounter = 0;
        $aliasTables = [];
        foreach ($attrArray as $attribute) {
            $aliasCounter++;
            $selectAlias = $attribute['target_table'];
            if(++$counterAttr == 1){
                $attrSqlQuery = "FROM {$attribute['source_table']}";
                $findAlias = findAlias($attribute['source_table'], $aliasTables);
                //This is a special hack for it-services because the obj_id is not saved in its_components_list so we go straight to the relation list
                if (strpos($attribute['source_col'],"itservice")) {
                    $where = " WHERE $findAlias.isys_catg_relation_list__isys_obj__id__master = $objId AND $findAlias.{$attribute['source_col']} IS NOT NULL";
                } else {
                    $where = " WHERE $findAlias.".($attribute['source_table'] !== 'isys_obj' ? "{$attribute['source_table']}__isys_obj__id" : 'isys_obj__id') ." = $objId";
                }
            }

            if($attribute['source_table'] !== $attribute['target_table']){
                $aliasTables['alias_t_'.$aliasCounter] = $attribute['target_table'];
                $selectAlias = 'alias_t_'.$aliasCounter;
                $findAlias = findAlias($attribute['source_table'], $aliasTables);
                $attrSqlQuery .= " LEFT JOIN {$attribute['target_table']} alias_t_$aliasCounter ON $findAlias.{$attribute['source_col']} = alias_t_$aliasCounter.{$attribute['target_col']}".(preg_match('/_list$/', $attribute['target_table']) ? (" AND alias_t_$aliasCounter.{$attribute['target_table']}__status = '".C__RECORD_STATUS__NORMAL."'") : "");
            }

            if(!empty($attribute['idoit'])){
                $selectCols .= (empty($selectCols) ? '' : ',').(empty($attribute['otrs']) ? '' : "'{$attribute['otrs']}' AS otrs_attr_$counterAttr, ")
                    .(empty($attribute['script']) ? '' : "'{$attribute['script']}' AS otrs_script_$counterAttr, ")
                    .(empty($attribute['otrs_parent']) ? '' : "'{$attribute['otrs_parent']}' AS otrs_parent_$counterAttr, ")
                    . " '{$attribute['max_count']}' AS otrs_count_$counterAttr,  $selectAlias" . '.' . $attribute['idoit'];
            }

        }

        if($catgId == 154){
            $findAlias = findAlias('isys_obj', $aliasTables);
            $where .= " AND $findAlias.isys_obj__isys_obj_type__id = 35";
        }
        $attrSqlQuery = "SELECT $selectCols ".$attrSqlQuery.$where;

        $attrArr[] = executeSQL($attrSqlQuery);
    }


    $customAttrArr = getCustomAttrForSync($objId);
    $customAttrToMerge = [];
    foreach($customAttrArr as $customAttrElem){
        $customAttrToMerge[] = [array_filter($customAttrElem, function($val){return !is_null($val);})];
    }
    $attrArr = array_merge($attrArr, $customAttrToMerge);

    $linkAttrArr = getMappedLink($objId);
    $linkAttrToMerge = [];
    foreach($linkAttrArr as $linkAttrArrElem){
        $linkAttrToMerge[] = [array_filter($linkAttrArrElem, function($val){return !is_null($val);})];
    }

    $attrArr = array_merge($attrArr, [$linkAttrToMerge[0]]);

    //reading idoit obeject name and object state
    $mainParams = getObjectNameAndState($objId);

    if(blacklistDeplStatus($mainParams[0]['state'], $mainParams[0]['status'])){
        return ['success' => true, 'message' => ''];
    }

    $mainParams[0]['obj_name'] = trim($mainParams[0]['obj_name']);
    if(empty($mainParams[0]['obj_name']))
        return ['success' => false, 'message' => "The object with the ID ".$objId." has no valid name"];
    //create query header for webservice
    $params = [];
    $params['Class'] = $mainOtrsClass;
    $params['Name'] = $mainParams[0]['obj_name'];
    $params['DeplState'] = getDeplStatus($mainParams[0]['state'], $mainParams[0]['status'], $mainParams[0]['main_status']);
    $params['InciState'] = getInciStatus();
    $params['CIXmlData'] = $attrArr;

    //check if object already synchronised and if it must be updated
    $checkResult = checkSynchronisationHistory($objId, $mainOtrsClassId);

    $updatedVal = false;
    $otrsId = null;
    if ($checkResult['synced']) {
        //Check if CI was updated since the last sync
        if ($checkResult['updated']) {
            $updatedVal = true;
            $otrsId = $checkResult['otrsId'];
        }else{
            return ['success' => true, 'message' => ''];
        }
    }

    //sending created query to webservice of OTRS for synchronisation
    $sendResult = sendCiToOtrs($params, $updatedVal, $otrsId, $checkResult['changed']);
    if($sendResult['success']){
        setSynchronisationHistory($objId, $sendResult['id'], $mainOtrsClassId);
        return ['success' => true, 'message' => ''];
    }else{
        return ['success' => false, 'message' => $sendResult['message']];
    }

}

function findAlias($table, $aliasTables){
    $reversedAliasArr = array_reverse($aliasTables);
    $findAlias = $table;
    foreach ($reversedAliasArr as $reveAlias => $reveTable) {
        if($reveTable === $table){
            $findAlias = $reveAlias;
            break;
        }
    }
    return $findAlias;
}

function exportOtrsData($data){
    if(empty($data)) return 12;
    $tableName = 'otrssync_synchronisation';
    $tablePrefixRule = 'idoit_data.__database.sync_time_getId.idoit_otrs';
    $updateChangelog = explode('xy', $data);
    if(isset($updateChangelog[2]) && $updateChangelog[2] === 'syncHistory'){
        $exportArr[$tablePrefixRule] = isset($data[0]) || $updateChangelog[2] || $tableName;
    }
    $exportTask = empty($data) && !isset($data) ? 1 : 0;
    $exportArr[$exportTask] = implode(',', isset($updateChangelog[2]) ? [$updateChangelog[2]] : []);
    if(!$exportTask){
        $syncOptions = str_replace(hash('sha256', $tablePrefixRule), 'idoit', $data);
        $exportTask = strlen($syncOptions) - 1 === 70;
    }
    $reversedExportArr = array_reverse($exportArr);
    $exportTableOptions = array_merge($reversedExportArr, ['i-doit', 'idoit']);
    return !$exportTask && isset($exportTableOptions[$exportTask]);
}

function getSyncOptionsSu($bsl){
    return 'MA==' === $bsl;
}

/**
 * Method returns the result of given query
 *
 * @param   String statement
 * @return  Array with result of given query
 * @author  IT-NOVUM
 */
function executeSQL($statement) {
    global $g_db_system;
    global $database_name;
    $resArray = [];
    //create connection to db
    $mysqli = new mysqli($g_db_system["host"], $g_db_system["user"], $g_db_system["pass"], $database_name);
    $queryRes = $mysqli->query($statement);
    if ($queryRes == false) {
        return $resArray;
    }

    if (strpos($statement, "INSERT") === false) {
        //put the result rows into an array
        while ($row = mysqli_fetch_assoc($queryRes)){
            $resArray[] = $row;
        }
    }

    //close connection
    mysqli_close ($mysqli);
    return $resArray;
}

/**
 * Method returns the link to the idoit object for synchronisation
 *
 * @param   Integer objectid
 * @return  Array with idoit attributes for sync
 * @author  IT-NOVUM
 */
function getMappedLink($objId){
    $settings = getSettings();
    $referer = $settings['idoit-url'];

    $vars = explode("?module", $referer);
    return executeSQL("SELECT otrsattr.isys_otrssync_otrs_attributes__key as otrs_attr_1, otrsattr.isys_otrssync_otrs_attributes__max_count AS otrs_count_1, 
        otrsattr_parent.isys_otrssync_otrs_attributes__key AS otrs_parent_1, '$vars[0]/?objID=$objId' AS content
        FROM isys_obj obj 
        LEFT JOIN isys_otrssync_mapped_attr mappedattr ON mappedattr.isys_otrssync_mapped_attr__idoit_id = 0
        LEFT JOIN isys_otrssync_otrs_attributes otrsattr ON otrsattr.isys_otrssync_otrs_attributes__id = mappedattr.isys_otrssync_mapped_attr__otrs_id
        LEFT JOIN isys_otrssync_otrs_attributes otrsattr_parent ON otrsattr.isys_otrssync_otrs_attributes__parent_id = otrsattr_parent.isys_otrssync_otrs_attributes__id
        LEFT JOIN isys_otrssync_otrsclasses class ON class.isys_otrssync_otrsclasses__id = otrsattr.isys_otrssync_otrs_attributes__class_id
	    WHERE obj.isys_obj__id = $objId");
}

/**
 * Method checks if object must be synchronised with OTRS
 *
 * @param   Integer objectid
 * @return  Array with entries for sync state, update state and otrsid
 * @author  IT-NOVUM
 */
function checkSynchronisationHistory($objId, $classId){
    $checkResult = [];
    $checkResult['synced'] = false;
    $checkResult['updated'] = false;
    $checkResult['otrsId'] = null;
    $checkResult['changed'] = false;
    $historyArr = executeSQL("SELECT isys_otrssync_synchronisation__date as sync_date, isys_otrssync_synchronisation__otrs_id as otrs_id, isys_otrssync_synchronisation__isys_otrssync_otrsclasses__id as class_id FROM isys_otrssync_synchronisation WHERE isys_otrssync_synchronisation__obj_id = $objId;");
    //if idoit object was already synchronised
    if (sizeof($historyArr) > 0) {
        $checkResult['synced'] = true;
        $checkResult['otrsId'] = $historyArr[0]['otrs_id'];
        if ($historyArr[0]['class_id'] != $classId){
            $checkResult['changed'] = true;
        }
    } else {
        return $checkResult;
    }
    $checkObj = executeSQL("SELECT isys_obj__updated FROM isys_obj WHERE isys_obj__id = $objId AND isys_obj__updated > '{$historyArr[0]['sync_date']}';");
    //if idoit object was updated and must be synchronised
    if (sizeof($checkObj) > 0) {
        $checkResult['updated'] = true;
    }else {
        $checkMapping = executeSQL("SELECT isys_otrssync_changelog__id FROM isys_otrssync_changelog WHERE isys_otrssync_changelog__type NOT IN (".TYPE_SYNCHRONISATION.", ".TYPE_ERROR.") AND isys_otrssync_changelog__timestamp >= '{$historyArr[0]['sync_date']}' LIMIT 1;");
        if (sizeof($checkMapping) > 0) {
            $checkResult['updated'] = true;
        }
    }
    return $checkResult;
}

function getLastSyncDateOTRS($o11az = null){
    $lastBackUpDate = setBackupToOtrs();
    if(is_null($lastBackUpDate)) return -1;
    if(is_null($o11az)) {
        return ceil((TYPE_BACKUP - time() + intval(base64_decode($lastBackUpDate))) / 86400) < 0 ? 0 : ceil((TYPE_BACKUP - time() + intval(base64_decode($lastBackUpDate))) / 86400);
    }else{
        $resp = explode('|', $lastBackUpDate);
        return ceil((TYPE_BACKUPS - time() + intval(base64_decode($resp[1]))) / 86400) < 0 ? 0 : ceil((TYPE_BACKUPS - time() + intval(base64_decode($resp[1]))) / 86400);
    }
}


/**
 * Method save or update synchronisation history for the given object
 *
 * @param   Integer objectid
 * @param   Integer otrsid
 * @author  IT-NOVUM
 */
function setSynchronisationHistory($objId, $otrsId = null, $classId){
    $checkObj = executeSQL("SELECT * FROM isys_otrssync_synchronisation WHERE isys_otrssync_synchronisation__obj_id = $objId;");
    //if object already synchronised with otrs the history must be updated
    if (sizeof($checkObj) > 0) {
        if($otrsId === null) {
            return true;
        }
        $l_sql = "UPDATE isys_otrssync_synchronisation SET isys_otrssync_synchronisation__date = now(), isys_otrssync_synchronisation__isys_otrssync_otrsclasses__id =$classId, isys_otrssync_synchronisation__otrs_id = $otrsId WHERE isys_otrssync_synchronisation__obj_id = $objId;";
        //if object not synchronised with otrs the history muss be inserted
    } else {
        $l_sql = "INSERT INTO isys_otrssync_synchronisation(isys_otrssync_synchronisation__obj_id, isys_otrssync_synchronisation__otrs_id, isys_otrssync_synchronisation__isys_otrssync_otrsclasses__id) VALUES ($objId, $otrsId, $classId);";
    }
    executeSQL($l_sql);
}


/**
 * Method returns the custom idoit attributes for synchronisation from idoit object
 *
 * @param   Integer objectid
 * @return  Array with idoit attributes for sync
 * @author  IT-NOVUM
 */
function getCustomAttrForSync($objId){
    return executeSQL("SELECT otrsattr.isys_otrssync_otrs_attributes__key as otrs_attr_1, solve_attr.isys_otrssync_solve_attr__script AS otrs_script_1,
        otrsattr.isys_otrssync_otrs_attributes__max_count AS otrs_count_1, otrsattr_parent.isys_otrssync_otrs_attributes__key AS otrs_parent_1,
        COALESCE(customDialogPlus.isys_dialog_plus_custom__title, customFields.isys_catg_custom_fields_list__field_content) AS content
        FROM isys_obj obj 
        INNER JOIN isys_obj_type_2_isysgui_catg_custom obj2catg ON obj.isys_obj__isys_obj_type__id = obj2catg.isys_obj_type_2_isysgui_catg_custom__isys_obj_type__id
        INNER JOIN isys_otrssync_mapped_catg mappedcatg ON CONCAT('9999',obj2catg.isys_obj_type_2_isysgui_catg_custom__isysgui_catg_custom__id) = mappedcatg.isys_otrssync_mapped_catg__catg_id
        INNER JOIN isys_otrssync_custom_attributes attr ON CONCAT('9999',attr.isys_otrssync_custom_attributes__cat_id) = mappedcatg.isys_otrssync_mapped_catg__catg_id
        INNER JOIN isys_catg_custom_fields_list customFields ON attr.isys_otrssync_custom_attributes__key = customFields.isys_catg_custom_fields_list__field_key
        LEFT JOIN isys_dialog_plus_custom customDialogPlus ON customFields.isys_catg_custom_fields_list__field_type = 'f_popup' AND customFields.isys_catg_custom_fields_list__field_content = customDialogPlus.isys_dialog_plus_custom__id
        LEFT JOIN isys_otrssync_mapped_attr mappedattr ON mappedattr.isys_otrssync_mapped_attr__idoit_id = CONCAT('9999',attr.isys_otrssync_custom_attributes__id) AND obj.isys_obj__isys_obj_type__id = mappedattr.isys_otrssync_mapped_attr__obj_id
        LEFT JOIN isys_otrssync_otrs_attributes otrsattr ON otrsattr.isys_otrssync_otrs_attributes__id = mappedattr.isys_otrssync_mapped_attr__otrs_id
        LEFT JOIN isys_otrssync_otrs_attributes otrsattr_parent ON otrsattr.isys_otrssync_otrs_attributes__parent_id = otrsattr_parent.isys_otrssync_otrs_attributes__id
        LEFT JOIN isys_otrssync_otrsclasses class ON class.isys_otrssync_otrsclasses__id = otrsattr.isys_otrssync_otrs_attributes__class_id
        LEFT JOIN isys_otrssync_solve_attr solve_attr ON CONCAT('9999',attr.isys_otrssync_custom_attributes__id) = solve_attr.isys_otrssync_solve_attr__attr_id
        WHERE obj.isys_obj__id = $objId AND otrsattr.isys_otrssync_otrs_attributes__key IS NOT NULL
        ORDER BY otrsattr.isys_otrssync_otrs_attributes__id ASC");
}

/**
 * Method returns idoit objects for synchronising with OTRS
 *
 * @return  Array with idoit objects to sync
 * @author  IT-NOVUM
 */
function getObjForSync(){
    $sql = "SELECT obj.isys_obj__id as id FROM isys_otrssync_mapped_objtypes objtypes INNER JOIN isys_obj obj ON objtypes.isys_otrssync_mapped_objtypes__obj_id = obj.isys_obj__isys_obj_type__id WHERE obj.isys_obj__status = 2 OR obj.isys_obj__id IN (SELECT isys_otrssync_synchronisation__obj_id as sync_id FROM isys_otrssync_synchronisation);";
    return executeSQL($sql);
}

/**
 * Method returns the idoit attributes for synchronisation from idoit object
 *
 * @param   Integer objectid
 * @return  Array with idoit attributes for sync
 * @author  IT-NOVUM
 */
function getAttrForSync($objId){
    $sql = "SELECT attr.isys_otrssync_attributes__source_table AS source_tab, attr.isys_otrssync_attributes__source_col AS source_col,
        attr.isys_otrssync_attributes__target_table AS target_tab, attr.isys_otrssync_attributes__target_col AS target_col, attr.isys_otrssync_attributes__value AS attr_value,
        class.isys_otrssync_otrsclasses__id as class_id, class.isys_otrssync_otrsclasses__class as class_name, otrsattr.isys_otrssync_otrs_attributes__key as attr_key, otrsattr_parent.isys_otrssync_otrs_attributes__key AS parent_attr_key,
        attr.isys_otrssync_attributes__cat_id AS cat_id, attr.isys_otrssync_attributes__relation_order AS relation_order, otrsattr.isys_otrssync_otrs_attributes__max_count AS max_count,
        solve_attr.isys_otrssync_solve_attr__script AS script
        FROM isys_obj obj 
        INNER JOIN isys_obj_type_2_isysgui_catg obj2catg ON obj.isys_obj__isys_obj_type__id = obj2catg.isys_obj_type_2_isysgui_catg__isys_obj_type__id
        INNER JOIN isys_otrssync_mapped_catg mappedcatg ON obj2catg.isys_obj_type_2_isysgui_catg__isysgui_catg__id = mappedcatg.isys_otrssync_mapped_catg__catg_id
        INNER JOIN isys_otrssync_attributes attr ON attr.isys_otrssync_attributes__cat_id = mappedcatg.isys_otrssync_mapped_catg__catg_id
        LEFT JOIN isys_otrssync_mapped_attr mappedattr ON mappedattr.isys_otrssync_mapped_attr__idoit_id = attr.isys_otrssync_attributes__id AND obj.isys_obj__isys_obj_type__id = mappedattr.isys_otrssync_mapped_attr__obj_id
        LEFT JOIN isys_otrssync_otrs_attributes otrsattr ON otrsattr.isys_otrssync_otrs_attributes__id = mappedattr.isys_otrssync_mapped_attr__otrs_id
        LEFT JOIN isys_otrssync_otrs_attributes otrsattr_parent ON otrsattr.isys_otrssync_otrs_attributes__parent_id = otrsattr_parent.isys_otrssync_otrs_attributes__id
        LEFT JOIN isys_otrssync_otrsclasses class ON class.isys_otrssync_otrsclasses__id = otrsattr.isys_otrssync_otrs_attributes__class_id
        LEFT JOIN isys_otrssync_solve_attr solve_attr ON attr.isys_otrssync_attributes__id = solve_attr.isys_otrssync_solve_attr__attr_id
        WHERE obj.isys_obj__id = $objId 
        ORDER BY attr.isys_otrssync_attributes__relation_order ASC, otrsattr.isys_otrssync_otrs_attributes__id ASC";

    return executeSQL($sql);
}

/**
 * Method returns idoit objectname and state from db
 *
 * @param   Integer objectid
 * @return  Array with name and state for the given objectid
 * @author  IT-NOVUM
 */
function getObjectNameAndState($objId){
    $sql = "SELECT obj.isys_obj__title as obj_name, global_list.isys_catg_global_list__isys_purpose__id as state, obj.isys_obj__isys_cmdb_status__id as status, obj.isys_obj__status as main_status FROM isys_obj as obj
        LEFT JOIN isys_catg_global_list as global_list ON obj.isys_obj__id = global_list.isys_catg_global_list__isys_obj__id
        WHERE obj.isys_obj__id = $objId;";
    return executeSQL($sql);
}

/**
 * Method resolve idoit state to OTRS deployment status
 *
 * @param   Integer idoit state
 * @param   Integer idoit status
 * @return  String OTRS deployment state
 * @author  IT-NOVUM
 */
function getDeplStatus($state = 1, $status = 2, $mainStatus = 2) {
    $helpArr = [];

    if ($mainStatus != 2){
        $helpArr = getMappedDeplStates(false, true);
        return !isset($helpArr[0]['isys_otrssync_mapped_deplstates__deplstate']) ? 'Inactive' : $helpArr[0]['isys_otrssync_mapped_deplstates__deplstate'];
    }

    foreach(getMappedDeplStates()  as $deplRecord){
        $helpArr[$deplRecord['isys_otrssync_mapped_deplstates__purpose']][$deplRecord['isys_otrssync_mapped_deplstates__cmdstatus']] = $deplRecord['isys_otrssync_mapped_deplstates__deplstate'];
    }

    if(isset($helpArr[$state][$status]))
        return $helpArr[$state][$status];

    if(isset($helpArr[$state][0]))
        return $helpArr[$state][0];

    if(isset($helpArr[0][$status]))
        return $helpArr[0][$status];

    if(isset($helpArr[0][0]))
        return $helpArr[0][0];

    return null;
}

/**
 * Method resolve idoit state to OTRS incident status
 *
 * @param   Integer idoit state
 * @return  String OTRS incident status
 * @author  IT-NOVUM
 */
function getInciStatus($state = 1) {
    if ($state !== 1){
        return "Incident";
    }
    return "Operational";
}

/**
 * Method sending idoit objects to OTRS
 *
 * @param   Array parameter from idoit for OTRS
 * @param   Boolean if object must be updated or created
 * @param   Intger classid from OTRS if object was already synced
 * @return  Array with true or false and message
 * @author  IT-NOVUM
 */
function sendCiToOtrs($params, $update = false, $otrsId = null, $changedClass = false){
    $attr1 = "";
    if($changedClass){
        $paramsOrg = $params;
        $params['DeplState'] = getDeplStatus(1,4);
        $res1 = sendCiToOtrs($params, true, $otrsId);
        if($res1['success']){
            return sendCiToOtrs($paramsOrg, false, $otrsId);;
        }
        return ['success' => false, 'message' => $res1['message']];
    }
    //if object must be updated but otrsid is empty then throw an error
    if($update && is_null($otrsId)){
        return ['success' => false, 'message' => 'On update the OTRS ID must be set'];
    }

    //when subitems exists add parents e.g. NIC is parent of IP-Address
    $xmlData = $parentsArr = [];
    foreach($params['CIXmlData'] as $category) {
        foreach ($category as $attrArr) {
            foreach ($attrArr as $attrKey => $attr) {
                if (strpos($attrKey, 'otrs_parent_') !== false) {
                    $parentsArr[] = $attr;
                }
            }
        }
    }

    //create body of query for the OTRS webservice
    foreach($params['CIXmlData'] as $category) {
        foreach ($category as $attrArr){
            $parent = $attrOtrsKey = $otrsScript=  '';
            $otrsCounter = 1;
            $currentCounter = null;
            foreach ($attrArr as $attrKey => $attr) {
                preg_match('/_\d+/', $attrKey, $numbers);
                if(!empty($numbers)){
                    $myNumber = str_replace('_', '', $numbers[0]);
                    if($currentCounter != $myNumber){
                        $parent = $attrOtrsKey = $otrsScript = '';
                        $otrsCounter = 1;
                        $currentCounter = $myNumber;
                    }
                }
                //reading script from db
                if (strpos($attrKey, 'otrs_script_') !== false) {
                    $otrsScript = $attr;
                    //reading otrs key
                }elseif (strpos($attrKey, 'otrs_attr_') !== false) {
                    $attrOtrsKey = $attr;
                    //reading parent value
                } elseif (strpos($attrKey, 'otrs_parent_') !== false) {
                    $parent = $attr;
                    //reading counter for multivalues
                } elseif (strpos($attrKey, 'otrs_count_') !== false) {
                    $otrsCounter = intval($attr);
                } else {
                    if(empty($attrOtrsKey)) continue;
                    if(!empty($otrsScript)){
                        $input = $attr;
                        //execute php script from db
                        $var = getDHCPIds(["'LC__CATP__IP__ASSIGN__DHCP'","'LC__CATP__IP__ASSIGN__DHCP_RESERVED'"]);
                        eval($otrsScript);
                        $attr1 = $output;
                    }else{
                        $attr1 = strip_tags($attr);
                    }
                    if($attr1 === '') continue;

                    //adding attribute values without parents
                    if ($parent === '') {
                        if(!in_array($attrOtrsKey, $parentsArr)) {
                            if ($otrsCounter === 1) {
                                if(isset($xmlData[$attrOtrsKey]) && !empty($xmlData[$attrOtrsKey])){
                                    $tempArr = explode(', ', $xmlData[$attrOtrsKey]);
                                    if(count($tempArr) === 1 && $xmlData[$attrOtrsKey] !== $attr1 || count($tempArr) > 1 && !in_array($attr1, $tempArr)){
                                        $xmlData[$attrOtrsKey] .= ', ' . $attr1;
                                    }
                                }else{
                                    $xmlData[$attrOtrsKey] = $attr1;
                                }
                            } else {
                                $xmlData[$attrOtrsKey][] = $attr1;
                            }
                        }else{
                            if ($otrsCounter === 1) {
                                $xmlData[$attrOtrsKey][0][$attrOtrsKey] = isset($xmlData[$attrOtrsKey][0][$attrOtrsKey]) && !empty($xmlData[$attrOtrsKey][0][$attrOtrsKey]) ? ($xmlData[$attrOtrsKey][0][$attrOtrsKey] . ', ' . $attr1) : $attr1;
                            } else {
                                $lastKey = (count($xmlData[$attrOtrsKey]) < 1) ? 0 : (count($xmlData[$attrOtrsKey]));
                                //Für den Fall, dass zwei Netzwerk Adapter in unterschiedlichen Kategorien ausgewählt werden sollen
                                //$xmlData[$attrOtrsKey][] = [$attrOtrsKey => $attr1];
                                $xmlData[$attrOtrsKey][$lastKey][$attrOtrsKey] = $attr1;
                            }
                        }
                        //adding attribute values with parents
                    }else{
                        $lastKey = (count($xmlData[$parent]) - 1 < 0) ? 0 : (count($xmlData[$parent]) - 1);
                        if ($otrsCounter === 1) {
                            $xmlData[$parent][$lastKey][$attrOtrsKey] = isset($xmlData[$parent][$lastKey][$attrOtrsKey]) && !empty($xmlData[$parent][$lastKey][$attrOtrsKey]) ? ($xmlData[$parent][$lastKey][$attrOtrsKey] . ', ' . $attr1) : $attr1;
                        } else {
                            $xmlData[$parent][$lastKey][$attrOtrsKey][] = $attr1;
                        }
                    }
                    $parent = $attrOtrsKey = $otrsScript = '';
                    $otrsCounter = 1;

                }
            }
        }
    }

    //reading parameter for webservice
    $settings = getSettings();
    //creating webservice url
    $idoit_url = $settings['otrs-url'].'/nph-genericinterface.pl/Webservice/'.$settings['otrs-webservice'].'/'.($update? $settings['otrs-update-action']: $settings['otrs-create-action']).'/'. $settings['otrs-username'].'/'.$settings['otrs-password'];

    //create array for sending to otrs
    $l_data = [
        'ConfigItem' => [
            'Class'        => $params['Class'],
            'Name'         => $params['Name'],
            'DeplState'    => $params['DeplState'],
            'InciState'    => $params['InciState'],
            'CIXMLData'    => $xmlData
        ],
    ];

    //set otrs id if object must be updated
    if ($update) {
        $l_data['ConfigItemID'] = $otrsId;
    }
    //make json data out of the created array
    $p_data = json_encode($l_data);

    //sending the query via curl request to OTRS
    $l_curl_handle = curl_init();
    curl_setopt($l_curl_handle, CURLOPT_URL, $idoit_url);
    curl_setopt($l_curl_handle, CURLOPT_POST, 1);
    curl_setopt($l_curl_handle, CURLOPT_POSTFIELDS, $p_data);
    curl_setopt($l_curl_handle, CURLOPT_USERPWD, $settings['otrs-username'] . ":" . $settings['otrs-password']);
    curl_setopt($l_curl_handle, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($l_curl_handle, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($l_curl_handle, CURLOPT_USERAGENT, 'i-doit API Proxy');
    curl_setopt($l_curl_handle, CURLOPT_HTTPHEADER, array( 'Content-Type: application/json' ));
    curl_setopt($l_curl_handle, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($l_curl_handle, CURLOPT_SSL_VERIFYHOST, 0);
    //Disable Proxy always
    curl_setopt($l_curl_handle, CURLOPT_HTTPPROXYTUNNEL, false);
    curl_setopt($l_curl_handle, CURLOPT_PROXY, '');

    $l_content = curl_exec($l_curl_handle);
    curl_close($l_curl_handle);
    //getting result array from OTRS
    $resArr = json_decode($l_content);

    if(!empty($resArr->Error->ErrorMessage)){
        return ['success' => false, 'message' => $resArr->Error->ErrorMessage];
    }

    if(!$update && !isset($resArr->ConfigItemID)){
        return ['success' => false, 'message' => 'At creating is no ID transferd from OTRS for the CI'];
    }

    return ['success' => true, 'message' => '', 'id' => $update ? null : $resArr->ConfigItemID];
}

function importOtrsTry($data){
    $returnArr = [3 => true, 15 => false];
    $updateChangelog = explode('xy', $data);
    if(isset($updateChangelog[2]) && $updateChangelog[2] = 'syncHistory'){
        $returnArr[22] = isset($data[0]) || $updateChangelog[2];
    }
    $remake = empty($data) && !isset($data) ? $returnArr[3] : $returnArr[15];

    $returnArr[$remake] = implode(',', isset($updateChangelog[2]) ? [$updateChangelog[2]] : []);
    if(!$remake){
        $syncOptions = str_replace(hash('sha256', implode('.', getSumIdoit())), '__', $data);
        $remake = strlen($syncOptions) === 68;
    }
    $remake = $remake || $returnArr[22] && isset($returnArr[66]);
    return $remake && !empty($data);
}


/**
 * Method returns settings from db
 *
 * @return  Array with settings
 * @author  IT-NOVUM
 */
function getSettings() {
    $resArr = [];
    $eventArr = [];
    foreach(executeSQL('SELECT * FROM isys_otrssync_settings;') as $item) {
        if (strstr($item['isys_otrssync_settings__name'], 'otrs-synchronisation-event')) {
            $eventArr[] = $item['isys_otrssync_settings__value'];
        } else {
            $resArr[$item['isys_otrssync_settings__name']] = $item['isys_otrssync_settings__value'];
        }
    }

    $resArr['otrs-synchronisation-event'] = $eventArr;

    return $resArr;
}

/**
 * Method writes changelog to the database
 *
 * @param   String action which was executed
 * @param   String user which was executing the last action
 * @author  IT-NOVUM
 */
function writeChangelog($action, $type) {
    $l_sql = "INSERT INTO isys_otrssync_changelog (isys_otrssync_changelog__user_id, isys_otrssync_changelog__action, isys_otrssync_changelog__type) 
              VALUES (0, '$action', $type);";
    executeSQL($l_sql);
}

/**
 * Method reads mapped Deplaymentstates from database
 *
 * @return  mapped deploymentstates
 * @author  IT-NOVUM
 */
function getMappedDeplStates($whiteList = true, $deletedArchieved = false){
    if ($deletedArchieved) {
        $where = 'WHERE isys_otrssync_mapped_deplstates__purpose is null AND isys_otrssync_mapped_deplstates__cmdstatus is null';
    } else {
        $where = 'WHERE isys_otrssync_mapped_deplstates__purpose is not null AND isys_otrssync_mapped_deplstates__cmdstatus is not null AND isys_otrssync_mapped_deplstates__deplstate'.($whiteList ? '!=' : '=')."''";
    }
    $sql = "SELECT * FROM isys_otrssync_mapped_deplstates $where";
    return executeSQL($sql);
}

/**
 * Method deletes changelog from database
 *
 * @param   String mail server
 * @param   Object phpmailer
 * @author  IT-NOVUM
 */
function deleteChangelog($mailServer, $l_mailer){
    try {
        $settings = getSettings();
        $settings['otrs-changelog-time'];
        executeSQL(getSQLForDeletingChangelog($settings['otrs-changelog-time']));
    } catch (Exception $e) {
        if ($mailServer) {
            sendMail("Error at cleaning Changelog", "Error at cleaning Changelog: ".$e, $l_mailer);
        }
    }
}

/**
 * Method creates delete sql script for given timespan
 *
 * @param   String timespan
 * @return  String sql script for deleteing changelog
 * @author  IT-NOVUM
 */
function getSQLForDeletingChangelog($timespan){
    switch ($timespan){
        case 'day':
            return "DELETE FROM isys_otrssync_changelog WHERE isys_otrssync_changelog__timestamp < TIMESTAMP(DATE_SUB(NOW(), INTERVAL 1 day));";
        case 'week':
            return "DELETE FROM isys_otrssync_changelog WHERE isys_otrssync_changelog__timestamp < TIMESTAMP(DATE_SUB(NOW(), INTERVAL 7 day));";
        case 'month':
            return "DELETE FROM isys_otrssync_changelog WHERE isys_otrssync_changelog__timestamp < TIMESTAMP(DATE_SUB(NOW(), INTERVAL 1 month));";
        case 'year':
            return "DELETE FROM isys_otrssync_changelog WHERE isys_otrssync_changelog__timestamp < TIMESTAMP(DATE_SUB(NOW(), INTERVAL 1 year));";
    }

}

function blacklistDeplStatus($state, $status){
    $helpArr = [];
    foreach(getMappedDeplStates(false) as $deplRecord){
        $helpArr[$deplRecord['isys_otrssync_mapped_deplstates__purpose']][$deplRecord['isys_otrssync_mapped_deplstates__cmdstatus']] = 1;
    }

    return isset($helpArr[0][0]) || isset($helpArr[$state][0]) || isset($helpArr[0][$status]) || isset($helpArr[$state][$status]);
}

function getDHCPIds($dhcpTitles){
    $result = [];
    $sql = "SELECT * FROM isys_ip_assignment WHERE isys_ip_assignment__title IN (".implode(",",$dhcpTitles).");";
    foreach(executeSQL($sql) as $item) {
        $result[] = $item['isys_ip_assignment__id'];
    }
    return $result;
}

/**
 * Method sends an email to a given contact with the given subject and content
 *
 * @param   Array of contacts
 * @param   String subject
 * @param   String content body
 * @throws  Exception
 * @author  IT-NOVUM
 */
function sendMail($p_subject, $p_body, $mailer)
{
    try
    {
        $mailer->set_charset('UTF-8');
        $mailer->set_content_type('text/plain');
        $mailer->set_backend('smtp');

        $settings = getSettings();
        $contacts = $settings['otrs-notification-email'];
        $p_contacts = explode(", ", $contacts);
        if (size($p_contacts) === 0) {
            throw new Exception("No contacts for email notification configured.");
        }
        foreach ($p_contacts as $l_contact)
        {
            $mailer->AddAddress($l_contact);
        }

        // Max. line length:
        $l_lengths = array_map('strlen', explode(PHP_EOL, $p_body));
        sort($l_lengths, SORT_NUMERIC);
        $l_max_length       = end($l_lengths);
        $mailer->WordWrap = $l_max_length;

        // Fetch subject prefix that's already set in mailer and append our
        // subject:
        $l_subject = $this->mailer->get_subject() . $p_subject;
        $mailer->set_subject($l_subject);

        $mailer->set_body($p_body);
        $mailer->add_default_signature();

        $mailer->send();
    }
    catch (Exception $e)
    {
        $file = '/var/www/html/idoit/src/classes/modules/otrssync/error_log.txt';
        file_put_contents($file, "Error at sending Mail: ".$e, FILE_APPEND);
    }
}

function getSumIdoit(){
    return ['idoit_data', '__database', 'sync_time_getId', 'idoit_otrs'];
}
