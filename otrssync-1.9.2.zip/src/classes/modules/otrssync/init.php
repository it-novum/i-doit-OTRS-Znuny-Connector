<?PHP

if (isys_module_manager::instance()->is_active('otrssync'))
{
	//include the autolaod class
    if (include_once('isys_module_otrssync_autoload.class.php'))
	{
		//initialise the autoloader
	    spl_autoload_register('isys_module_otrssync__autoload::init');
	}

	//check ich Psr4Autloader exists
    if (class_exists('\idoit\Psr4AutoloaderClass')) {
        //add module namespace for OTRS sync
        \idoit\Psr4AutoloaderClass::factory()->addNamespace('idoit\Module\Otrssync\Model', __DIR__);
        global $g_comp_session;
        //loading specific language file
        if (file_exists(__DIR__ . DS . 'lang' . DS . $g_comp_session->get_language() . '.inc.php')) {
            $l_language = include_once(__DIR__ . DS . 'lang' . DS . $g_comp_session->get_language() . '.inc.php');

            if (is_array($l_language)) {
                global $g_comp_template_language_manager;
                $g_comp_template_language_manager->append_lang($l_language);
            }
        }
    }
}

