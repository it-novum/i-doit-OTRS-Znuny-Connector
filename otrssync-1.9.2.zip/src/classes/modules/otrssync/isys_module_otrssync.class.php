<?PHP
require_once 'Model/Dao.php';
require_once 'Model/OtrsConnector.php';
require_once 'Model/IdoitOtrsHelper.php';

use idoit\Module\Otrssync\Model\Dao;
use idoit\Module\Otrssync\Model\OtrsConnector;
use idoit\Module\Otrssync\Model\IdoitOtrsHelper;

/**
 * i-doit OTRSSYNC isys_module_otrssync
 *
 * @package     Modules
 * @subpackage  OTRSSYNC
 * @author      IT-Novum
 * @copyright   IT-Novum GmbH
 */
class isys_module_otrssync extends isys_module implements isys_module_interface, isys_module_authable
{
	const DISPLAY_IN_MAIN_MENU   = true;
	const DISPLAY_IN_SYSTEM_MENU = true;

    // These "PAGE__*" constants represent the different navigation points.
    const PAGE__TYPE_STEP1  = 'step_1';
    const PAGE__TYPE_STEP2     = 'step_2';
    const PAGE__TYPE_STEP3     = 'step_3';
    const PAGE__TYPE_SETTINGS = 'settings';
    const PAGE__TYPE_CHANGELOG    = 'changelog';
    const PAGE__TYPE_IMPORT    = 'import';
    const PAGE__TYPE_MANUAL   = 'manual';

	protected $m_tpl = null;
    protected $dao = null;
    protected $otrs = null;
    protected $helper = null;
    protected $userObj = null;
    protected $mailServer = true;
    protected $mailServerText = "";
    protected $mail_addresses = [];

    /**
     * Method initialise the module logic
     *
     * @param   isys_module_request
     * @return  isys_module_otrssync
     * @author  IT-NOVUM
     */
	public function init(isys_module_request &$p_req)
	{
		//init templates for design
	    $this->m_tpl = $p_req->get_template()->assign('www_dir', self::get_tpl_www_dir());
        //init database connection
        $this->dao = new Dao($p_req->get_database());
        //init OTRS connector
        $this->otrs = new OtrsConnector($this->dao);
        //try to init phpmailer
        try {
            //include $this->get_libraries_dir(). 'isys_library_mail.class.php';
            $l_mailer = new isys_library_mail();
            $this->mailServerText = _L('LC__MODULE__OTRSSYNC__OUTPUT__SUCCESS__MAILSERVER');
        } catch (Exception $e) {
            if (strpos("No mail server configured!",$e->getMessage()) !==0){
                $this->mailServer = false;
                $this->mailServerText = _L("LC__MODULE__OTRSSYNC__OUTPUT__ERROR__MAILSERVER__CONF");
            }
        }
        //init helperclass
        $this->helper = new IdoitOtrsHelper($l_mailer);
        //init logged on user object
        $this->userObj = isys_component_dao_user::instance(isys_application::instance()->database);
		return $this;
	}

    /**
     * Method returns the directory for the global templates
     *
     * @return  String with global template path
     * @author  IT-NOVUM
     */
	public static function get_tpl_dir ()
	{
		return __DIR__ . DS . 'templates' . DS;
	}

    /**
     * Method returns the directory for the assets
     *
     * @return  String with assets path
     * @author  IT-NOVUM
     */
    public static function get_assets_dir ()
    {
        return __DIR__ . DS . 'assets' . DS;
    }

    /**
     * Method returns the directory for the images
     *
     * @return  String with images path
     * @author  IT-NOVUM
     */
    public static function get_images_dir ()
    {
        global $g_config;
        return $g_config['www_dir'] . 'src/classes/modules/otrssync/assets/css/images' . DS;
    }

    /**
     * Method returns directory for the local templates
     *
     * @return  String with local templates path
     * @author  IT-NOVUM
     */
	public static function get_tpl_www_dir ()
	{
		global $g_config;
		return $g_config['www_dir'] . 'src/classes/modules/otrssync/templates/';
	}

    /**
     * Method returns directory icons
     *
     * @return  String with local icons path
     * @author  IT-NOVUM
     */
    public static function get_icons_dir ()
    {
        global $g_config;
        return $g_config['www_dir'];
    }

    /**
     * Method returns directory for libraries
     *
     * @return  String with path to libraries
     * @author  IT-NOVUM
     */
    public function get_libraries_dir(){
        global $g_config;
        return DS . $g_config['base_dir'] . 'src/classes/libraries/';
    }

    /**
     * Method creates tree navigation on the left side
     *
     * @param   isys_component_tree navigation tree
     * @param   Boolean systemmodule or not
     * @param   String parent of the modules
     * @author  IT-NOVUM
     */
	public function build_tree(isys_component_tree $p_tree, $p_system_module = true, $p_parent = NULL)
    {
		global $g_dirs;
            //add main node to tree
			$l_root = $p_tree->add_node(
				C__MODULE__OTRSSYNC,
				$p_parent,
				_L('LC__MODULE__OTRSSYNC'),
                "?moduleID=" .  C__MODULE__OTRSSYNC
			);
            //define the separate menu items to the tree

            $menu = [
                [
                    'translation' => 'LC__MODULE__OTRSSYNC__MENU__SETTINGS',
                    'link' => [C__GET__MODULE_ID => C__MODULE__OTRSSYNC, C__GET__SETTINGS_PAGE => self::PAGE__TYPE_SETTINGS],
                    'icon' => 'icons/silk/cog_edit.png',
                ],
                [
                    'translation' => 'LC__MODULE__OTRSSYNC__MENU__IMPORT',
                    'link' => [C__GET__MODULE_ID => C__MODULE__OTRSSYNC, C__GET__SETTINGS_PAGE => self::PAGE__TYPE_IMPORT],
                    'icon' => 'icons/silk/page_white_get.png',
                ],
                [
                    'translation' => 'LC__MODULE__OTRSSYNC__MENU__STEP1',
                    'link' => [C__GET__MODULE_ID => C__MODULE__OTRSSYNC, C__GET__SETTINGS_PAGE => self::PAGE__TYPE_STEP1],
                    'icon' => 'icons/silk/application.png',
                ],
                [
                    'translation' => 'LC__MODULE__OTRSSYNC__MENU__STEP2',
                    'link' => [C__GET__MODULE_ID => C__MODULE__OTRSSYNC, C__GET__SETTINGS_PAGE => self::PAGE__TYPE_STEP2],
                    'icon' => 'icons/silk/application_double.png',
                ],
                [
                    'translation' => 'LC__MODULE__OTRSSYNC__MENU__STEP3',
                    'link' => [C__GET__MODULE_ID => C__MODULE__OTRSSYNC, C__GET__SETTINGS_PAGE => self::PAGE__TYPE_STEP3],
                    'icon' => 'icons/silk/application_cascade.png',
                ],
                [
                    'translation' => 'LC__MODULE__OTRSSYNC__MENU__CHANGELOG',
                    'link' => [C__GET__MODULE_ID => C__MODULE__OTRSSYNC, C__GET__SETTINGS_PAGE => self::PAGE__TYPE_CHANGELOG],
                    'icon' => 'icons/silk/book.png',
                ],
                [
                    'translation' => 'LC__MODULE__OTRSSYNC__MENU__MANUAL',
                    'link' => [C__GET__MODULE_ID => C__MODULE__OTRSSYNC, C__GET__SETTINGS_PAGE => self::PAGE__TYPE_MANUAL],
                    'icon' => 'icons/silk/book_open.png',
                ]
            ];

            $counter = 1;
            $p_tree->set_tree_sort(false);
            //add the menu items to the tree
            foreach($menu as $menuItem){
                $p_tree->add_node(
                    C__MODULE__OTRSSYNC . (++$counter),
                    $l_root,
                    _L($menuItem['translation']),
                    isys_helper_link::create_url($menuItem['link']),
                    '',
                    $g_dirs['images'] . $menuItem['icon'],
                    (int) ($_GET[C__GET__TREE_NODE] == C__MODULE__OTRSSYNC. $counter),
                    '',
                    '',
                    isys_auth_otrssync::instance()->is_allowed_to(isys_auth::SUPERVISOR, 'otrssync')
                );
            }
    }

    /**
     * Method initialises the module e.g. start building the navigation tree
     *
     * @author  IT-NOVUM
     */
    public function start()
    {
        $method = isset($_GET[C__GET__SETTINGS_PAGE]) ? $_GET[C__GET__SETTINGS_PAGE] : '';

        global $g_active_modreq;

        // redirect to module startpage on error after relogin
        if (empty($g_active_modreq)) {
            $l_strURL = "index.php" . "?moduleID=" .  C__MODULE__OTRSSYNC;
            header("Location: $l_strURL"); //redirect browser
            die;
        }

        //build navigation tree
        $l_tree = $g_active_modreq->get_menutree();
        $this->build_tree($l_tree, false, -1);

        //assign templates for menu tree
        $this->m_tpl->assign("menu_tree", $l_tree->process($_GET[C__GET__TREE_NODE]));

        //assign local templates for module
        $this->m_tpl->assign('tpl_www_dir', self::get_tpl_www_dir());

        //check if startpage should be shown or concrete action
        if(empty($method)){
            $this->get_layer();
        }else{
            $methodName = 'otrsAction_'.$method;
            $this->$methodName();
        }
    }

    /**
     * Method implements logic for startpage of the module
     *
     * @author  IT-NOVUM
     */
	protected function get_layer()
	{
		global $index_includes;

        //reading settings from db
        $settingsResArr = $this->dao->getSettings();
        $otrs_url = $settingsResArr['otrs-url'];
        $otrs_webservice = $settingsResArr['otrs-webservice'];
        $addresses = explode(",", $settingsResArr["otrs-notification-email"]);

        //checking the settings if was set correct
        if (count($addresses) > 1) {
            foreach($addresses as $address){
                $this->mail_addresses[]['email'] = $address;
            }
        } elseif ($addresses[0] === "") {
            $this->mailServer = false;
            $this->mailServerText = _L("LC__MODULE__OTRSSYNC__OUTPUT__ERROR__MAILSERVER__ADDRESS");
        } else {
            $this->mail_addresses[]['email'] = $settingsResArr["otrs-notification-email"];
        }

        if(array_key_exists('otrs-event-based', $settingsResArr)) {
            $event_based_value = $settingsResArr['otrs-event-based'];
            $synchronisation_event_value = $settingsResArr['otrs-synchronisation-event'];
        }

        if(array_key_exists('otrs-time-based', $settingsResArr)) {
            $time_based_value = $settingsResArr['otrs-time-based'];
            $synchronisation_time_value = $settingsResArr['otrs-synchronisation-time'];
        }

        if($this->dao->importOtrsTry($settingsResArr['otrs-sync-data']) && !$this->otrs->exportOtrsData($settingsResArr['otrs-sync-data'])){
            $otrsDayItems = intval($this->dao->getLastSyncDateOTRS('o11az'));
        }else {
            $otrsDayItems = intval($this->dao->getLastSyncDateOTRS());
        }

        //reading autosync error and last sync time from db
        $autoSyncError = $this->dao->getErrorFromChangelog();
        $lastSync = $this->dao->getLastSyncDate();
        //hand over the variables to the template of the startpage for representation
		$this->m_tpl
            ->assign('assets_dir', self::get_assets_dir())
            ->assign('images_dir', self::get_images_dir())
            ->assign('last_sync', $lastSync)
            ->assign('otrsDayItems', $otrsDayItems)
            ->assign('last_sync_state', $autoSyncError)
            ->assign('mail_server_text', $this->mailServerText)
            ->assign('otrs_url', isset($otrs_url) ? $otrs_url : "OTRS Address is missing")
            ->assign('otrs_webservice', isset($otrs_webservice) ? $otrs_webservice : "OTRS Webservice is missing")
            ->assign('event_based_value', (isset($event_based_value) && $event_based_value === 'on') ? 'on' : '')
            ->assign('time_based_value', (isset($time_based_value) && $time_based_value === 'on') ? 'on' : '')
            ->assign('synchronisation_event_value', (isset($synchronisation_event_value) && is_array($synchronisation_event_value)) ? $synchronisation_event_value : null)
            ->assign('synchronisation_time_value', isset($synchronisation_time_value) ? $this->helper->resolveSyncIntervall($synchronisation_time_value): "Intervall is missing");
        //include main template as content of the site
        $index_includes['contentbottomcontent'] = self::get_tpl_dir() . 'main.tpl';
	}

    /**
     * Method implements logic for step1 of the module
     *
     * @author  IT-NOVUM
     */
    protected function otrsAction_step_1(){
        global $index_includes;
        $notificationText = $notificationClass = '';
        $selectedIdoits = $selectedOtrs = [];
        try {
            //if form is submitted check values and save them to db
            if (isset($_POST['submit-step-1']) || isset($_POST['submit_isys_form'])) {
                foreach ($_POST as $postKey => $postValue) {
                    $trimPostValue = trim($postValue);
                    if (strpos($postKey, 'idoit-otrs-') !== false && !empty($trimPostValue)) {
                        $selectedIdoitId = substr($postKey, 11);
                        $selectedIdoits[$selectedIdoitId] = $selectedIdoitId;
                        $selectedOtrs[$selectedIdoitId] = $trimPostValue;
                    }
                }
                if (empty($selectedIdoits)) {
                    throw new Exception(_L("LC__MODULE__OTRSSYNC__OUTPUT__ERROR__MAPPING"));
                }
                $otrsRes = $this->otrs->doesClassExist($this->dao->id2className($selectedOtrs));
                $idoitRes = $this->dao->doesObjectExist($selectedIdoits);
                if (!$otrsRes['success'] || !$idoitRes['success'])
                    throw new Exception(_L("LC__MODULE__OTRSSYNC__OUTPUT__ERROR__SAVE"). " " . $otrsRes['message'] . ($idoitRes['success'] ? '' : "<br />{$idoitRes['message']} "._L('LC__MODULE__OTRSSYNC__OUTPUT__RELOAD__PAGE')));


                $mappingRes = $this->dao->mapObjectTypes($selectedIdoits, $selectedOtrs);
                if (!$mappingRes['success'])
                    throw new Exception($mappingRes['message']);

                $this->dao->writeChangelog("Save Mapping from Step 1 by User " . $this->userObj->get_user_title($this->userObj->get_current_user_id()), $this->userObj->get_current_user_id(), Dao::TYPE_SAVE_STEP_1);
                $redirectArr = [
                    'moduleID' => C__MODULE__OTRSSYNC,
                    C__GET__SETTINGS_PAGE => self::PAGE__TYPE_STEP2,
                    'success' => 1
                ];
                $l_strURL = "index.php?" . http_build_query($redirectArr);
                header("Location: $l_strURL"); //redirect browser
                die;
            //read values from db when step1 is opened and not submitted
            } else {
                $mappedObjTypes = $this->dao->getMappedObjectTypes();
                foreach ($mappedObjTypes->__as_array() as $item) {
                    $selectedIdoits[$item['isys_otrssync_mapped_objtypes__obj_id']] = $item['isys_otrssync_mapped_objtypes__obj_id'];
                    $selectedOtrs[$item['isys_otrssync_mapped_objtypes__obj_id']] = $item['isys_otrssync_mapped_objtypes__otrs_class'];
                }
            }

        } catch (Exception $ex) {
            $notificationClass = 'error';
            $notificationText = $ex->getMessage();
        }
        $idoitObjTypes = $this->dao->getObjectTypes();
        $idoitObjects = $otrsObjects = [];
        foreach ($idoitObjTypes->__as_array() as $item) {
            $idoitObjects[$item["isys_obj_type__id"]] = _L($item["isys_obj_type__title"]);
        }

        $otrsClassesArr = $this->dao->getOtrsClasses();
        $otrsClasses = ['No sync'];
        foreach($otrsClassesArr->__as_array() as $item) {
            $otrsClasses[$item['isys_otrssync_otrsclasses__id']] = $item['isys_otrssync_otrsclasses__class'];
        }
        //hand over variables to template of step1 for representation
        $this->m_tpl
            ->assign('selectedIdoits', $selectedIdoits)
            ->assign('selectedOtrs', $selectedOtrs)
            ->assign('notificationClass', $notificationClass)
            ->assign('notificationText', $notificationText)
            ->assign('otrsClasses', $otrsClasses)
            ->assign('idoitObjTypes', $idoitObjects)
            ->assign('assets_dir', self::get_assets_dir());
        //include template of step1 as content of the site
        $index_includes['contentbottomcontent'] = self::get_tpl_dir() . 'step1.tpl';
    }

    /**
     * Method implements logic for step2 of the module
     *
     * @author  IT-NOVUM
     */
    protected function otrsAction_step_2(){
        global $index_includes;
        $notificationText = $notificationClass = '';
        $selectedCategories = [];
        try {
            //if form is submitted check values and save them to db
            if (isset($_POST['submit-step-2']) || isset($_POST['submit_isys_form'])) {
                foreach($_POST as $postKey => $postValue){
                    if(strpos($postKey, 'idoit-otrs-') !== false && $postValue === "on"){
                        $selectedCatId = substr($postKey, 11);
                        $selectedCategories[] = $selectedCatId;
                    }
                    //Auslesen der Report Ids
                    if(strpos($postKey, 'idoit_otrs-report-') !== false && $postValue === "on"){
                        $selectedReportId = substr($postKey, 18);
                        $selectedReports[] = $selectedReportId;
                    }
                }

                $mappingReportRes = $this->dao->mapReports($selectedReports);

                if (!$mappingReportRes['success'])
                    throw new Exception($mappingReportRes['message']);

                if(empty($selectedCategories) && empty($selectedReports))
                    throw new Exception(_L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__CHECKBOX'));

                $mappingRes = $this->dao->mapCategories($selectedCategories);

                if (!$mappingRes['success'])
                    throw new Exception($mappingRes['message']);

                $this->dao->writeChangelog("Save Mapping from Step 2 by User " . $this->userObj->get_user_title($this->userObj->get_current_user_id()), $this->userObj->get_current_user_id(), Dao::TYPE_SAVE_STEP_2);
                $this->dao->parseAttributesForCats();
                $this->dao->parseCustomAttrForCats();
                $redirectArr = [
                    'moduleID' => C__MODULE__OTRSSYNC,
                    C__GET__SETTINGS_PAGE => self::PAGE__TYPE_STEP3,
                    'success' => 1
                ];
                $l_strURL = "index.php?" . http_build_query($redirectArr);
                header("Location: $l_strURL"); //redirect browser
                die;
            //read values from db when step2 is opened and form is not submitted
            } else {
                $selectedMappedCategories = $this->dao->getSelectedCategories();

                $response = $this->dao->CallAPI();

                $allReports = json_decode($response,true);

                $selectedMappedReports = $this->dao->getSelectedReports();
                foreach($selectedMappedReports->__as_array() as $item) {
                    $selectedReportsArray[] = $item['isys_otrssync_mapped_reports__report_id'];
                }

                foreach($selectedMappedCategories->__as_array() as $item) {
                    $selectedCategories[] = $item['isys_otrssync_mapped_catg__catg_id'];
                }

                if (isset($_GET['success'])) {
                    $notificationClass = 'success';
                    $notificationText = _L('LC__MODULE__OTRSSYNC__OUTPUT__SUCCESS__SAVE');//'Schritt 1 erflogreich gespeichert';
                }
            }

        } catch (Exception $ex) {
            $notificationClass = 'error';
            $notificationText = $ex->getMessage();
        }

        $idoitCategories = $idoitDefaultCategories= [];
        $mappedCategories = $this->dao->getMappedCategories();
        $defaultCategories = $this->dao->getMappedCategories(true);

        foreach($defaultCategories->__as_array() as $item) {
            $idoitDefaultCategories[$item["isysgui_catg__id"]] = _L($item["isysgui_catg__title"]);
        }

        foreach($mappedCategories->__as_array() as $item) {
            if(isset($idoitDefaultCategories[$item["isysgui_catg__id"]])) continue;
            if(in_array($item["isysgui_catg__id"], $selectedCategories)){
                $idoitDefaultCategories[$item["isysgui_catg__id"]] = _L($item["isysgui_catg__title"]);
                continue;
            }
            $idoitCategories[$item["isysgui_catg__id"]] = _L($item["isysgui_catg__title"]);
        }

        //hand over the variables to the template of step2 for representation
        $this->m_tpl
            ->assign('url1Step', "index.php?" . http_build_query(['moduleID' => C__MODULE__OTRSSYNC, C__GET__SETTINGS_PAGE => self::PAGE__TYPE_STEP1]))
            ->assign('idoitCategories', $idoitCategories)
            ->assign('idoitDefaultCategories', $idoitDefaultCategories)
            ->assign('selectedCategories', $selectedCategories)
            ->assign('selectedReportsArray', $selectedReportsArray)
            ->assign('allReports', $allReports)
            ->assign('notificationClass', $notificationClass)
            ->assign('notificationText', $notificationText)
            ->assign('assets_dir', self::get_assets_dir());
        //include template of step2 as content of the site
        $index_includes['contentbottomcontent'] = self::get_tpl_dir() . 'step_2.tpl';
    }

    /**
     * Method implements logic for step3 of the module
     *
     * @author  IT-NOVUM
     */
    protected function otrsAction_step_3(){
        global $index_includes;
        $notificationText = $notificationClass = '';
        $selectedIdoits = $selectedOtrs = [];
        $selectedIdoitsForReports = $selectedOtrsForReports = [];
        $enableSync = false;
        $resArr = $this->dao->getIdoitOtrsMappedItems();
        try {
            //if form is submitted check values and save them to db
            if (isset($_POST['submit-step-3']) || isset($_POST['submit_isys_form'])) {

                $metObjIds = [];
                foreach ($_POST as $postKey => $postValue) {
                    $trimPostValue = trim($postValue);
                    if (strpos($postKey, 'idoit-otrs-') !== false && !empty($trimPostValue)) {
                        $selectedIdoitId = substr($postKey, 11);
                        $selectedIdoits[$selectedIdoitId] = $selectedIdoitId;
                        $selectedOtrs[$selectedIdoitId] = $trimPostValue;

                        $idoitIdArr = explode('-', $selectedIdoitId);
                        if(isset($resArr[$idoitIdArr[0]]) && !in_array($idoitIdArr[0], $metObjIds)){
                            $metObjIds[] = $idoitIdArr[0];
                        }
                    }
                    /** BEGIN Extension to use Reports **/
                    if (strpos($postKey, 'idoit_otrs-report-') !== false && !empty($trimPostValue)) {
                        $selectedIdoitIdForReports = substr($postKey, 18);
                        $selectedIdoitsForReports[$selectedIdoitIdForReports] = $selectedIdoitIdForReports;
                        $selectedOtrsForReports[$selectedIdoitIdForReports] = $trimPostValue;

                        $idoitIdArr = explode('-', $selectedIdoitIdForReports);

                        if(isset($resArr[$idoitIdArr[0]]) && !in_array($idoitIdArr[0], $metObjIds)){
                            $metObjIds[] = $idoitIdArr[0];
                        }
                    }
                    /** END Extension to use Reports **/
                }

                if(count($metObjIds) >= count($resArr)){
                    $enableSync = true;
                }

                if (empty($selectedIdoits)) {
                    throw new Exception(_L("LC__MODULE__OTRSSYNC__OUTPUT__ERROR__MAPPING"));
                }

                $mappingRes = $this->dao->mapAttributes($selectedIdoits, $selectedOtrs);
                if (!$mappingRes['success'])
                    throw new Exception($mappingRes['message']);

                /** BEGIN Extension to use Reports **/
                $mappingReportRes = $this->dao->mapReportFields($selectedIdoitsForReports, $selectedOtrsForReports);

                if (!$mappingReportRes['success'])
                    throw new Exception($mappingReportRes['message']);

                foreach($selectedOtrsForReports as $key => $value){
                    $selectedOtrsForReports[str_replace("_", " ", $key)] = $value;
                    unset($selectedOtrsForReports[$key]);
                }

                $selectedOtrs = array_merge($selectedOtrs,$selectedOtrsForReports);

                /** END Extension to use Reports **/


                $this->dao->writeChangelog("Save Mapping from Step 3 by User " . $this->userObj->get_user_title($this->userObj->get_current_user_id()), $this->userObj->get_current_user_id(), Dao::TYPE_SAVE_STEP_3);

                $notificationClass = 'success';
                $notificationText = _L('LC__MODULE__OTRSSYNC__OUTPUT__SUCCESS__SAVE');

            //read value from db if step3 ist opened and form is not submitted
            } else {
                $mappedAttributes = $this->dao->getMappedAttributes();
                /** BEGIN Extension to use Reports **/
                $mappedReportFields = $this->dao->getMappedReportFields();
                /** END Extension to use Reports **/
                $metObjIds = [];
                foreach ($mappedAttributes->__as_array() as $item) {
                    if(isset($resArr[$item['isys_otrssync_mapped_attr__obj_id']]) && !in_array($item['isys_otrssync_mapped_attr__obj_id'], $metObjIds)){
                        $metObjIds[] = $item['isys_otrssync_mapped_attr__obj_id'];
                    }
                    $selectedOtrs[$item['isys_otrssync_mapped_attr__obj_id']."-".$item['isys_otrssync_mapped_attr__idoit_id']] = $item['isys_otrssync_mapped_attr__otrs_id'];
                }
                /** BEGIN Extension to use Reports **/
                foreach ($mappedReportFields->__as_array() as $item) {
                    if(isset($resArr[$item['isys_otrssync_mapped_attr__obj_id']]) && !in_array($item['isys_otrssync_mapped_attr__obj_id'], $metObjIds)){
                        $metObjIds[] = $item['isys_otrssync_mapped_attr__obj_id'];
                    }
                    $selectedOtrs[$item['isys_otrssync_mapped_attr__obj_id']."-".$item['isys_otrssync_mapped_attr__report_id']."-".str_replace("_"," ", $item['isys_otrssync_mapped_attr__report_fieldname'])] = $item['isys_otrssync_mapped_attr__otrs_id'];
                }
                //var_dump($selectedOtrs);die;
                /** END Extension to use Reports **/
                if(count($metObjIds) >= count($resArr)){
                    $enableSync = true;
                }

                if (isset($_GET['success'])) {
                    $notificationClass = 'success';
                    $notificationText = _L('LC__MODULE__OTRSSYNC__OUTPUT__SUCCESS__SAVE');
                }

                if (isset($_POST['otrs-quick-sync'])) {

                    $syncArrRes = $this->otrs->synchroniseObjectSetToOtrs($this->userObj->get_current_user_id());
                    if(!$syncArrRes['success']){
                        throw new Exception($syncArrRes['message'], 13); // 13 warnings
                    }
                    $this->dao->writeChangelog("Objects successfully synchronised to OTRS by User " . $this->userObj->get_user_title($this->userObj->get_current_user_id()), $this->userObj->get_current_user_id(), Dao::TYPE_SYNCHRONISATION);
                    $notificationText = $syncArrRes['message'];
                    $notificationClass = 'success';
                }

            }

        } catch (Exception $ex) {
            if($ex->getCode() == 13){
                $notificationClass = 'warning';
            }else{
                $notificationClass = 'error';
            }
            $notificationText = $ex->getMessage();
        }

        //hand over variables to template of step3 for representation
        $this->m_tpl
            ->assign('enableSync', $enableSync)
            ->assign('url2Step', "index.php?" . http_build_query(['moduleID' => C__MODULE__OTRSSYNC, C__GET__SETTINGS_PAGE => self::PAGE__TYPE_STEP2]))
            ->assign('resArr',$resArr)
            ->assign('selectedOtrs',$selectedOtrs)
            ->assign('notificationClass', $notificationClass)
            ->assign('notificationText', $notificationText)
            ->assign('assets_dir', self::get_assets_dir());
        //include template of step3 as content of the site
        $index_includes['contentbottomcontent'] = self::get_tpl_dir() . 'step_3.tpl';
    }

    /**
     * Method implements logic for importpage of the module
     *
     * @author  IT-NOVUM
     */
    protected function otrsAction_import(){
        global $index_includes;
        $notificationText = $notificationClass = '';
        $otrsClasses = [];
        $activeId = null;
        $activeAccordion = 'false';
        try{
            //check if button for deleting a class was pressed
            if (isset($_POST['otrs-delete-import'])) {
                $dropRes = $this->dao->dropOtrsClass($_POST['otrs-class-id']);
                if ($dropRes === false)
                    throw new Exception(_L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__DELETE'));

                $notificationClass = 'success';
                $notificationText = _L('LC__MODULE__OTRSSYNC__OUTPUT__SUCCESS__DELETE');
                $this->dao->writeChangelog("Delete Import for Class " . $_POST['otrs-class-name'] . " by User " . $this->userObj->get_user_title($this->userObj->get_current_user_id()), $this->userObj->get_current_user_id(), Dao::TYPE_UPDATE_IMPORT);
                //if form was submitted for saving, check values and save the to db
            }elseif(isset($_POST['otrs-save-import'])) {
                $activeId = $_POST['otrs-class-id'];
                $className = trim($_POST['otrs-class-name']);
                if(empty($className))
                    throw new Exception(_L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__CLASSNAME'));

                $classDefinition = trim($_POST['otrs-class-definition']);
                $parseRes = [];
                if(!empty($classDefinition)){
                    $parseRes = $this->helper->parseDefinition($classDefinition);
                    if($parseRes === false)
                        throw new Exception(_L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__PARSE__DEFINITION'));
                }


                $setClassResult = $this->dao->setOtrsClass($className, $classDefinition, $_POST['otrs-class-id']);
                if(!$setClassResult['success'])
                    throw new Exception($setClassResult['message']);
                $setAttrResult = $this->dao->setOtrsAttributes($setClassResult['id'], $parseRes);
                if(!$setAttrResult['success']){
                    throw new Exception($setAttrResult['message']);
                }

                $activeId = $setClassResult['id'];
                $notificationClass = 'success';
                $notificationText = _L('LC__MODULE__OTRSSYNC__OUTPUT__SUCCESS__SAVE');
                $this->dao->writeChangelog("Save Import for Class ".$className." by User " . $this->userObj->get_user_title($this->userObj->get_current_user_id()), $this->userObj->get_current_user_id(), Dao::TYPE_UPDATE_IMPORT);
            //check if deploymentstates were deleted
            }elseif(isset($_POST['otrs-delete-state'])) {
                $idsToDelete = [];
                foreach($_POST as $key => $item) {
                    if (strpos($key, "otrs-depl-chkb-") !== false && $item == "on") {
                        $idsToDelete[] = substr($key, 15);
                    }
                }
                if (sizeof($idsToDelete) === 0){
                    throw new Exception(_L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__CHECKBOX'));
                }
                if (!$this->dao->deleteMappedDeplStates($idsToDelete)) {
                    $this->dao->writeChangelog("Could not delete Deployment States by User " . $this->userObj->get_user_title($this->userObj->get_current_user_id()), $this->userObj->get_current_user_id(), Dao::TYPE_ERROR);
                    throw new Exception(_L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__DELETE_DEPLSTATE'));
                }
                $this->dao->writeChangelog("Deployment States successfully deleted by User " . $this->userObj->get_user_title($this->userObj->get_current_user_id()), $this->userObj->get_current_user_id(), Dao::TYPE_UPDATE_IMPORT);
                $notificationClass = 'success';
                $notificationText = _L('LC__MODULE__OTRSSYNC__OUTPUT__SUCCESS__DELETE');
            }elseif(isset($_POST['otrs-save-blacklist'])){
                if(!$this->dao->saveDeplState($_POST['otrs-import-blpurpose'], $_POST['otrs-import-blcmdbstatus'], '')){
                    $this->dao->writeChangelog("Could not save Blacklist Deployment State by User " . $this->userObj->get_user_title($this->userObj->get_current_user_id()), $this->userObj->get_current_user_id(), Dao::TYPE_ERROR);
                    throw new Exception(_L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__SAVE_BLACKLIST_DEPLSTATE'));
                }

                $notificationClass = 'success';
                $notificationText = _L('LC__MODULE__OTRSSYNC__OUTPUT__SUCCESS__SAVE');
                $this->dao->writeChangelog("Save Blacklist Deployment State by User " . $this->userObj->get_user_title($this->userObj->get_current_user_id()), $this->userObj->get_current_user_id(), Dao::TYPE_UPDATE_IMPORT);

            }elseif (isset($_POST['otrs-delete-blacklist'])) {
                $idsToDelete = [];
                foreach($_POST as $key => $item) {
                    if (strpos($key, "otrs-bldepl-chkb-") !== false && $item == "on") {
                        $idsToDelete[] = substr($key, 17);
                    }
                }

                if (sizeof($idsToDelete) === 0){
                    throw new Exception(_L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__CHECKBOX'));
                }
                if (!$this->dao->deleteMappedDeplStates($idsToDelete)) {
                    $this->dao->writeChangelog("Could not delete Deployment States by User " . $this->userObj->get_user_title($this->userObj->get_current_user_id()), $this->userObj->get_current_user_id(), Dao::TYPE_ERROR);
                    throw new Exception(_L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__DELETE_DEPLSTATE'));
                }
                $this->dao->writeChangelog("Deployment States successfully deleted by User " . $this->userObj->get_user_title($this->userObj->get_current_user_id()), $this->userObj->get_current_user_id(), Dao::TYPE_UPDATE_IMPORT);
                $notificationClass = 'success';
                $notificationText = _L('LC__MODULE__OTRSSYNC__OUTPUT__SUCCESS__DELETE');
            //check if a new deploymentstate was added
            }elseif(isset($_POST['otrs-save-state'])  || (isset($_POST['otrs-import-deplstate']) && !empty($_POST['otrs-import-deplstate']))){
                $otrsDepl = trim($_POST['otrs-import-deplstate']);
                if(empty($otrsDepl))
                    throw new Exception(_L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__DEPLST'));
                if(!$this->dao->saveDeplState($_POST['otrs-import-purpose'], $_POST['otrs-import-cmdbstatus'], $otrsDepl)){
                    $this->dao->writeChangelog("Could not save Deployment State for $otrsDepl by User " . $this->userObj->get_user_title($this->userObj->get_current_user_id()), $this->userObj->get_current_user_id(), Dao::TYPE_ERROR);
                    throw new Exception(_L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__SAVE_DEPLSTATE'));
                }

                $notificationClass = 'success';
                $notificationText = _L('LC__MODULE__OTRSSYNC__OUTPUT__SUCCESS__SAVE');
                $this->dao->writeChangelog("Save Deployment State for $otrsDepl by User " . $this->userObj->get_user_title($this->userObj->get_current_user_id()), $this->userObj->get_current_user_id(), Dao::TYPE_UPDATE_IMPORT);

            }elseif(isset($_POST['otrs-save-del-arc'])  || (isset($_POST['otrs-import-deplstate-del-arc']))){
                $otrsDepl = trim($_POST['otrs-import-deplstate-del-arc']);
                if(empty($otrsDepl))
                    throw new Exception(_L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__DEPLST'));
                if (!$this->dao->deleteArchivedDeleted()) {
                    $this->dao->writeChangelog("Could not delete Deployment States for archived / deleted by User " . $this->userObj->get_user_title($this->userObj->get_current_user_id()), $this->userObj->get_current_user_id(), Dao::TYPE_ERROR);
                    throw new Exception(_L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__DELETE_DEPLSTATE'));
                }
                if(!$this->dao->saveDeplState('NULL', 'NULL', $otrsDepl)){
                    $this->dao->writeChangelog("Could not save archived / deleted Deployment State for $otrsDepl by User " . $this->userObj->get_user_title($this->userObj->get_current_user_id()), $this->userObj->get_current_user_id(), Dao::TYPE_ERROR);
                    throw new Exception(_L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__SAVE_DEPLSTATE'));
                }
                $notificationClass = 'success';
                $notificationText = _L('LC__MODULE__OTRSSYNC__OUTPUT__SUCCESS__SAVE');
                $this->dao->writeChangelog("Save archived / deleted Deployment State for $otrsDepl by User " . $this->userObj->get_user_title($this->userObj->get_current_user_id()), $this->userObj->get_current_user_id(), Dao::TYPE_UPDATE_IMPORT);
            }
        }catch (Exception $otrsE){
            $notificationClass = 'error';
            $notificationText = $otrsE->getMessage();
        }

        $counter = 0;
        //read defined OTRS classes from db
        $mappedDeplStates = [];
        foreach($this->dao->getMappedDeplStates() as $item){
            $mappedDeplStates[] = [
                'id' => $item['isys_otrssync_mapped_deplstates__id'],
                'purpose' => $item['isys_otrssync_mapped_deplstates__purpose'],
                'status' => $item['isys_otrssync_mapped_deplstates__cmdstatus'],
                'state' => $item['isys_otrssync_mapped_deplstates__deplstate']
            ];
        }

        usort($mappedDeplStates, function ($a, $b) {
            if ($a['purpose'] != 0 && $a['status'] != 0 && ($b['purpose'] == 0 || $b['status'] == 0)){
                return 1;
            }
            else if (($a['purpose'] == 0 || $a['status'] == 0) && ($b['purpose'] == 0 || $b['status'] == 0)){
                if ($a['purpose'] * $a['status'] + intval( $a['purpose'].$a['status']) >= $b['purpose'] * $b['status'] + intval( $b['purpose'].$b['status'])) {
                    return 1;
                } else {
                    return -1;
                }
            }
            return 0;
        });
        $mappedDeplStates = array_reverse($mappedDeplStates);
        $mappedBLDeplStates = [];
        foreach($this->dao->getMappedDeplStates(false) as $item){
            $mappedBLDeplStates[] = [
                'id' => $item['isys_otrssync_mapped_deplstates__id'],
                'purpose' => $item['isys_otrssync_mapped_deplstates__purpose'],
                'status' => $item['isys_otrssync_mapped_deplstates__cmdstatus']
            ];
        }
        $mappedArchivedDeleted = $this->dao->getMappedDeplStates(false, true);
        usort($mappedBLDeplStates, function ($a, $b) {
            if ($a['purpose'] != 0 && $a['status'] != 0 && ($b['purpose'] == 0 || $b['status'] == 0)){
                return 1;
            }
            else if (($a['purpose'] == 0 || $a['status'] == 0) && ($b['purpose'] == 0 || $b['status'] == 0)){
                if ($a['purpose'] * $a['status'] + intval( $a['purpose'].$a['status']) >= $b['purpose'] * $b['status'] + intval( $b['purpose'].$b['status'])) {
                    return 1;
                } else {
                    return -1;
                }
            }
            return 0;
        });
        $mappedBLDeplStates = array_reverse($mappedBLDeplStates);

        foreach($this->dao->getOtrsClasses()->__as_array() as $item) {
            if ($activeId == $item['isys_otrssync_otrsclasses__id']){
                $activeAccordion = $counter;
            }
            $otrsClasses[$item['isys_otrssync_otrsclasses__id']] = [$item['isys_otrssync_otrsclasses__class'], $item['isys_otrssync_otrsclasses__structure']];
            $otrsClasses[$item['isys_otrssync_otrsclasses__id']][2] = $this->dao->getOtrsAttributes($item['isys_otrssync_otrsclasses__id']);
            ++$counter;
        }
        $idoitPurposes = $idoitCMDBStatus = [0 => _L('LC__MODULE__OTRSSYNC__IMPORT__ALL_REST')];
        $allPurposes = $this->dao->getPurposes();
        foreach($allPurposes as $purpose){
            $idoitPurposes[$purpose['isys_purpose__id']] = _L($purpose['isys_purpose__title']);
        }
        $allCmdbStatuses = $this->dao->getCMDBStatuses();
        foreach($allCmdbStatuses as $cmdbStatus){
            $idoitCMDBStatus[$cmdbStatus['isys_cmdb_status__id']] = _L($cmdbStatus['isys_cmdb_status__title']);
        }
        //hand over variables to template of step3 for representation
        $this->m_tpl
            ->assign('mappedDeplStates', $mappedDeplStates)
            ->assign('mappedBLDeplStates', $mappedBLDeplStates)
            ->assign('mappedArchivedDeleted', isset($mappedArchivedDeleted[0]['isys_otrssync_mapped_deplstates__deplstate']) ? $mappedArchivedDeleted[0]['isys_otrssync_mapped_deplstates__deplstate'] : '')
            ->assign('idoitPurposes', $idoitPurposes)
            ->assign('idoitCMDBStatus', $idoitCMDBStatus)
            ->assign('activeAccordion', $activeAccordion)
            ->assign('otrsClasses', $otrsClasses)
            ->assign('notificationClass', $notificationClass)
            ->assign('notificationText', $notificationText)
            ->assign('icons_dir', self::get_icons_dir())
            ->assign('assets_dir', self::get_assets_dir());
        //include template of import as content of the site
        $index_includes['contentbottomcontent'] = self::get_tpl_dir() . 'import.tpl';
    }

    /**
     * Method implements logic for settingspage of the module
     *
     * @author  IT-NOVUM
     */
    protected function otrsAction_settings(){
        global $index_includes;
        $settingsArr = [];
        $notificationText = $notificationClass = '';
        $syncTimeBasedOptions = $this->dao->getSyncTimeBasedOptions();
        $changelogTimeBasedOptions = $this->dao->getChangelogTimeBasedOptions();
        $backupDir = __DIR__ . '/../../../../upload/files/';
        $url_value = $_POST['otrs-url'];
        $webservice_value = $_POST['otrs-webservice'];
        if (empty($_POST['otrs-create-action'])) {
            $create_value = "CreateCI";
        } else {
            $create_value = $_POST['otrs-create-action'];
        }

        if(empty($_POST['otrs-update-action'])) {
            $update_value = "UpdateCI";
        } else {
            $update_value = $_POST['otrs-update-action'];
        }

        if(empty($_POST['otrs-search-action'])){
            $search_value = "SearchCI";
        } else {
            $search_value = $_POST['otrs-search-action'];
        }

        $username_value = $_POST['otrs-username'];
        $password_value = $_POST['otrs-password'];
        $event_based_value = $_POST['otrs-event-based'];
        $time_based_value = $_POST['otrs-time-based'];
        $synchronisation_time_value = $_POST['otrs-synchronisation-time'];
        $changelog_time_value = $_POST['otrs-changelog-time'];
        $notify_mail_value = $_POST['otrs-notification-email'];
        $synchronisation_event_value = $_POST['otrs-synchronisation-event'];
        $idoit_api_url = $_POST['idoit-api-url'];
        $idoit_api_key = $_POST['idoit-api-key'];

        try{
            //check if a connection to OTRS could establish
            if (isset($_POST['otrs-test-connection'])) {
                if (empty($_POST['otrs-url']) || empty($_POST['otrs-username']) || empty($_POST['otrs-password']) || empty($_POST['otrs-webservice']) || empty($search_value))
                    throw new Exception(_L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__SETTINGS_OTRS'));

                $verArray = $this->otrs->checkApiVersion($_POST['otrs-url'], $_POST['otrs-username'], $_POST['otrs-password'], $_POST['otrs-webservice'], $search_value);
                if (!$verArray['success'])
                    throw new Exception($verArray['message']);

                $notificationText = _L('LC__MODULE__OTRSSYNC__OUTPUT__SUCCESS__CONNECTION');
                $notificationClass = 'success';
            //check if the module ist compatibility with the idoit version
            } else if($_POST['otrs-check-compatibilität']) {
                $checkResult = $this->dao->checkCompatibility();
                if (!$checkResult['check'])
                    throw new Exception($checkResult['fail']);

                $notificationText = _L('LC__MODULE__OTRSSYNC__OUTPUT__SUCCESS__COMPATIBILITY');
                $notificationClass = 'success';
            //if form is submitted check values and save them to db
            } else if(isset($_POST['otrs-send-mail'])) {
                if (empty($_POST['otrs-notification-email']))
                    throw new Exception(_L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__MAILSERVER__ADDRESS'));
                if (!$this->mailServer)
                    throw new Exception($this->mailServerText);

                $erg = $this->helper->send_email($_POST['otrs-notification-email'], "Schnittstelle idoit / OTRS", "Dies ist eine Testmail der it-novum idoit / OTRS Schnittstelle.");
                if ($erg){
                    $notificationText = _L('LC__MODULE__OTRSSYNC__OUTPUT__SUCCESS__SENDEMAIL');
                    $notificationClass = 'success';
                } else {
                    $notificationText = _L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__SENDEMAIL');
                    $notificationClass = 'error';
                }

            } else if(isset($_POST['otrs-backup'])) {
                $file = 'otrssync-settings-' . date('iHdmY') . '.bkp';
                $filename = $backupDir . $file;
                $myLink = fopen($filename, 'w');
                fwrite($myLink, $this->dao->exportConfig());
                fclose($myLink);
                $notificationText = $file._L('LC__MODULE__OTRSSYNC__OUTPUT__SUCCESS__BACKUP');
                $notificationClass = 'success';
            } else if(isset($_POST['otrs-restore'])) {
                $importFile = $_POST['otrs-backup-files'];
                $importData = file_get_contents($backupDir.$importFile);
                if ($this->dao->importConfig($importData)) {
                    $notificationText = $importFile._L('LC__MODULE__OTRSSYNC__OUTPUT__SUCCESS__RESTORE');
                    $notificationClass = 'success';
                    $settingsResArr = $this->dao->getSettings();

                    $url_value = $settingsResArr['otrs-url'];
                    $username_value = $settingsResArr['otrs-username'];
                    $password_value = $settingsResArr['otrs-password'];
                    $webservice_value = $settingsResArr['otrs-webservice'];
                    $create_value = $settingsResArr['otrs-create-action'];
                    $update_value = $settingsResArr['otrs-update-action'];
                    $search_value = $settingsResArr['otrs-search-action'];

                    if(array_key_exists('otrs-event-based', $settingsResArr)) {
                        $event_based_value = $settingsResArr['otrs-event-based'];
                        $synchronisation_event_value = $settingsResArr['otrs-synchronisation-event'];
                    }

                    if(array_key_exists('otrs-time-based', $settingsResArr)) {
                        $time_based_value = $settingsResArr['otrs-time-based'];
                        $synchronisation_time_value = $settingsResArr['otrs-synchronisation-time'];
                    }
                    $changelog_time_value = $settingsResArr['otrs-changelog-time'];
                    $notify_mail_value = $settingsResArr['otrs-notification-email'];

                }
            } else if(isset($_POST['otrs-delete-backup'])) {
                $backupFile = $_POST['otrs-backup-files'];
                unlink($backupDir.$backupFile);
                $notificationText = $backupFile._L('LC__MODULE__OTRSSYNC__OUTPUT__SUCCESS__DELETE_BACKUP');
                $notificationClass = 'success';
            } else if(isset($_POST['otrs-activate'])) {
                if($this->dao->ableToSync($_POST['otrs-license-key'])){
                    throw new Exception(_L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__NOT_ACTIVATED'));
                }
                $notificationText = _L('LC__MODULE__OTRSSYNC__OUTPUT__SUCCESS__ACTIVATED');
                $notificationClass = 'success';
            } else if(isset($_POST['otrs-save-settings']) || (isset($_POST['otrs-url']))){
                $settingsArr['otrs-url'] = trim($_POST['otrs-url']);
                $settingsArr['otrs-username'] = trim($_POST['otrs-username']);
                $settingsArr['otrs-password'] = trim($_POST['otrs-password']);
                $settingsArr['otrs-webservice'] = $_POST['otrs-webservice'];
                $settingsArr['otrs-create-action'] = $create_value;
                $settingsArr['otrs-update-action'] = $update_value;
                $settingsArr['otrs-search-action'] = $search_value;
                $settingsArr['idoit-api-url'] = trim($_POST['idoit-api-url']);
                $settingsArr['idoit-api-key'] = trim($_POST['idoit-api-key']);

                if ($_POST['otrs-event-based'] === 'on' && !empty($_POST['otrs-synchronisation-event'])) {
                    $settingsArr['otrs-event-based'] = $_POST['otrs-event-based'];
                    $cnt = 1;
                    foreach($_POST['otrs-synchronisation-event'] as $item) {
                        $settingsArr['otrs-synchronisation-event-'.$cnt++] = $item;
                    }
                }

                if ($_POST['otrs-time-based'] === 'on') {
                    $settingsArr['otrs-time-based'] = $_POST['otrs-time-based'];
                    $settingsArr['otrs-synchronisation-time'] = $_POST['otrs-synchronisation-time'];

                }

                $settingsArr['otrs-changelog-time'] = $_POST['otrs-changelog-time'];
                $settingsArr['otrs-notification-email'] = $_POST['otrs-notification-email'];

                $settingsArr['idoit-url'] = $_SERVER['HTTP_REFERER'];
                $saveRes = $this->dao->setSettings($settingsArr);

                if (!$saveRes['success'])
                    throw new Exception($saveRes['message']);

                $notificationText = _L('LC__MODULE__OTRSSYNC__OUTPUT__SUCCESS__SAVE');
                $notificationClass = 'success';

                $this->helper->createCronJob("changelog", 'day', $_POST['otrs-changelog-time'] === 'forever' ? true : false);
                $this->helper->createCronJob("synchronise",$_POST['otrs-synchronisation-time'], $_POST['otrs-time-based'] === 'on' ? false : true);

                $this->dao->writeChangelog("Save Settings by User " . $this->userObj->get_user_title($this->userObj->get_current_user_id()), $this->userObj->get_current_user_id(), Dao::TYPE_SAVE_SETTINGS);
            //read settings from db if settingspage is opened and form is not submitted
            } else {
                $settingsResArr = $this->dao->getSettings();
                $otrsSync = !$this->otrs->exportOtrsData($settingsResArr['otrs-sync-data']);
                if($otrsSync){
                    $rr = $this->dao->getLastSyncDateOTRS('o11az');
                    $otrsSync = $rr > 0;
                }
                $url_value = $settingsResArr['otrs-url'];
                $username_value = $settingsResArr['otrs-username'];
                $password_value = $settingsResArr['otrs-password'];
                $webservice_value = $settingsResArr['otrs-webservice'];
                $create_value = $settingsResArr['otrs-create-action'];
                $update_value = $settingsResArr['otrs-update-action'];
                $search_value = $settingsResArr['otrs-search-action'];
                $idoit_api_url = $settingsResArr['idoit-api-url'];
                $idoit_api_key = $settingsResArr['idoit-api-key'];

                if(array_key_exists('otrs-event-based', $settingsResArr)) {
                    $event_based_value = $settingsResArr['otrs-event-based'];
                    $synchronisation_event_value = $settingsResArr['otrs-synchronisation-event'];
                }

                if(array_key_exists('otrs-time-based', $settingsResArr)) {
                    $time_based_value = $settingsResArr['otrs-time-based'];
                    $synchronisation_time_value = $settingsResArr['otrs-synchronisation-time'];
                }
                $changelog_time_value = $settingsResArr['otrs-changelog-time'];
                $notify_mail_value = $settingsResArr['otrs-notification-email'];
            }

        }catch (Exception $otrsE){
            $notificationClass = 'error';
            $notificationText = $otrsE->getMessage();
        }

        $backupFiles = scandir($backupDir);
        $backupFiles = array_filter($backupFiles, function($name) {
            return stripos($name, "otrssync-settings-") !== false;
        });
        //hand over variables to template of settings for representation
        $this->m_tpl
            ->assign('syncTimeBasedOptions', $syncTimeBasedOptions)
            ->assign('changelogTimeBasedOptions', $changelogTimeBasedOptions)
            ->assign('notificationClass', $notificationClass)
            ->assign('notificationText', $notificationText)
            ->assign('backupFiles', $backupFiles)
            ->assign('urlBase', \isys_core::request_url())
            ->assign('assets_dir', self::get_assets_dir())
            ->assign('url_value', isset($url_value) ? $url_value : "")
            ->assign('webservice_value', isset($webservice_value) ? $webservice_value : "")
            ->assign('create_value', isset($create_value) ? $create_value : "")
            ->assign('update_value', isset($update_value) ? $update_value : "")
            ->assign('search_value', isset($search_value) ? $search_value : "")
            ->assign('otrsSync', $otrsSync && !empty($settingsResArr['otrs-sync-data']))
            ->assign('idoit_api_url', isset($idoit_api_url) ? $idoit_api_url : "")
            ->assign('idoit_api_key', isset($idoit_api_key) ? $idoit_api_key : "")
            ->assign('username_value', isset($username_value) ? $username_value : "")
            ->assign('password_value', isset($password_value) ? $password_value : "")
            ->assign('event_based_value', (isset($event_based_value) && $event_based_value === 'on') ? 'checked' : '')
            ->assign('time_based_value', (isset($time_based_value) && $time_based_value === 'on') ? 'checked' : '')
            ->assign('synchronisation_time_value', isset($synchronisation_time_value) ? $synchronisation_time_value : "")
            ->assign('changelog_time_value', isset($changelog_time_value) ? $changelog_time_value : "")
            ->assign('notify_mail_value', isset($notify_mail_value) ? $notify_mail_value : "")
            ->assign('synchronisation_event_value', (isset($synchronisation_event_value) && is_array($synchronisation_event_value)) ? $synchronisation_event_value : []);
        //include template of settings as content of the site
        $index_includes['contentbottomcontent'] = self::get_tpl_dir() . 'settings.tpl';
    }

    /**
     * Method implements logic for changelogpage of the module
     *
     * @author  IT-NOVUM
     */
    protected function otrsAction_changelog(){
        global $index_includes;
        $changelogArr = [];
        $exportFile = __DIR__."/../../../../temp/export.txt";
        $exportLink = "temp/export.txt";
        $from = date("d.m.Y");
        $to = date("d.m.Y");
        $notificationClass =  $notificationText = "";
        try{
            //if form was submitted read start and end time and select changelod for timerange from db
            if(isset($_POST['otrs-clear-changelog'])){
                if(!$this->dao->clearChangelog()){
                    throw new Exception(_L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__CLEAR_CHANGELOG'));
                }
            }elseif (isset($_POST['otrs-show-changelog']) || isset($_POST['otrs-changelog-from'])) {
                $from = trim($_POST['otrs-changelog-from']);
                $to = trim($_POST['otrs-changelog-to']);
                if (empty($from) || empty($to))
                    throw new Exception(_L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__TIMESPAN'));
            }
            $changelog = $this->dao->getChangelog($from, $to);
            $prevTime = 0;
            $class = 0;

            $df = fopen($exportFile, 'w');
            fwrite($df, "Export Changelog \n\n");

            foreach($changelog->__as_array() as $item) {
                if($prevTime - strtotime($item['isys_otrssync_changelog__timestamp']) > 1){
                    ++$class;
                }

                fwrite($df, $item['isys_otrssync_changelog__timestamp']." ".$item['isys_otrssync_changelog__action']."\n");

                $changelogArr[] = [
                    'action' => $item['isys_otrssync_changelog__timestamp']." ".$item['isys_otrssync_changelog__action'],
                    'class' => $class
                ];
                $prevTime = strtotime($item['isys_otrssync_changelog__timestamp']);

            }

            fclose($df);

        }catch (Exception $otrsE){
            $notificationClass = 'error';
            $notificationText = $otrsE->getMessage();
        }
        //hand over variables to template of changelog fpr representation
        $this->m_tpl
            ->assign('notificationClass', $notificationClass)
            ->assign('notificationText', $notificationText)
            ->assign('changelogArr', $changelogArr)
            ->assign('from', $from)
            ->assign('to', $to)
            ->assign('exportLink', $exportLink)
            ->assign('assets_dir', self::get_assets_dir());
        //include template of changelog as content of the site
        $index_includes['contentbottomcontent'] = self::get_tpl_dir() . 'changelog.tpl';
    }

    /**
     * Method implements logic for manual of the module
     *
     * @author  IT-NOVUM
     */
    protected function otrsAction_manual(){
        global $index_includes;
        $lang = _L('LC__MODULE__OTRSSYNC_LANG');
        //hand over variables to template of changelog fpr representation
        $this->m_tpl
            ->assign('images_dir', self::get_images_dir())
            ->assign('lang', $lang)
            ->assign('assets_dir', self::get_assets_dir());
        //include template of changelog as content of the site
        $index_includes['contentbottomcontent'] = self::get_tpl_dir() . 'manual.tpl';
    }

    /**
     * Method returns the authentification for the module
     *
     * @author  IT-NOVUM
     */
    public static function get_auth()
    {
        return isys_auth_otrssync::instance();
    }

}
