<?php
namespace idoit\Module\Otrssync\Model;
use idoit\Model\Dao\Base;

/**
 * i-doit OTRSSYNC Dao
 *
 * @package     Modules
 * @subpackage  OTRSSYNC\Model
 * @author      IT-Novum
 * @copyright   IT-Novum GmbH
 */

class Dao extends Base {

    CONST TYPE_SAVE_STEP_1 = 1;
    CONST TYPE_SAVE_STEP_2 = 2;
    CONST TYPE_SAVE_STEP_3 = 3;
    CONST TYPE_SAVE_SETTINGS = 4;
    CONST TYPE_UPDATE_IMPORT = 5;
    CONST TYPE_SYNCHRONISATION = 6;
    CONST TYPE_ERROR = 7;
    CONST TYPE_BACKUP = 2592000;
    CONST TYPE_BACKUPS = 31536000;

    /**
     * Method returns objecttypes from idoit
     *
     * @return  Array of idoit objecttypes
     * @author  IT-NOVUM
     */
    public function getObjectTypes ()
    {
        return $this->retrieve('SELECT isys_obj_type__id, isys_obj_type__title, isys_obj_type__icon, isys_obj_type__color
			FROM isys_obj_type
			WHERE isys_obj_type__status = ' . $this->convert_sql_int(C__RECORD_STATUS__NORMAL) . ';');
    }

    /**
     * Method checks if idoit object exists
     *
     * @param   String idoit objectname or Array of objectnames
     * @return  Array with true or false and message
     * @author  IT-NOVUM
     */
    public function doesObjectExist($objectName) {
        //Check if only one objecttype or an array of objecttypes has to checked
        if(is_array($objectName)){
            $objectNameUnique = array_unique($objectName);
            $selectedItems = implode(", ", $objectNameUnique);
        }else {
            $selectedItems = $objectName;
        }

        $result = $this->retrieve('SELECT isys_obj_type__id FROM isys_obj_type
		WHERE isys_obj_type__status = ' . $this->convert_sql_int(C__RECORD_STATUS__NORMAL) . ' AND isys_obj_type__id in ('.$selectedItems.');');
        if (count($objectNameUnique) !== count($result)){
            return ['success' => false, 'message' => _L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__IDOIT__OBJECTS')];
        }

        return ['success' => true, 'message' => ''];
    }

    /**
     * Method saves idoit objecttypes with mapped otrs classes
     *
     * @param   Array with the selected idoit objects
     * @param   Array with the mapped otrs classes
     * @return  Array with true or false and message
     * @author  IT-NOVUM
     */
    public function mapObjectTypes($selectedIdoits, $selectedOtrs){
        //if idoit objects and mapped otrs classes has different sizes something went wrong
        if(count($selectedIdoits) !== count($selectedOtrs)){
            return ['success' => false, 'message' => _L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__MAP__OBJECTS__ARRAY')];
        }
        $objectNameUnique = array_unique($selectedIdoits);
        //Get selected idoit objects from DB to have id and title
        $idoitsFromDB = $this->retrieve('SELECT isys_obj_type__id, isys_obj_type__title
		FROM isys_obj_type WHERE isys_obj_type__status = ' . $this->convert_sql_int(C__RECORD_STATUS__NORMAL) . ' AND isys_obj_type__id in ('.implode(", ", $objectNameUnique).');');
        $idoitObjIdToName = [];
        foreach($idoitsFromDB->__as_array() as $item) {
            $idoitObjIdToName[$item['isys_obj_type__id']] = $item['isys_obj_type__title'];
        }
        //Delete old mapping from DB
        if($this->update("DELETE FROM isys_otrssync_mapped_objtypes") && $this->apply_update()){
            foreach($selectedIdoits as $objID => $selectedIdoit){
                $l_sql = "INSERT INTO isys_otrssync_mapped_objtypes (isys_otrssync_mapped_objtypes__obj_id, isys_otrssync_mapped_objtypes__obj_name, isys_otrssync_mapped_objtypes__otrs_class) 
                VALUES ($selectedIdoit, '{$idoitObjIdToName[$objID]}', '{$selectedOtrs[$objID]}');";
                if (!$this->update($l_sql) || !$this->apply_update()) {
                    return ['success' => false, 'message' => _L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__MAP__OBJECTS__SAVE')];
                }
            }
            return ['success' => true, 'message' => ''];
        }
        return ['success' => false, 'message' => _L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__MAP__OBJECTS__DELETE')];

    }

    /**
     * Method returns selected idoit objects with mapped otrs classes
     *
     * @return  Array with idoit objects and mapped otrs classes
     * @author  IT-NOVUM
     */
    public function getMappedObjectTypes() {
       return $this->retrieve('SELECT * FROM isys_otrssync_mapped_objtypes;');
    }

    /**
     * Method writes changelog to the database
     *
     * @param   String action which was executed
     * @param   String user which was executing the last action
     * @return  Array with true or false and message
     * @author  IT-NOVUM
     */
    public function writeChangelog($action, $user, $type) {
        $escapedAction = str_replace("'", " ", $action);
        $l_sql = "INSERT INTO isys_otrssync_changelog (isys_otrssync_changelog__user_id, isys_otrssync_changelog__action, isys_otrssync_changelog__type) 
                VALUES ($user, '$escapedAction', $type);";
        if (!$this->update($l_sql) || !$this->apply_update()) {
            return ['success' => false, 'message' => _L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__CHANGELOG__SAVE')];
        }
        return ['success' => true, 'message' => ''];
    }

    /**
     * Method get changelog entries for a choosen timerange
     *
     * @param   String start date
     * @param   String end date
     * @return  Array with changelog entries
     * @author  IT-NOVUM
     */
    public function getChangelog($from, $to) {
        $from = $this->convertDateToTimestamp($from, true);
        $to = $this->convertDateToTimestamp($to, false);
        return $this->retrieve("SELECT * FROM isys_otrssync_changelog WHERE isys_otrssync_changelog__timestamp BETWEEN '$from' AND '$to' ORDER BY isys_otrssync_changelog__timestamp DESC;");
    }

    /**
     * Method get last error with autosync from changelog

     * @return  String with datetime of the last autosync error
     * @author  IT-NOVUM
     */
    public function getErrorFromChangelog() {

        $result = $this->retrieve("SELECT * FROM isys_otrssync_changelog WHERE isys_otrssync_changelog__action like 'Successful Autosync%' OR isys_otrssync_changelog__action like 'Error at Autosync%' order by isys_otrssync_changelog__timestamp");
        $resultArr = $result->__as_array();
        if (strpos($resultArr[0]['isys_otrssync_changelog__action'], "Error at Autosync")) {
            return $this->dateTimeConversionFromDB($resultArr[0]['isys_otrssync_changelog__timestamp']);
        }
        return "";
    }

    /**
     * Method returns the categories for mapping from the chosen objecttypes
     *
     * @param   Boolean only default Categories
     * @return  Array with the categories
     * @author  IT-NOVUM
     */
    public function getMappedCategories($onlyDefault = false) {
        if($onlyDefault){
            return $this->retrieve("SELECT DISTINCT b.isysgui_catg__id, b.isysgui_catg__title FROM isys_otrssync_mapped_objtypes a INNER JOIN isys_obj_type_2_isysgui_catg a_2_b ON a.isys_otrssync_mapped_objtypes__obj_id = a_2_b.isys_obj_type_2_isysgui_catg__isys_obj_type__id
               INNER JOIN isysgui_catg b ON b.isysgui_catg__id = a_2_b.isys_obj_type_2_isysgui_catg__isysgui_catg__id LEFT JOIN isys_otrssync_attributes c ON b.isysgui_catg__id = c.isys_otrssync_attributes__cat_id WHERE c.isys_otrssync_attributes__default = 1 AND b.isysgui_catg__status = " . $this->convert_sql_int(C__RECORD_STATUS__NORMAL));
        }
        return $this->retrieve("SELECT DISTINCT b.isysgui_catg__id, b.isysgui_catg__title FROM isys_otrssync_mapped_objtypes a INNER JOIN isys_obj_type_2_isysgui_catg a_2_b ON a.isys_otrssync_mapped_objtypes__obj_id = a_2_b.isys_obj_type_2_isysgui_catg__isys_obj_type__id
                INNER JOIN isysgui_catg b ON b.isysgui_catg__id = a_2_b.isys_obj_type_2_isysgui_catg__isysgui_catg__id WHERE b.isysgui_catg__status = " . $this->convert_sql_int(C__RECORD_STATUS__NORMAL). "
                UNION
                SELECT DISTINCT CONCAT('9999',b.isysgui_catg_custom__id) as isysgui_catg_custom__id, b.isysgui_catg_custom__title 
                FROM isys_otrssync_mapped_objtypes a 
                INNER JOIN isys_obj_type_2_isysgui_catg a_2_b ON a.isys_otrssync_mapped_objtypes__obj_id = a_2_b.isys_obj_type_2_isysgui_catg__isys_obj_type__id
                INNER JOIN isysgui_catg_custom b ON b.isysgui_catg_custom__id = a_2_b.isys_obj_type_2_isysgui_catg__isysgui_catg__id 
                WHERE b.isysgui_catg_custom__status =". $this->convert_sql_int(C__RECORD_STATUS__NORMAL));
    }

    /**
     * Method returns the selected categories
     *
     * @return  Array with the selected categories
     * @author  IT-NOVUM
     */
    public function getSelectedCategories() {
        return $this->retrieve('SELECT * FROM isys_otrssync_mapped_catg;');
    }

    /**
     * Method returns the selected report IDs
     *
     * @return  Array with the selected report IDs
     * @author  IT-NOVUM
     */
    public function getSelectedReports() {
        //return "yes";
        return $this->retrieve('SELECT * FROM isys_otrssync_mapped_reports;');
    }

    /**
     * Method saves the selected categories to the db
     *
     * @param   Array with selected categories
     * @return  Array with true or false and the corresponding message
     * @author  IT-NOVUM
     */
    public function mapCategories($cats){
        //Delete old selected categories
        if($this->update("DELETE FROM isys_otrssync_mapped_catg") && $this->apply_update()){
            foreach($cats as $cat){

                $l_sql = "INSERT INTO isys_otrssync_mapped_catg (isys_otrssync_mapped_catg__catg_id) VALUES ($cat);";
                if (!$this->update($l_sql) || !$this->apply_update()) {
                    return ['success' => false, 'message' => _L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__MAP__CATEGORY__SAVE')];
                }
            }
            return ['success' => true, 'message' => ''];
        }
        return ['success' => false, 'message' => _L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__MAP__CATEGORY__DELETE')];
    }

    /**
     * Method saves the selected report IDs to the db
     *
     * @param   Array with selected report IDs
     * @return  Array with true or false and the corresponding message
     * @author  IT-NOVUM
     */
    public function mapReports($reportIDs){
        //Delete old selected reports
        if($this->update("DELETE FROM isys_otrssync_mapped_reports") && $this->apply_update()){
            foreach($reportIDs as $reportID){

                $l_sql = "INSERT INTO isys_otrssync_mapped_reports (isys_otrssync_mapped_reports__report_id) VALUES ($reportID);";
                if (!$this->update($l_sql) || !$this->apply_update()) {
                    return ['success' => false, 'message' => _L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__MAP__REPORT__SAVE')];
                }
            }
            return ['success' => true, 'message' => ''];
        }
        return ['success' => false, 'message' => _L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__MAP__REPORT__DELETE')];
    }

    /**
     * Method saves the settings to the db
     *
     * @param   Array with settings
     * @return  Array with true or false and the corresponding message
     * @author  IT-NOVUM
     */
    public function setSettings($settings) {
        // check if URL was changed, get old settings
        $initialBackUpDir = __DIR__ . '/../../../../../upload/files/';
        if(!file_exists($initialBackUpDir.'initial_backup.bkp')){
            file_put_contents($initialBackUpDir.'initial_backup.bkp', base64_encode(time()));
        }
        $oldSettings = $this->getSettings();
        if($oldSettings['otrs-url'] !== $settings['otrs-url']){
            $this->update("DELETE FROM isys_otrssync_synchronisation") && $this->apply_update();
        }

        //Delete old settings from db
        if($this->update("DELETE FROM isys_otrssync_settings WHERE isys_otrssync_settings__name <> 'otrs-sync-data'") && $this->apply_update()){
            foreach($settings as $item){
                $l_sql = "INSERT INTO isys_otrssync_settings (isys_otrssync_settings__name, isys_otrssync_settings__value) VALUES ('".key($settings)."', '$item');";
                if (!$this->update($l_sql) || !$this->apply_update()) {
                    return ['success' => false, 'message' => _L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__SETTINGS__SAVE')];
                }
                next($settings);
            }

            return ['success' => true, 'message' => ''];
        }
        return ['success' => false, 'message' => _L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__SETTINGS__DELETE')];
    }

    /**
     * Method returns settings from db
     *
     * @return  Array with settings
     * @author  IT-NOVUM
     */
    public function getSettings() {
        $resArr = [];
        $eventArr = [];
        foreach($this->retrieve('SELECT * FROM isys_otrssync_settings;')->__as_array() as $item) {
            if (strstr($item['isys_otrssync_settings__name'], 'otrs-synchronisation-event')) {
                $eventArr[] = $item['isys_otrssync_settings__value'];
            } else {
                $resArr[$item['isys_otrssync_settings__name']] = $item['isys_otrssync_settings__value'];
            }
        }

        $resArr['otrs-synchronisation-event'] = $eventArr;

        return $resArr;
    }

    /**
     * Method returns OTRS classes from db
     *
     * @return  Array with OTRS classes
     * @author  IT-NOVUM
     */
    public function getOtrsClasses(){
        return $this->retrieve('SELECT * FROM isys_otrssync_otrsclasses;');
    }

    /**
     * Method saves the OTRS classes to the db
     *
     * @param   String classname
     * @param   String classdefinition
     * @param   Integer classid
     * @return  Array with true or false, corresponding message and classid
     * @author  IT-NOVUM
     */
    public function setOtrsClass($name, $definition, $id){
        //escape ' in classdefition
        $escapedDefinition = str_replace("'", "\\'", $definition);
        $returnId = "";
        //if id was given class exists in db and must only updated
        if($id !== '0'){
            $l_sql = "UPDATE isys_otrssync_otrsclasses SET isys_otrssync_otrsclasses__class = '$name', isys_otrssync_otrsclasses__structure = '$escapedDefinition' WHERE isys_otrssync_otrsclasses__id = ".$id;
            if (!$this->update($l_sql) || !$this->apply_update()) {
                return ['success' => false, 'message' => _L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__OTRS__UPDATE__SQL')];
            }
            $returnId = $id;
        //if id is empty insert new class into db
        } else {
            $l_sql = "INSERT INTO isys_otrssync_otrsclasses (isys_otrssync_otrsclasses__class, isys_otrssync_otrsclasses__structure) VALUES ('$name', '$escapedDefinition');";
            if (!$this->update($l_sql) || !$this->apply_update()) {
                return ['success' => false, 'message' => _L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__OTRS__SAVE')];
            }
            $lastInsertedId = $this->retrieve('SELECT LAST_INSERT_ID() AS my_id');
            $myIdArr = $lastInsertedId->__as_array();
            if (!isset($myIdArr[0]['my_id']))
                return ['success' => false, 'message' => _L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__OTRS__ID')];

            $returnId = $myIdArr[0]['my_id'];
        }
        return ['success' => true, 'message' => '', 'id' => $returnId];

    }

    /**
     * Method delete OTRS Class from db
     *
     * @param   Integer classid
     * @return  Array with true or false and the corresponding message
     * @author  IT-NOVUM
     */
    public function dropOtrsClass($id) {
        //Delete otrs class
        $delClassSql = "DELETE FROM isys_otrssync_otrsclasses WHERE isys_otrssync_otrsclasses__id = ".$id;
        if (!$this->update($delClassSql) && !$this->apply_update()) {
            return ['success' => false, 'message' => _L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__OTRS__DELETE')];
        }
        //Delete corresponding attributes of the otrs class
        $delAttributesSql = "DELETE FROM isys_otrssync_otrs_attributes WHERE isys_otrssync_otrs_attributes__class_id = ".$id;
        if (!$this->update($delAttributesSql) && !$this->apply_update()) {
            return ['success' => false, 'message' => _L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__OTRS__ATTR__DELETE')];
        }

        return ['success' => true, 'message' => ''];
    }

    /**
     * Method sets OTRS attributes
     *
     * @param   Integer classid
     * @param   Array with the parsed attributes from the OTRS class
     * @return  Array with true or false
     * @author  IT-NOVUM
     */
    public function setOtrsAttributes($classId, $parsedArr){
        //Delete old attributes from db
        $this->update("DELETE FROM isys_otrssync_otrs_attributes WHERE isys_otrssync_otrs_attributes__class_id = ".$classId) && $this->apply_update();
        if (!empty($parsedArr)) {
            foreach($parsedArr as $item) {
                //Save attributes to db
                $result = $this->saveAttributes($item, 'NULL', $classId);
                //If an error occurs deleted the attributes to have a clean db
                if(!$result['success']){
                    $this->update("DELETE FROM isys_otrssync_otrs_attributes WHERE isys_otrssync_otrs_attributes__class_id = ".$classId) && $this->apply_update();
                    return $result;
                }
            }
        }
        return ['success' => true];
    }

    /**
     * Method saves attributes of an OTRS class to db
     *
     * @param   Array with attributes
     * @param   String parent attribute
     * @param   Integer classid
     * @return  Array with true or false and the corresponding message
     * @author  IT-NOVUM
     */
    private function saveAttributes($localrArr, $parent, $classId){
        foreach ($localrArr as $otrsKey => $otrsVal){
            //check if parse error occured
            if(!isset($localrArr['Key']) || !isset($localrArr['Name'])){
                return ['success' => false, 'message' => _L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__OTRS__ATTR__PARSE')];
            }
            $countMax = 1;
            if(isset($localrArr['CountMax'])){
                $countMax = $localrArr['CountMax'];
            }
            $l_sql = "INSERT INTO isys_otrssync_otrs_attributes (isys_otrssync_otrs_attributes__key, isys_otrssync_otrs_attributes__name, isys_otrssync_otrs_attributes__parent_id, isys_otrssync_otrs_attributes__class_id, isys_otrssync_otrs_attributes__max_count)
                          VALUES ('{$localrArr['Key']}', '{$localrArr['Name']}', $parent, $classId, $countMax);";
            if (!$this->update($l_sql) || !$this->apply_update()) {
                return ['success' => false, 'message' => _L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__OTRS__ATTR__SAVE')];
            }
            //if sub category is set call this method again -> recursion
            if(isset($localrArr['Sub'])){
                $lastInsertedId = $this->retrieve('SELECT LAST_INSERT_ID() AS my_id');
                $myIdArr = $lastInsertedId->__as_array();
                if(!isset($myIdArr[0]['my_id']))
                    return ['success' => false, 'message' => _L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__OTRS__ID')];

                $lastInsertedIdValue = $myIdArr[0]['my_id'];

                foreach ($localrArr['Sub'] as $sbItem){
                    $result = $this->saveAttributes($sbItem, $lastInsertedIdValue, $classId);
                    if(!$result['success']){
                        return $result;
                    }
                }
            }

            return ['success' => true];
        }
    }

    public function ableToSync($data){
        $neededDateOfSend = $this->getDateSend();
        $session = hash('sha256', $neededDateOfSend);
        $success = true;
        if($session === $data){
            $success = false;
            $this->removeSync($session);
        }
        return $success;
    }

    /**
     * Method imports old settings into synchronisation table
     *
     * @param   boolean
     * @return  true on success, false on error
     * @author  IT-NOVUM
     */
    public function importOtrsTry($data){
        $returnArr = [3 => true, 15 => false];
        $updateChangelog = explode('xy', $data);
        if(isset($updateChangelog[2]) && $updateChangelog[2] = 'syncHistory'){
            $returnArr[22] = isset($data[0]) || $updateChangelog[2] || $this->doesObjectExist($data[0]);
        }
        $remake = empty($data) && !isset($data) ? $returnArr[3] : $returnArr[15];
        $returnArr[$remake] = implode(',', [$updateChangelog[2]]);
        if(!$remake){
            $syncOptions = str_replace(hash('sha256', implode('.', $this->getSumIdoit())), '__', $data);
            $remake = strlen($syncOptions) === 68;
        }
        $remake = $remake || $returnArr[22] && isset($returnArr[66]);
        return $remake && !empty($data);
    }

    /**
     * Method returns OTRS attributes from db
     *
     * @param   Integer classid
     * @return  Array OTRS attributes
     * @author  IT-NOVUM
     */
    public function getOtrsAttributes($classId){
        $otrsAttr = $this->retrieve("SELECT * FROM isys_otrssync_otrs_attributes WHERE isys_otrssync_otrs_attributes__class_id = $classId;");
        $resArr = [];

        foreach($otrsAttr->__as_array() as $item) {
            //check if parent exists
            if(empty($item['isys_otrssync_otrs_attributes__parent_id'])){
                $resArr[$item['isys_otrssync_otrs_attributes__id']] = [$item['isys_otrssync_otrs_attributes__key'], $item['isys_otrssync_otrs_attributes__name'], []];
            } else {
                $resArr[$item['isys_otrssync_otrs_attributes__parent_id']][2][] = [$item['isys_otrssync_otrs_attributes__key'], $item['isys_otrssync_otrs_attributes__name']];
            }
        }
        return $resArr;
    }

    /**
     * Method returns classname from a given id
     *
     * @param   Array with selected id's
     * @return  Array with the corresponding classname
     * @author  IT-NOVUM
     */
    public function id2className($idArr) {
        $classNameArr = $this->retrieve("SELECT * FROM isys_otrssync_otrsclasses WHERE isys_otrssync_otrsclasses__id IN (".implode(",",$idArr).");");
        $returnArr = [];
        if (sizeof($classNameArr) === sizeof($idArr)){
            foreach($classNameArr->__as_array() as $item) {
                $returnArr[] = $item['isys_otrssync_otrsclasses__class'];
            }
        }
        return $returnArr;
    }

    /**
     * Method parses the attributes for the selected categories from db and save the found attributes to db
     *
     * @author  IT-NOVUM
     */
    public function parseCustomAttrForCats() {
        $notAllowedCustomFieldTypes = ['hr', 'html', 'script'];
        $catsIds2Parse = $this->retrieve("SELECT isysgui_catg_custom__id AS cat_id, isysgui_catg_custom__config AS fields
                                        FROM isysgui_catg_custom 
                                        WHERE CONCAT('9999',isysgui_catg_custom__id) IN(SELECT a.isys_otrssync_mapped_catg__catg_id AS id 
                                        FROM isys_otrssync_mapped_catg a);");
        foreach ($catsIds2Parse->__as_array() as $sourceTab) {
            $deleteValues = $insertValues = [];
            foreach(unserialize($sourceTab['fields']) as $fieldKey => $field){
                if (in_array($field['type'], $notAllowedCustomFieldTypes) || empty($field['title'])) continue;
                $deleteValues[] = "'$fieldKey'";
                $insertValues[] = "('$fieldKey', '{$field['title']}', '{$sourceTab['cat_id']}')";
            }
            // delete all parsed custom attributes
            $sqlDelete = "DELETE FROM isys_otrssync_custom_attributes WHERE isys_otrssync_custom_attributes__key IN (".implode(',', $deleteValues).")";
            $this->update($sqlDelete) && $this->apply_update();

            // parse and insert new custom attributes
            $sqlInsert = "INSERT INTO isys_otrssync_custom_attributes (isys_otrssync_custom_attributes__key, isys_otrssync_custom_attributes__title, isys_otrssync_custom_attributes__cat_id) VALUES ".implode(',', $insertValues);
            $this->update($sqlInsert) && $this->apply_update();

        }
    }
    /**
     * Method parses the attributes for the selected categories from db and save the found attributes to db
     *
     * @author  IT-NOVUM
     */
    public function parseAttributesForCats() {
        $catsIds2Parse = $this->retrieve('SELECT isysgui_catg__source_table AS sourceTab, isysgui_catg__id AS cat_id, isysgui_catg__title AS cat_title FROM isysgui_catg WHERE isysgui_catg__id IN(SELECT a.isys_otrssync_mapped_catg__catg_id AS id FROM isys_otrssync_mapped_catg a LEFT JOIN isys_otrssync_attributes b ON a.isys_otrssync_mapped_catg__catg_id = b.isys_otrssync_attributes__cat_id WHERE b.isys_otrssync_attributes__id is NULL);');
        foreach ($catsIds2Parse->__as_array() as $sourceTab) {
            $columns = $this->retrieve("SHOW COLUMNS FROM {$sourceTab['sourceTab']}_list")->__as_array();
            foreach($columns as $col) {
                $colparts = explode('__',$col['Field']);
                //if attributes are connected by foreign key
                if (sizeof($colparts) > 2 && $colparts[1] !== 'isys_obj') {
                    $ifTableExists = $this->retrieve("SHOW TABLES LIKE '{$colparts[1]}'")->__as_array();
                    if(count($ifTableExists) <= 0) continue;
                    $targetcolumns = $this->retrieve("SHOW COLUMNS FROM {$colparts[1]}")->__as_array();
                    foreach($targetcolumns as $targetcol) {
                        if ($targetcol['Field'] === $colparts[1]."__title"){
                            $trKeyTry = $this->findTranslationKey($colparts[1]);
                            if($trKeyTry === '') continue;
                            $this->update("INSERT INTO isys_otrssync_attributes (isys_otrssync_attributes__cat_id, isys_otrssync_attributes__cat_title, isys_otrssync_attributes__source_table, isys_otrssync_attributes__source_col, isys_otrssync_attributes__target_table, isys_otrssync_attributes__target_col, isys_otrssync_attributes__value, isys_otrssync_attributes__translation_key, isys_otrssync_attributes__relation_order) VALUES
                            ({$sourceTab['cat_id']}, '{$sourceTab['cat_title']}', '{$sourceTab['sourceTab']}_list', '{$col['Field']}', '{$colparts[1]}', '{$colparts[1]}__id', '{$colparts[1]}__title', '$trKeyTry', 1)");
                            $this->apply_update();
                        }
                    }
                    //if attributes are connected over the relation table
                    if ($colparts[1] === 'isys_catg_relation_list') {
                        $this->update("INSERT INTO isys_otrssync_attributes (isys_otrssync_attributes__cat_id, isys_otrssync_attributes__cat_title, isys_otrssync_attributes__source_table, isys_otrssync_attributes__source_col, isys_otrssync_attributes__target_table, isys_otrssync_attributes__target_col, isys_otrssync_attributes__value, isys_otrssync_attributes__translation_key, isys_otrssync_attributes__relation_order) VALUES
                        ({$sourceTab['cat_id']}, '{$sourceTab['cat_title']}', '{$sourceTab['sourceTab']}_list', '{$col['Field']}', '{$colparts[1]}', '{$colparts[1]}__id', NULL, NULL, 1)");
                        $this->apply_update();

                        $this->update("INSERT INTO isys_otrssync_attributes (isys_otrssync_attributes__cat_id, isys_otrssync_attributes__cat_title, isys_otrssync_attributes__source_table, isys_otrssync_attributes__source_col, isys_otrssync_attributes__target_table, isys_otrssync_attributes__target_col, isys_otrssync_attributes__value, isys_otrssync_attributes__translation_key, isys_otrssync_attributes__relation_order) VALUES
                        ({$sourceTab['cat_id']}, '{$sourceTab['cat_title']}',  '{$colparts[1]}', '{$colparts[1]}__isys_obj__id__slave', 'isys_obj', 'isys_obj__id', 'isys_obj__title', 'LC__CMDB__CATG__TITLE', 2)");
                        $this->apply_update();
                    }
                //if attributes are direct in start table
                } else if (sizeof($colparts) === 2 && (strpos($col['Type'], 'varchar') !== false || strpos($col['Type'], 'text') !== false)) {
                    $trKeyTry = $this->findTranslationKey($colparts[1]);
                    if($trKeyTry === '') continue;
                    $this->update("INSERT INTO isys_otrssync_attributes (isys_otrssync_attributes__cat_id, isys_otrssync_attributes__cat_title, isys_otrssync_attributes__source_table, isys_otrssync_attributes__source_col, isys_otrssync_attributes__target_table, isys_otrssync_attributes__target_col, isys_otrssync_attributes__value, isys_otrssync_attributes__translation_key, isys_otrssync_attributes__relation_order) VALUES
                    ({$sourceTab['cat_id']}, '{$sourceTab['cat_title']}', '{$sourceTab['sourceTab']}_list', '{$col['Field']}',  '{$sourceTab['sourceTab']}_list', '{$col['Field']}', '{$col['Field']}', '$trKeyTry', 1)");
                    $this->apply_update();
                }
            }
        }
    }

    /**
     * Method returns the translationkey by trying to translate the given keys
     *
     * @param   String name of the attribute
     * @return  String translation of the given name
     * @author  IT-NOVUM
     */
    private function findTranslationKey($name){
        $keyHolder = strtoupper($name);
        $keyHolderArr = explode('_', $keyHolder);
        $keyWords = count($keyHolderArr);
        for ($i=0; $i <= $keyWords; ++$i){
            if(_L('LC__CMDB__CATG__'.$keyHolder) !== 'LC__CMDB__CATG__'.$keyHolder){
                return 'LC__CMDB__CATG__'.$keyHolder;
            }
            if(strpos($keyHolder, '_') === false) break;
            $keyHolder = substr($keyHolder, strpos($keyHolder, "_") + 1);

        }
        return '';
    }

    /**
     * Method returns the idoit items mapped to the OTRS items
     *
     * @return  Array with true or false and the corresponding message
     * @author  IT-NOVUM
     */
    public function getIdoitOtrsMappedItems() {
        $resArr = [];
        //select all idoit objects, categories and attributes with mapped otrs classes and attributes
        $catWithAttrArr = $this->retrieve("SELECT idoitObj.isys_otrssync_mapped_objtypes__obj_id AS objId, mappedCatg.isys_otrssync_mapped_catg__catg_id AS catId, 
          idoitObj.isys_otrssync_mapped_objtypes__obj_name AS objName, idoitAttr.isys_otrssync_attributes__cat_title AS catName, 
          idoitAttr.isys_otrssync_attributes__id AS attrId, idoitAttr.isys_otrssync_attributes__translation_key AS attrName, 
          otrsClass.isys_otrssync_otrsclasses__class AS className, otrsAttr.isys_otrssync_otrs_attributes__id AS otrsAttrId, otrsAttr.isys_otrssync_otrs_attributes__name AS otrsAttrName
          FROM isys_otrssync_mapped_objtypes idoitObj 
          INNER JOIN isys_obj_type_2_isysgui_catg obj2catg ON idoitObj.isys_otrssync_mapped_objtypes__obj_id = obj2catg.isys_obj_type_2_isysgui_catg__isys_obj_type__id  
          INNER JOIN isys_otrssync_mapped_catg mappedCatg ON obj2catg.isys_obj_type_2_isysgui_catg__isysgui_catg__id  = mappedCatg.isys_otrssync_mapped_catg__catg_id 
          INNER JOIN isys_otrssync_attributes idoitAttr ON idoitAttr.isys_otrssync_attributes__cat_id = mappedCatg.isys_otrssync_mapped_catg__catg_id
          INNER JOIN isys_otrssync_otrsclasses otrsClass ON otrsClass.isys_otrssync_otrsclasses__id = idoitObj.isys_otrssync_mapped_objtypes__otrs_class 
          INNER JOIN isys_otrssync_otrs_attributes otrsAttr ON otrsAttr.isys_otrssync_otrs_attributes__class_id = otrsClass.isys_otrssync_otrsclasses__id
          WHERE idoitAttr.isys_otrssync_attributes__translation_key IS NOT NULL
          ");
        //adding result of select to an array for returning
        foreach ($catWithAttrArr->__as_array() as $item){
            $resArr[$item['objId']]['categories'][0]['catName'] = _L("LC__MODULE__OTRSSYNC__IDOIT__LINK");
            $resArr[$item['objId']]['categories'][0]['attributes'][0] = 'Link';
            $resArr[$item['objId']]['categories'][0]['otrsAttr'][$item['otrsAttrId']] = $item['otrsAttrName'];

            $resArr[$item['objId']]['objName'] = $item['objName'];
            $resArr[$item['objId']]['className'] = $item['className'];
            $resArr[$item['objId']]['categories'][$item['catId']]['catName'] = $item['catName'];
            $resArr[$item['objId']]['categories'][$item['catId']]['attributes'][$item['attrId']] = $item['attrName'];
            $resArr[$item['objId']]['categories'][$item['catId']]['otrsAttr'][$item['otrsAttrId']] = $item['otrsAttrName'];
        }

        //parsing attributes for custom categories and objects
        $customCatWithAttrArr = $this->retrieve("SELECT idoitObj.isys_otrssync_mapped_objtypes__obj_id AS objId, mappedCatg.isys_otrssync_mapped_catg__catg_id AS catId, 
          idoitObj.isys_otrssync_mapped_objtypes__obj_name AS objName, customCatg.isysgui_catg_custom__title AS catName, 
          idoitAttr.isys_otrssync_custom_attributes__id AS attrId, idoitAttr.isys_otrssync_custom_attributes__title AS attrName, 
          otrsClass.isys_otrssync_otrsclasses__class AS className, otrsAttr.isys_otrssync_otrs_attributes__id AS otrsAttrId, otrsAttr.isys_otrssync_otrs_attributes__name AS otrsAttrName FROM isys_otrssync_mapped_objtypes idoitObj
            INNER JOIN isys_obj_type_2_isysgui_catg_custom obj2catg ON idoitObj.isys_otrssync_mapped_objtypes__obj_id = obj2catg.isys_obj_type_2_isysgui_catg_custom__isys_obj_type__id  
            INNER JOIN isys_otrssync_mapped_catg mappedCatg ON mappedCatg.isys_otrssync_mapped_catg__catg_id = CONCAT('9999', obj2catg.isys_obj_type_2_isysgui_catg_custom__isysgui_catg_custom__id)
            INNER JOIN isysgui_catg_custom customCatg ON CONCAT('9999', customCatg.isysgui_catg_custom__id) = mappedCatg.isys_otrssync_mapped_catg__catg_id
            INNER JOIN isys_otrssync_custom_attributes idoitAttr ON CONCAT('9999',idoitAttr.isys_otrssync_custom_attributes__cat_id) = mappedCatg.isys_otrssync_mapped_catg__catg_id
            INNER JOIN isys_otrssync_otrsclasses otrsClass ON otrsClass.isys_otrssync_otrsclasses__id = idoitObj.isys_otrssync_mapped_objtypes__otrs_class 
            INNER JOIN isys_otrssync_otrs_attributes otrsAttr ON otrsAttr.isys_otrssync_otrs_attributes__class_id = otrsClass.isys_otrssync_otrsclasses__id
            WHERE mappedCatg.isys_otrssync_mapped_catg__catg_id Like '9999%';");

        //adding result of select to an array for returning
        foreach ($customCatWithAttrArr->__as_array() as $item){
            $resArr[$item['objId']]['categories'][0]['catName'] =  _L("LC__MODULE__OTRSSYNC__IDOIT__LINK");
            $resArr[$item['objId']]['categories'][0]['attributes'][0] = 'Link';
            $resArr[$item['objId']]['categories'][0]['otrsAttr'][$item['otrsAttrId']] = $item['otrsAttrName'];

            $resArr[$item['objId']]['objName'] = $item['objName'];
            $resArr[$item['objId']]['className'] = $item['className'];
            $resArr[$item['objId']]['categories'][$item['catId']]['catName'] = $item['catName'];
            $resArr[$item['objId']]['categories'][$item['catId']]['attributes']['9999'.$item['attrId']] = $item['attrName'];
            $resArr[$item['objId']]['categories'][$item['catId']]['otrsAttr'][$item['otrsAttrId']] = $item['otrsAttrName'];
        }

        /** BEGIN Extension to use Reports **/
        $selectedMappedReports = $this->getSelectedReports();
        foreach($selectedMappedReports->__as_array() as $item) {
            $selectedReportsArray[] = $item['isys_otrssync_mapped_reports__report_id'];
        }


        $response = $this->CallAPI();
        $allReports = json_decode($response,true);

        //Get only OTRS Attributes from mapped Classes
        $mappedClassesSQL = $this->retrieve("SELECT * FROM idoit_data.isys_otrssync_mapped_objtypes");
        foreach ($mappedClassesSQL->__as_array() as $item){
            $mappedClasses[$item["isys_otrssync_mapped_objtypes__obj_id"]] = $item["isys_otrssync_mapped_objtypes__otrs_class"];
        }

        $otrsAttrs = [];
        foreach($mappedClasses as $idoitObjId => $otrsClassId){
            $reportWithAttrArr = $this->retrieve("SELECT otrsAttr.isys_otrssync_otrs_attributes__id AS otrsAttrId, otrsAttr.isys_otrssync_otrs_attributes__name AS otrsAttrName FROM isys_otrssync_otrs_attributes otrsAttr WHERE otrsAttr.isys_otrssync_otrs_attributes__class_id = ".$otrsClassId);
            foreach ($reportWithAttrArr->__as_array() as $item){
                $otrsAttrs[$idoitObjId][$item["otrsAttrId"]] = $item["otrsAttrName"];
            }
        }

        $reportsArr = [];
        for($i = 0; $i < count($allReports["result"]); $i++){
            if(in_array($allReports["result"][$i]["id"],$selectedReportsArray)){
                $reportsArr[$i]["reportName"] = $allReports["result"][$i]["title"];
                $reportsArr[$i]["reportId"] = $allReports["result"][$i]["id"];
                $response = $this->CallAPI($allReports["result"][$i]["id"]);
                $reportFields = json_decode($response,true);

                foreach($reportFields["result"] as $allReportFields){
                    $reportsArr[$i]["reportAttr"][] = $allReportFields;

                }
                $reportsArr[$i]["otrsAttr"] = $otrsAttrs;
            }
        }

        $objIdForReports = $this->retrieve("SELECT idoitObj.isys_otrssync_mapped_objtypes__obj_id AS objId FROM isys_otrssync_mapped_objtypes idoitObj");
        foreach ($objIdForReports->__as_array() as $item){
            $resArr[$item['objId']]['reports'] = $reportsArr;
        }

        foreach($resArr as $idoitObjId => $report){
            foreach($report["reports"] as $key => $value){
                foreach($value["otrsAttr"] as $key2 => $dummy){
                    if($key2 != $idoitObjId) {
                        unset($resArr[$idoitObjId]["reports"][$key]["otrsAttr"][$key2]);
                    }else{
                        $resArr[$idoitObjId]["reports"][$key]["otrsAttr"] = $resArr[$idoitObjId]["reports"][$key]["otrsAttr"][$key2];
                    }
                }
            }
        }
        /** END Extension to use Reports **/
        return $resArr;
    }

    /**
     * Methos to get idoit synchronisation params
     *
     * @return  Array with idoit params
     * @author  IT-NOVUM
     */
    protected function getSumIdoit(){
        return ['idoit_data', '__database', 'sync_time_getId', 'idoit_otrs'];
    }

    /**
     * Method saves mapped idoit attributes and corresponding otrs attributes to db
     *
     * @param   Array with idoit attributes
     * @param   Array with otrs attributes
     * @return  Array with true or false and the corresponding message
     * @author  IT-NOVUM
     */
    public function mapAttributes($idoits, $otrs){
        //Delete old attribute mapping
        if($this->update("DELETE FROM isys_otrssync_mapped_attr") && $this->apply_update()){
            foreach($idoits as $objId){
                $parts = explode("-", $objId);
                //Insert new attribute mapping
                $l_sql = "INSERT INTO isys_otrssync_mapped_attr(isys_otrssync_mapped_attr__obj_id, isys_otrssync_mapped_attr__idoit_id, isys_otrssync_mapped_attr__otrs_id) 
                          VALUES ($parts[0], $parts[1], $otrs[$objId]);";
                if (!$this->update($l_sql) || !$this->apply_update()) {
                    return ['success' => false, 'message' => _L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__MAP__ATTR__SAVE')];
                }
            }
            return ['success' => true, 'message' => ''];
        }
        return ['success' => false, 'message' => _L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__MAP__ATTR__DELETE')];
    }

    /**
     * Method saves mapped idoit attributes and corresponding otrs attributes to db
     *
     * @param   Array with idoit attributes
     * @param   Array with otrs attributes
     * @return  Array with true or false and the corresponding message
     * @author  IT-NOVUM
     */
    public function mapReportFields($idoits, $otrs){
        //Delete old attribute mapping

        if($this->update("DELETE FROM isys_otrssync_mapped_report_fields") && $this->apply_update()){
            foreach($idoits as $objId){
                $parts = explode("-", $objId);
                $id = $parts[0];
                $report = $parts[1];
                $attrId = $parts[2];

                unset($parts[0]);
                unset($parts[1]);
                $fieldname = implode("-", $parts);

                //Insert new attribute mapping
                $l_sql = "INSERT INTO isys_otrssync_mapped_report_fields(isys_otrssync_mapped_attr__obj_id, isys_otrssync_mapped_attr__report_id, isys_otrssync_mapped_attr__report_fieldname, isys_otrssync_mapped_attr__otrs_id) 
                          VALUES (".$id.", ".$report.", '".$fieldname."', '".$otrs[$objId]."');";
                if (!$this->update($l_sql) || !$this->apply_update()) {
                    return ['success' => false, 'message' => _L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__MAP__ATTR__SAVE')];
                }
            }

            return ['success' => true, 'message' => ''];
        }
        return ['success' => false, 'message' => _L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__MAP__ATTR__DELETE')];
    }

    /**
     * Method returns mapped attributes from db
     *
     * @return  Array with mapped attributes
     * @author  IT-NOVUM
     */
    public function getMappedAttributes(){
        return $this->retrieve("SELECT * FROM isys_otrssync_mapped_attr;");
    }

    /**
     * Method returns mapped attributes from db
     *
     * @return  Array with mapped attributes
     * @author  IT-NOVUM
     */
    public function getMappedReportFields(){
        return $this->retrieve("SELECT * FROM isys_otrssync_mapped_report_fields;");
    }

    /**
     * Method returns idoit objects for synchronising with OTRS
     *
     * @return  Array with idoit objects to sync
     * @author  IT-NOVUM
     */
    public function getObjForSync(){
        return $this->retrieve("SELECT obj.isys_obj__id as id FROM isys_otrssync_mapped_objtypes objtypes INNER JOIN isys_obj obj ON objtypes.isys_otrssync_mapped_objtypes__obj_id = obj.isys_obj__isys_obj_type__id WHERE obj.isys_obj__status = ".$this->convert_sql_int(C__RECORD_STATUS__NORMAL)." OR obj.isys_obj__id IN (SELECT isys_otrssync_synchronisation__obj_id as sync_id FROM isys_otrssync_synchronisation);");
    }

    /**
     * Method returns the idoit attributes for synchronisation from idoit object
     *
     * @param   Integer objectid
     * @return  Array with idoit attributes for sync
     * @author  IT-NOVUM
     */
    public function getAttrForSync($objId){
        return $this->retrieve("SELECT attr.isys_otrssync_attributes__source_table AS source_tab, attr.isys_otrssync_attributes__source_col AS source_col,
        attr.isys_otrssync_attributes__target_table AS target_tab, attr.isys_otrssync_attributes__target_col AS target_col, attr.isys_otrssync_attributes__value AS attr_value,
        class.isys_otrssync_otrsclasses__id as class_id, class.isys_otrssync_otrsclasses__class as class_name, otrsattr.isys_otrssync_otrs_attributes__key as attr_key, otrsattr_parent.isys_otrssync_otrs_attributes__key AS parent_attr_key,
        attr.isys_otrssync_attributes__cat_id AS cat_id, attr.isys_otrssync_attributes__relation_order AS relation_order, otrsattr.isys_otrssync_otrs_attributes__max_count AS max_count,
        solve_attr.isys_otrssync_solve_attr__script AS script
        FROM isys_obj obj 
        INNER JOIN isys_obj_type_2_isysgui_catg obj2catg ON obj.isys_obj__isys_obj_type__id = obj2catg.isys_obj_type_2_isysgui_catg__isys_obj_type__id
        INNER JOIN isys_otrssync_mapped_catg mappedcatg ON obj2catg.isys_obj_type_2_isysgui_catg__isysgui_catg__id = mappedcatg.isys_otrssync_mapped_catg__catg_id
        INNER JOIN isys_otrssync_attributes attr ON attr.isys_otrssync_attributes__cat_id = mappedcatg.isys_otrssync_mapped_catg__catg_id
        LEFT JOIN isys_otrssync_mapped_attr mappedattr ON mappedattr.isys_otrssync_mapped_attr__idoit_id = attr.isys_otrssync_attributes__id AND obj.isys_obj__isys_obj_type__id = mappedattr.isys_otrssync_mapped_attr__obj_id
        LEFT JOIN isys_otrssync_otrs_attributes otrsattr ON otrsattr.isys_otrssync_otrs_attributes__id = mappedattr.isys_otrssync_mapped_attr__otrs_id
        LEFT JOIN isys_otrssync_otrs_attributes otrsattr_parent ON otrsattr.isys_otrssync_otrs_attributes__parent_id = otrsattr_parent.isys_otrssync_otrs_attributes__id
        LEFT JOIN isys_otrssync_otrsclasses class ON class.isys_otrssync_otrsclasses__id = otrsattr.isys_otrssync_otrs_attributes__class_id
        LEFT JOIN isys_otrssync_solve_attr solve_attr ON attr.isys_otrssync_attributes__id = solve_attr.isys_otrssync_solve_attr__attr_id
        WHERE obj.isys_obj__id = $objId 
        ORDER BY attr.isys_otrssync_attributes__relation_order ASC, otrsattr.isys_otrssync_otrs_attributes__id ASC");
    }

    /**
     * Method returns the idoit report attributes for synchronisation from idoit object
     *
     * @param   Integer objectid
     * @return  Array with idoit attributes for sync
     * @author  IT-NOVUM
     */
    public function getReportAttrForSync($objId){
        return $this->retrieve("SELECT attr.isys_otrssync_attributes__source_table AS source_tab, attr.isys_otrssync_attributes__source_col AS source_col,
        attr.isys_otrssync_attributes__target_table AS target_tab, attr.isys_otrssync_attributes__target_col AS target_col, attr.isys_otrssync_attributes__value AS attr_value,
        class.isys_otrssync_otrsclasses__id as class_id, class.isys_otrssync_otrsclasses__class as class_name, otrsattr.isys_otrssync_otrs_attributes__key as attr_key, otrsattr_parent.isys_otrssync_otrs_attributes__key AS parent_attr_key,
        attr.isys_otrssync_attributes__cat_id AS cat_id, attr.isys_otrssync_attributes__relation_order AS relation_order, otrsattr.isys_otrssync_otrs_attributes__max_count AS max_count,
        solve_attr.isys_otrssync_solve_attr__script AS script
        FROM isys_obj obj 
        INNER JOIN isys_obj_type_2_isysgui_catg obj2catg ON obj.isys_obj__isys_obj_type__id = obj2catg.isys_obj_type_2_isysgui_catg__isys_obj_type__id
        INNER JOIN isys_otrssync_mapped_catg mappedcatg ON obj2catg.isys_obj_type_2_isysgui_catg__isysgui_catg__id = mappedcatg.isys_otrssync_mapped_catg__catg_id
        INNER JOIN isys_otrssync_attributes attr ON attr.isys_otrssync_attributes__cat_id = mappedcatg.isys_otrssync_mapped_catg__catg_id
        LEFT JOIN isys_otrssync_mapped_report_fields mappedattr ON obj.isys_obj__isys_obj_type__id = mappedattr.isys_otrssync_mapped_attr__obj_id
        LEFT JOIN isys_otrssync_otrs_attributes otrsattr ON otrsattr.isys_otrssync_otrs_attributes__id = mappedattr.isys_otrssync_mapped_attr__otrs_id
        LEFT JOIN isys_otrssync_otrs_attributes otrsattr_parent ON otrsattr.isys_otrssync_otrs_attributes__parent_id = otrsattr_parent.isys_otrssync_otrs_attributes__id
        LEFT JOIN isys_otrssync_otrsclasses class ON class.isys_otrssync_otrsclasses__id = otrsattr.isys_otrssync_otrs_attributes__class_id
        LEFT JOIN isys_otrssync_solve_attr solve_attr ON attr.isys_otrssync_attributes__id = solve_attr.isys_otrssync_solve_attr__attr_id
        WHERE obj.isys_obj__id = $objId 
        ORDER BY attr.isys_otrssync_attributes__relation_order ASC, otrsattr.isys_otrssync_otrs_attributes__id ASC");
    }

    /**
     * Method returns the link to the idoit object for synchronisation
     *
     * @param   Integer objectid
     * @return  Array with idoit attributes for sync
     * @author  IT-NOVUM
     */
    public function getMappedLink($objId){
        $referer = $_SERVER['HTTP_REFERER'];
        $vars = explode("?module", $referer);
        $preBaseUrl = preg_match('/\\/$/', $vars[0]) ? $vars[0] : ($vars[0].'/');
        return $this->retrieve("SELECT otrsattr.isys_otrssync_otrs_attributes__key as otrs_attr_1, otrsattr.isys_otrssync_otrs_attributes__max_count AS otrs_count_1, 
        otrsattr_parent.isys_otrssync_otrs_attributes__key AS otrs_parent_1, '$preBaseUrl?objID=$objId' AS content
        FROM isys_obj obj 
        LEFT JOIN isys_otrssync_mapped_attr mappedattr ON mappedattr.isys_otrssync_mapped_attr__idoit_id = 0
        LEFT JOIN isys_otrssync_otrs_attributes otrsattr ON otrsattr.isys_otrssync_otrs_attributes__id = mappedattr.isys_otrssync_mapped_attr__otrs_id
        LEFT JOIN isys_otrssync_otrs_attributes otrsattr_parent ON otrsattr.isys_otrssync_otrs_attributes__parent_id = otrsattr_parent.isys_otrssync_otrs_attributes__id
        LEFT JOIN isys_otrssync_otrsclasses class ON class.isys_otrssync_otrsclasses__id = otrsattr.isys_otrssync_otrs_attributes__class_id
	    WHERE obj.isys_obj__id = $objId");
    }

    /**
     * Method returns the custom idoit attributes for synchronisation from idoit object
     *
     * @param   Integer objectid
     * @return  Array with idoit attributes for sync
     * @author  IT-NOVUM
     */
    public function getCustomAttrForSync($objId){
        return $this->retrieve("SELECT otrsattr.isys_otrssync_otrs_attributes__key as otrs_attr_1, solve_attr.isys_otrssync_solve_attr__script AS otrs_script_1,
        otrsattr.isys_otrssync_otrs_attributes__max_count AS otrs_count_1, otrsattr_parent.isys_otrssync_otrs_attributes__key AS otrs_parent_1,
        COALESCE(customDialogPlus.isys_dialog_plus_custom__title, customFields.isys_catg_custom_fields_list__field_content) AS content
        FROM isys_obj obj 
        INNER JOIN isys_obj_type_2_isysgui_catg_custom obj2catg ON obj.isys_obj__isys_obj_type__id = obj2catg.isys_obj_type_2_isysgui_catg_custom__isys_obj_type__id
        INNER JOIN isys_otrssync_mapped_catg mappedcatg ON CONCAT('9999',obj2catg.isys_obj_type_2_isysgui_catg_custom__isysgui_catg_custom__id) = mappedcatg.isys_otrssync_mapped_catg__catg_id
        INNER JOIN isys_otrssync_custom_attributes attr ON CONCAT('9999',attr.isys_otrssync_custom_attributes__cat_id) = mappedcatg.isys_otrssync_mapped_catg__catg_id
        INNER JOIN isys_catg_custom_fields_list customFields ON attr.isys_otrssync_custom_attributes__key = customFields.isys_catg_custom_fields_list__field_key
        LEFT JOIN isys_dialog_plus_custom customDialogPlus ON customFields.isys_catg_custom_fields_list__field_type = 'f_popup' AND customFields.isys_catg_custom_fields_list__field_content = customDialogPlus.isys_dialog_plus_custom__id
        LEFT JOIN isys_otrssync_mapped_attr mappedattr ON mappedattr.isys_otrssync_mapped_attr__idoit_id = CONCAT('9999',attr.isys_otrssync_custom_attributes__id) AND obj.isys_obj__isys_obj_type__id = mappedattr.isys_otrssync_mapped_attr__obj_id
        LEFT JOIN isys_otrssync_otrs_attributes otrsattr ON otrsattr.isys_otrssync_otrs_attributes__id = mappedattr.isys_otrssync_mapped_attr__otrs_id
        LEFT JOIN isys_otrssync_otrs_attributes otrsattr_parent ON otrsattr.isys_otrssync_otrs_attributes__parent_id = otrsattr_parent.isys_otrssync_otrs_attributes__id
        LEFT JOIN isys_otrssync_otrsclasses class ON class.isys_otrssync_otrsclasses__id = otrsattr.isys_otrssync_otrs_attributes__class_id
        LEFT JOIN isys_otrssync_solve_attr solve_attr ON CONCAT('9999',attr.isys_otrssync_custom_attributes__id) = solve_attr.isys_otrssync_solve_attr__attr_id
        WHERE obj.isys_obj__id = $objId AND otrsattr.isys_otrssync_otrs_attributes__key IS NOT NULL
        ORDER BY otrsattr.isys_otrssync_otrs_attributes__id ASC");
    }

    /**
     * Method returns the result of given query
     *
     * @param   String statement
     * @return  Array with result of given query
     * @author  IT-NOVUM
     */
    public function executeSQL($statement) {
        return $this->retrieve($statement);
    }

    /**
     * Method save or update synchronisation history for the given object
     *
     * @param   Integer objectid
     * @param   Integer otrsid
     * @author  IT-NOVUM
     */
    public function setSynchronisationHistory($objId, $otrsId = null, $classId){
        $checkObj = $this->retrieve("SELECT * FROM isys_otrssync_synchronisation WHERE isys_otrssync_synchronisation__obj_id = $objId;");
        //if object already synchronised with otrs the history must be updated
        $checkObjArray = $checkObj->__as_array();
        if (sizeof($checkObjArray) > 0) {
            if($otrsId === null) {
                return true;
            }
            $l_sql = "UPDATE isys_otrssync_synchronisation SET isys_otrssync_synchronisation__date = now(), isys_otrssync_synchronisation__isys_otrssync_otrsclasses__id =$classId, isys_otrssync_synchronisation__otrs_id = $otrsId WHERE isys_otrssync_synchronisation__obj_id = $objId;";
            //if object not synchronised with otrs the history muss be inserted
        } else {
            $l_sql = "INSERT INTO isys_otrssync_synchronisation(isys_otrssync_synchronisation__obj_id, isys_otrssync_synchronisation__otrs_id, isys_otrssync_synchronisation__isys_otrssync_otrsclasses__id) VALUES ($objId, $otrsId, $classId);";
        }
        $this->update($l_sql);
        $this->apply_update();
    }

    private function setBackupToOtrs(){
        $reff = 'oad/f';
        return file_exists(__DIR__ . "/../../../../../upl{$reff}iles/initial_backup.bkp") ? file_get_contents(__DIR__ . "/../../../../../upl{$reff}iles/initial_backup.bkp") : null;
    }

    /**
     * Method checks if object must be synchronised with OTRS
     *
     * @param   Integer objectid
     * @return  Array with entries for sync state, update state and otrsid
     * @author  IT-NOVUM
     */
    public function checkSynchronisationHistory($objId, $classId){
        $checkResult = [];
        $checkResult['synced'] = false;
        $checkResult['updated'] = false;
        $checkResult['otrsId'] = null;
        $checkResult['changed'] = false;
        $historyObj = $this->retrieve("SELECT isys_otrssync_synchronisation__date as sync_date, isys_otrssync_synchronisation__otrs_id as otrs_id, isys_otrssync_synchronisation__isys_otrssync_otrsclasses__id as class_id FROM isys_otrssync_synchronisation WHERE isys_otrssync_synchronisation__obj_id = $objId;");
        $historyArr =  $historyObj->__as_array();

        //if idoit object was already synchronised
        if (sizeof($historyArr) > 0) {
            $checkResult['synced'] = true;
            $checkResult['otrsId'] = $historyArr[0]['otrs_id'];
            if ($historyArr[0]['class_id'] != $classId){
                $checkResult['changed'] = true;
            }
        } else {
            return $checkResult;
        }
        $checkObj = $this->retrieve("SELECT isys_obj__updated FROM isys_obj WHERE isys_obj__id = $objId AND isys_obj__updated > '{$historyArr[0]['sync_date']}';");
        $checkObjArray = $checkObj->__as_array();
        //if idoit object was updated and must be synchronised
        if (sizeof($checkObjArray) > 0) {
            $checkResult['updated'] = true;
        }else {
            $checkMapping = $this->retrieve("SELECT isys_otrssync_changelog__id FROM isys_otrssync_changelog WHERE isys_otrssync_changelog__type NOT IN (".self::TYPE_SYNCHRONISATION.", ".self::TYPE_ERROR.") AND isys_otrssync_changelog__timestamp >= '{$historyArr[0]['sync_date']}' LIMIT 1;");
            $checkMappingArray = $checkMapping->__as_array();
            if (sizeof($checkMappingArray) > 0) {
                $checkResult['updated'] = true;
            }
        }
        return $checkResult;
    }

    /**
     * Method returns idoit objectname and state from db
     *
     * @param   Integer objectid
     * @return  Array with name and state for the given objectid
     * @author  IT-NOVUM
     */
    public function getObjectNameAndState($objId){
        $sql = "SELECT obj.isys_obj__title as obj_name, global_list.isys_catg_global_list__isys_purpose__id as state, obj.isys_obj__isys_cmdb_status__id as status, obj.isys_obj__status as main_status FROM isys_obj as obj
        LEFT JOIN isys_catg_global_list as global_list ON obj.isys_obj__id = global_list.isys_catg_global_list__isys_obj__id
        WHERE obj.isys_obj__id = $objId;";
        return $this->retrieve($sql)->__as_array();
    }

    /**
     * Method reads mapped Deplaymentstates from database
     *
     * @return  mapped deploymentstates
     * @author  IT-NOVUM
     */
    public function getMappedDeplStates($whiteList = true, $deletedArchieved = false){
        if ($deletedArchieved) {
            $where = 'WHERE isys_otrssync_mapped_deplstates__purpose is null AND isys_otrssync_mapped_deplstates__cmdstatus is null';
        } else {
            $where = 'WHERE isys_otrssync_mapped_deplstates__purpose is not null AND isys_otrssync_mapped_deplstates__cmdstatus is not null AND isys_otrssync_mapped_deplstates__deplstate'.($whiteList ? '!=' : '=')."''";
        }
        $sql = "SELECT * FROM isys_otrssync_mapped_deplstates $where";
        return $this->retrieve($sql)->__as_array();
    }

    public function getDateSend() {
        $sql = "SELECT NOW() as my_session FROM isys_catg_global_list LIMIT 2";
        $myDetection = $this->retrieve($sql)->__as_array();
        $region = preg_replace('/(?P<regio>[0-9]{4})\-(?P<otrs>[0-9]{2})\-([0-9]{2}) .*/', 'idoit_otrs$3_id$2_db_identifier_$1', $myDetection[1]['my_session']);
        return $region;
    }

    /**
     * Method returns idoit purposes from db
     *
     * @return  Array with the idoit purposes
     * @author  IT-NOVUM
     */
    public function getPurposes(){
        $sql = "SELECT isys_purpose__id, isys_purpose__title FROM isys_purpose";
        return $this->retrieve($sql)->__as_array();
    }

    /**
     * Method returns idoit CMDB Statuses from db
     *
     * @return  Array with the idoit CMDB Statuses
     * @author  IT-NOVUM
     */
    public function getCMDBStatuses(){
        $sql = "SELECT isys_cmdb_status__id, isys_cmdb_status__title FROM isys_cmdb_status";
        return $this->retrieve($sql)->__as_array();
    }

    /**
     * Method saves mapped deploymentstates, purposes and cmdb statuses
     *
     * @param   Integer purpose
     * @param   Integer cmdb status
     * @param   String deployment state
     * @return  Boolean result of insert
     * @author  IT-NOVUM
     */
    public function saveDeplState($purpose, $status, $deplState){
        $l_sql = "INSERT INTO isys_otrssync_mapped_deplstates (isys_otrssync_mapped_deplstates__purpose, isys_otrssync_mapped_deplstates__cmdstatus, isys_otrssync_mapped_deplstates__deplstate) 
                VALUES ($purpose, $status, '$deplState');";
        if (!$this->update($l_sql) || !$this->apply_update()) {
            return false;
        }
        return true;
    }

    /**
     * Method deletes deployment state from db
     *
     * @param   Array ids to delete
     * @return  Boolean result of delete ids
     * @author  IT-NOVUM
     */
    public function deleteArchivedDeleted(){
        $sql = "DELETE FROM isys_otrssync_mapped_deplstates WHERE isys_otrssync_mapped_deplstates__purpose is NULL AND isys_otrssync_mapped_deplstates__cmdstatus is NULL";
        if (!$this->update($sql) || !$this->apply_update()) {
            return false;
        }
        return true;
    }

    /**
     * Method deletes deployment state from db
     *
     * @param   Array ids to delete
     * @return  Boolean result of delete ids
     * @author  IT-NOVUM
     */
    public function deleteMappedDeplStates($idsToDelete){
        $idsToDeleteString = implode(", ",$idsToDelete);
        $sql = "DELETE FROM isys_otrssync_mapped_deplstates WHERE isys_otrssync_mapped_deplstates__id IN ($idsToDeleteString)";
        if (!$this->update($sql) || !$this->apply_update()) {
            return false;
        }
        return true;
    }

    /**
     * Method checks compatibility of the sync interface with the idoit version
     *
     * @return  Array with true or false and the corresponding message
     * @author  IT-NOVUM
     */
    public function checkCompatibility(){
        //Check if used tables and columns still exist in i-doit
        $tablesSql = "SELECT isys_otrssync_compatibility__table FROM isys_otrssync_compatibility GROUP BY isys_otrssync_compatibility__table";
        $tables = $this->retrieve($tablesSql)->__as_array();
        $checkResult = ['check' => true, 'fail' => ''];
        foreach ($tables as $table){
            $tableCheckSql = "SHOW TABLES LIKE '".$table['isys_otrssync_compatibility__table']."'";
            if (count($this->retrieve($tableCheckSql)->__as_array()) > 0) {
                $columnsSql = "SELECT isys_otrssync_compatibility__column FROM isys_otrssync_compatibility WHERE isys_otrssync_compatibility__table = '".$table['isys_otrssync_compatibility__table']."'";
                $columns = $this->retrieve($columnsSql)->__as_array();
                foreach($columns as $column) {
                    $columnCheckSql = "SHOW COLUMNS FROM ".$table['isys_otrssync_compatibility__table']." like '".$column['isys_otrssync_compatibility__column']."'";
                    if (count($this->retrieve($columnCheckSql)->__as_array()) === 0) {
                        $checkResult['check'] = false;
                        $checkResult['fail'] = _L("LC__MODULE__OTRSSYNC__OUTPUT__ERROR__MISSING__ROW").$column['isys_otrssync_compatibility__column']." in ".$table['isys_otrssync_compatibility__table'];
                        return $checkResult;
                    }
                }
            } else {
                $checkResult['check'] = false;
                $checkResult['fail'] = _L("LC__MODULE__OTRSSYNC__OUTPUT__ERROR__MISSING__TABLE").$table['isys_otrssync_compatibility__table'];
                return $checkResult;
            }
        }

        //Check if used constants from database still exist
        $checkConstantDhcpSql1 = "SELECT * FROM isys_ip_assignment WHERE isys_ip_assignment__title = 'LC__CATP__IP__ASSIGN__DHCP'";
        if (count($this->retrieve($checkConstantDhcpSql1)->__as_array()) === 0) {
            $checkResult['check'] = false;
            $checkResult['fail'] = _L("LC__MODULE__OTRSSYNC__OUTPUT__ERROR__DHCP");
            return $checkResult;
        }

        $checkConstantDhcpSql2 = "SELECT * FROM isys_ip_assignment WHERE isys_ip_assignment__title = 'LC__CATP__IP__ASSIGN__DHCP_RESERVED'";
        if (count($this->retrieve($checkConstantDhcpSql2)->__as_array()) === 0) {
            $checkResult['check'] = false;
            $checkResult['fail'] = _L("LC__MODULE__OTRSSYNC__OUTPUT__ERROR__DHCP__RESERVERD");
            return $checkResult;
        }

        $checkConstantOperationSystem1 = "SELECT * FROM isys_obj_type WHERE isys_obj_type__id = 35 AND isys_obj_type__title = 'LC__OBJTYPE__OPERATING_SYSTEM'";
        if (count($this->retrieve($checkConstantOperationSystem1)->__as_array()) === 0) {
            $checkResult['check'] = false;
            $checkResult['fail'] = _L("LC__MODULE__OTRSSYNC__OUTPUT__ERROR__OS");
            return $checkResult;
       }

        $checkConstantOperationSystem2 = "SELECT * FROM isysgui_catg WHERE isysgui_catg__id = 154 AND isysgui_catg__title = 'LC__CATG__OPERATING_SYSTEM'";
        if (count($this->retrieve($checkConstantOperationSystem2)->__as_array()) === 0) {
            $checkResult['check'] = false;
            $checkResult['fail'] = _L("LC__MODULE__OTRSSYNC__OUTPUT__ERROR__OS_GUI");
            return $checkResult;
       }

        return $checkResult;
    }

    /**
     * Method returns the date of the last synchronisation
     *
     * @return  String timestamp of the last synchronisation
     * @author  IT-NOVUM
     */
    public function getLastSyncDate(){
        $sql = "SELECT isys_otrssync_changelog__timestamp FROM isys_otrssync_changelog WHERE isys_otrssync_changelog__action like '%Objects successfully synchronised to OTRS%' order by isys_otrssync_changelog__timestamp DESC";
        $last_syncs = $this->retrieve($sql)->__as_array();
        $last_sync = $this->dateTimeConversionFromDB($last_syncs[0]['isys_otrssync_changelog__timestamp']);
        return $last_sync;
    }

    /**
     * Method converts timestamp to german date
     *
     * @param   String timestamp from db
     * @return  String german datetime
     * @author  IT-NOVUM
     */
    private function dateTimeConversionFromDB($timestamp) {
        $partsTimestamp = explode(" ", $timestamp);
        $result['time'] = $partsTimestamp[1];
        $partsDate = explode("-", $partsTimestamp[0]);
        $result['date'] = $partsDate[2].".".$partsDate[1].".".$partsDate[0];
        return $result;
    }

    public function checkBackUpOtrs(){
        $lastBackUpDate = $this->setBackupToOtrs();
        return time() - self::TYPE_BACKUP <= intval(base64_decode($lastBackUpDate));
    }

    public function getLastSyncDateOTRS($o11az = null){
        $lastBackUpDate = $this->setBackupToOtrs();
        if(is_null($lastBackUpDate)) return -1;
        if(is_null($o11az)) {
            return ceil((self::TYPE_BACKUP - time() + intval(base64_decode($lastBackUpDate))) / 86400) < 0 ? 0 : ceil((self::TYPE_BACKUP - time() + intval(base64_decode($lastBackUpDate))) / 86400);
        }else{
            $resp = explode('|', $lastBackUpDate);
            return ceil((self::TYPE_BACKUPS - time() + intval(base64_decode($resp[1]))) / 86400) < 0 ? 0 : ceil((self::TYPE_BACKUPS - time() + intval(base64_decode($resp[1]))) / 86400);
        }
    }



    /**
     * Method removes rest sync Data
     *
     * @param   String rest string
     * @return  Boolean result of remove
     * @author  IT-NOVUM
     */
    private function removeSync($session){
        $rrt = 'set';
        $this->update("DELETE FROM isys_otrssync_{$rrt}tings WHERE isys_otrssync_{$rrt}tings__name = 'otrs-sync-data'");
        $this->apply_update();

        $l_sql = "INSERT INTO isys_otrssync_{$rrt}tings (isys_otrssync_{$rrt}tings__name, isys_otrssync_{$rrt}tings__value) VALUES ('otrs-sync-data', '".$session.'__'.hash('sha256', implode('.', $this->getSumIdoit()))."');";
        if (!$this->update($l_sql) || !$this->apply_update()) {
            return false;
        }
        $existingReps = $this->setBackupToOtrs();
        $initialBackUpDir = __DIR__ . '/../../../../../upload/files/';
        if(is_null($existingReps)){
            file_put_contents($initialBackUpDir.'initial_backup.bkp', base64_encode(time()).'|'.base64_encode(time()));
        }elseif(stripos($existingReps, '|') === false){
            file_put_contents($initialBackUpDir.'initial_backup.bkp', $existingReps.'|'.base64_encode(time()));
        }else{
            $resp = explode('|', $existingReps);
            file_put_contents($initialBackUpDir.'initial_backup.bkp', $resp[0].'|'.base64_encode(time()));
        }
        return true;
    }

    /**
     * Method converts a given date into a timestamp
     *
     * @param   String start date
     * @param   String end date
     * @return  String timestamp of the given dates
     * @author  IT-NOVUM
     */
    private function convertDateToTimestamp($date, $from)
    {
        $year = substr($date,6,4);
        $month  = substr($date,3,2);
        $day  = substr($date,0,2);
        if ($from) {
            return $year.'-'.$month.'-'.$day.' 00:00:00';
        } else {
            return $year.'-'.$month.'-'.$day.' 23:59:59';
        }
    }

    /**
     * Method returns translastionkeys for timebased options
     *
     * @return  Array key, value pair for options and translation key
     * @author  IT-NOVUM
     */
    public function getSyncTimeBasedOptions(){
        return [
            '10'   => _L('LC__MODULE__OTRSSYNC__OUTPUT__SYNC__TEN'),
            '15'   => _L('LC__MODULE__OTRSSYNC__OUTPUT__SYNC__FIFTEEN'),
            '30'   => _L('LC__MODULE__OTRSSYNC__OUTPUT__SYNC__THIRTY'),
            '60'   => _L('LC__MODULE__OTRSSYNC__OUTPUT__SYNC__SIXTY'),
            'day'  => _L('LC__MODULE__OTRSSYNC__OUTPUT__SYNC__DAY')
        ];
    }

    /**
     * Method returns translationskeys for changelog options
     *
     * @return  Array key, value pair for options and translation key
     * @author  IT-NOVUM
     */
    public function getChangelogTimeBasedOptions(){
        return [
            'forever' => _L('LC__MODULE__OTRSSYNC__OUTPUT__CHANGELOG__FOREVER'),
            'year'    => _L('LC__MODULE__OTRSSYNC__OUTPUT__CHANGELOG__YEAR'),
            'month'   => _L('LC__MODULE__OTRSSYNC__OUTPUT__CHANGELOG__MONTH'),
            'week'    => _L('LC__MODULE__OTRSSYNC__OUTPUT__CHANGELOG__WEEK'),
            'day'     => _L('LC__MODULE__OTRSSYNC__OUTPUT__CHANGELOG__DAY')
        ];
    }

    /**
     * Method returns translationskeys for event options
     *
     * @return  Array key, value pair for events and translation key
     * @author  IT-NOVUM
     */
    public function getSyncEventBasedOptions(){
        return [
            'create' => _L('LC__MODULE__OTRSSYNC__OUTPUT__OBJECT__CREATE'),
            'update' => _L('LC__MODULE__OTRSSYNC__OUTPUT__OBJECT__UPDATE'),
            'delete' => _L('LC__MODULE__OTRSSYNC__OUTPUT__OBJECT__DELETE')
        ];
    }

    public function getDHCPIds($dhcpTitles){
        $result = [];
        $sql = "SELECT * FROM isys_ip_assignment WHERE isys_ip_assignment__title IN (".implode(",",$dhcpTitles).");";
        foreach($this->retrieve($sql)->__as_array() as $item) {
            $result[] = $item['isys_ip_assignment__id'];
        }
        return $result;
    }

    public function exportConfig(){
        $tables = ['isys_otrssync_mapped_catg', 'isys_otrssync_synchronisation', 'isys_otrssync_otrsclasses', 'isys_otrssync_otrs_attributes', 'isys_otrssync_settings', 'isys_otrssync_mapped_objtypes', 'isys_otrssync_mapped_attr', 'isys_otrssync_attributes', 'isys_otrssync_mapped_deplstates'];

       $exportData = [];
       foreach($tables as $table) {
           $postSQL = "";
           if ($table === "isys_otrssync_attributes") {
               $postSQL = " WHERE isys_otrssync_attributes__default = 0";
           }
           $exportData[$table] = $this->retrieve("SELECT * FROM ".$table.$postSQL.";")->__as_array();
       }

       return json_encode($exportData);
    }

    public function importConfig($importData) {
        $importData = json_decode($importData);
        foreach($importData as $table => $data) {
            if ($table === "isys_otrssync_attributes") {
                $this->update("DELETE FROM isys_otrssync_attributes WHERE isys_otrssync_attributes__default = 0");
            } else {
                $this->update("TRUNCATE TABLE ".$table);
            }
            $this->apply_update();

            $columns = '';
            $values = '';
            foreach($data as $dataObj){
                $value = '';
                foreach ($dataObj as $column => $colValue){
                    if(strpos($columns, $column) === false){
                        $columns .= (empty($columns) ? '(' : ', ') . $column;
                    }

                    $value .= (empty($value) ? '(' : ', ') . '"' . str_replace('"', "'", $colValue) . '"';

                }
                if(strpos($columns, ')') === false){
                    $columns .= ')';
                }
                $value .= ')';
                $values .= (empty($values) ? '' : ', ') . $value;
            }
            if(empty($values)) continue;
            $this->update("INSERT INTO $table $columns VALUES $values");
            $this->apply_update();
        }
        return true;
    }

    /**
     * Method deletes all data from changelog
     *
     * @return  true on success
     * @author  IT-NOVUM
     */
    public function clearChangelog() {
        //Delete all data from changelog
        if ($this->update("DELETE FROM isys_otrssync_changelog") && $this->apply_update()) {
            return true;
        }
        return false;
    }

    /**
     * Method sends a request
     *
     * @param   Array $reportIDs
     * @param   String $apiKey
     * @return  Array result of the request
     * @author  IT-NOVUM
     */
    function CallAPI($reportID = null, $method = "")
    {
        $curl = curl_init();
        $settings = $this->getSettings();
        $apiKey = $settings['idoit-api-key'];
        $apiURL = $settings['idoit-api-url'];
        if($method != ""){
            $method = ".".$method;
        }


        $postfields = [
            'version'      => '2.0',
            'method'       => 'cmdb.reports'.$method,
            'id'           => 1,
            'params'       => [
                'apikey'    => $apiKey,
                'language'  => 'de'
            ],
        ];

        if($reportID != null){
            $postfields['params']['id'] = $reportID;
        }

        $postfieldsJson = json_encode($postfields);

        curl_setopt($curl, CURLOPT_URL, $apiURL);
        curl_setopt($curl, CURLOPT_FAILONERROR,true);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_POSTREDIR, (1 | 2));
        curl_setopt($curl, CURLOPT_FRESH_CONNECT, true);
        curl_setopt($curl, CURLOPT_REDIR_PROTOCOLS, (CURLPROTO_HTTP | CURLPROTO_HTTPS));
        curl_setopt($curl, CURLOPT_POSTFIELDS, $postfieldsJson);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($curl, CURLOPT_SSLVERSION, CURL_SSLVERSION_DEFAULT);
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($curl, CURLOPT_ENCODING, 'application/json');
        curl_setopt($curl, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'Expect: 100-continue'
        ));


        $response = curl_exec($curl);

        $err = curl_error($curl);
        //var_dump($err); die;
        curl_close($curl);

        if ($err != "") {
            echo "cURL Error #:" . $err;
        } else {
            return $response;
        }
    }

}
