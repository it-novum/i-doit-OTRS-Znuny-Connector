<?php

namespace idoit\Module\Otrssync\Model;
use idoit\Exception\Exception;
require_once 'Dao.php';

/**
 * i-doit OTRSSYNC OtrsConnector
 *
 * @package     Modules
 * @subpackage  OTRSSYNC\Model
 * @author      IT-Novum
 * @copyright   IT-Novum GmbH
 */

class OtrsConnector{

    private $url;
    private $webserviceName;
    private $createAction;
    private $updateAction;
    private $searchAction;
    private $username;
    private $password;
    protected $dao = null;

    private $aliasTables = [];

    /**
     * Constructor which initiates the db connection
     *
     * @param  Object with db connection
     * @author  IT-NOVUM
     */
    public function __construct($db_connection){
        $this->dao = $db_connection;
    }


    /**
     * Method reads settings from db and sets the global vars
     *
     * @throws Exception
     * @author  IT-NOVUM
     */
    private function setParametersFromDB(){
        $settings = $this->dao->getSettings();
        if (!isset($settings['otrs-url']) || !isset($settings['otrs-username']) || !isset($settings['otrs-password']) || !isset($settings['otrs-webservice']) || !isset($settings['otrs-create-action']) || !isset($settings['otrs-update-action']) || !isset($settings['otrs-search-action'])) {
            throw new Exception(_L("LC__MODULE__OTRSSYNC__OUTPUT__ERROR__DB__SETTINGS"));
        }
        $this->url = $settings['otrs-url'];
        $this->username = $settings['otrs-username'];
        $this->password = $settings['otrs-password'];
        $this->webserviceName = $settings['otrs-webservice'];
        $this->createAction = $settings['otrs-create-action'];
        $this->updateAction = $settings['otrs-update-action'];
        $this->searchAction = $settings['otrs-search-action'];
    }

    /**
     * Method returns data from the OTRS webservice with the search action
     *
     * @param   String query which should sent to the webservice
     * @return  Array result from the webservice after sending the query
     * @author  IT-NOVUM
     */
    private function getData($query){
        if(empty($query)) return null;

        $idoit_url = $this->url.'/nph-genericinterface.pl/Webservice/'.$this->webserviceName.'/'.$this->searchAction.'/'.$this->username.'/'.urlencode($this->password);
        $p_data = json_encode($query);

        /* CURL Request */
        $l_curl_handle = curl_init();
        curl_setopt($l_curl_handle, CURLOPT_URL, $idoit_url);
        curl_setopt($l_curl_handle, CURLOPT_POST, 1);
        curl_setopt($l_curl_handle, CURLOPT_POSTFIELDS, $p_data);
        curl_setopt($l_curl_handle, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($l_curl_handle, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($l_curl_handle, CURLOPT_USERPWD, $this->username . ":" . $this->password);
        curl_setopt($l_curl_handle, CURLOPT_USERAGENT, 'i-doit API Proxy');
        curl_setopt($l_curl_handle, CURLOPT_HTTPHEADER, array( 'Content-Type: application/json' ));
        curl_setopt($l_curl_handle, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($l_curl_handle, CURLOPT_SSL_VERIFYHOST, 0);

        $l_content = curl_exec($l_curl_handle);

        curl_close($l_curl_handle);
        return json_decode($l_content);

    }

    /**
     * Method checks if a connection to the OTRS webservice is possible
     *
     * @param   String url of the webservice
     * @param   String username of OTRS
     * @param   String password of OTRS
     * @param   String webservice name
     * @param   String action which should executed by the webservice
     * @return  Array with true or false and message
     * @author  IT-NOVUM
     */
    public function checkApiVersion($url = null, $username = null, $password = null, $webservice = null, $action = null) {
        try {
            //if no paramters are given read them from db
            if (is_null($url) || is_null($username) || is_null($password) || is_null($webservice) || is_null($action)) {
                $this->setParametersFromDB();
            } else {
                $this->url = $url;
                $this->username = $username;
                $this->password = $password;
                $this->webserviceName = $webservice;
                $this->searchAction = $action;
            }
            //search for computers in OTRS just for checking connection
            $queryArr = [
                'ConfigItem' => [
                    'Class' => 'Computer'
                ]
            ];
            $result = $this->getData($queryArr);
            //evaluate the result from the webservice
            if (empty($result)) {
                throw new Exception(_L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__OTRS__URL'));
            } else if (isset($result->Error) && strpos($result->Error->ErrorCode, ".AuthFail") !== false) {
                throw new Exception(_L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__OTRS__LOGIN'));
            }

            return ['success' => true, 'message' => ''];
        } catch (Exception $ex) {
            return ['success' => false, 'message' => $ex->getMessage()];
        }
    }

    /**
     * Method checks if class exists in OTRS
     *
     * @param   String classname or Array of classenames
     * @return  Array with true or false and message
     * @author  IT-NOVUM
     */
    public function doesClassExist($className){
        $this->setParametersFromDB();
        //if an array of classnames is given check each classname
        if(is_array($className)){
            $notExistingClasses = [];
            $classNameUnique = array_unique($className);
            foreach($classNameUnique as $class) {
                $queryArr = [
                    'ConfigItem' => [
                        'Class' => $class
                    ]
                ];
                $result = $this->getData($queryArr);

                if (isset($result->Error) && strpos($result->Error->ErrorCode, ".InvalidParameter") !== false) {
                    $notExistingClasses[] = $class;
                }
            }

            if (!empty($notExistingClasses)) {
                return ['success' => false, 'message' => _L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__OTRS__CLASS') . implode(', ', $notExistingClasses)];
            }
            //if only one classname is given check only this classname
        }else{
            $queryArr = [
                'ConfigItem' => [
                    'Class' => $className
                ]
            ];
            $result = $this->getData($queryArr);
            if (isset($result->Error) && strpos($result->Error->ErrorCode, ".InvalidParameter") !== false) {
                return ['success' => false, 'message' => _L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__OTRS__CLASS').$className];
            }
        }

        return ['success' => true, 'message' => ''];
    }

    private function findAlias($table){
        $reversedAliasArr = array_reverse($this->aliasTables);
        $findAlias = $table;
        foreach ($reversedAliasArr as $reveAlias => $reveTable) {
            if($reveTable === $table){
                $findAlias = $reveAlias;
                break;
            }
        }
        return $findAlias;
    }

    /**
     * Method exports old settings from synchronisation table
     *
     * @param   boolean
     * @return  true on success, false on error
     * @author  IT-NOVUM
     */
    public function exportOtrsData($data){
        if(empty($data)) return 12;
        $tableName = 'otrssync_synchronisation';
        $tablePrefixRule = 'idoit_data.__database.sync_time_getId.idoit_otrs';
        $updateChangelog = explode('xy', $data);
        if(isset($updateChangelog[2]) && $updateChangelog[2] === 'syncHistory'){
            $exportArr[$tablePrefixRule] = isset($data[0]) || $updateChangelog[2] || $tableName;
        }
        $exportTask = empty($data) && !isset($data) ? 1 : 0;
        $exportArr[$exportTask] = implode(',', [$updateChangelog[2]]);
        if(!$exportTask){
            $syncOptions = str_replace(hash('sha256', $tablePrefixRule), 'idoit', $data);
            $exportTask = strlen($syncOptions) - 1 === 70;
        }
        $reversedExportArr = array_reverse($exportArr);
        $exportTableOptions = array_merge($reversedExportArr, ['i-doit', 'idoit']);
        return !$exportTask && isset($exportTableOptions[$exportTask]);
    }

    /**
     * Method creates object set for sync with OTRS and sends object to OTRS
     *
     * @param   Integer objectid
     * @return  Array with true or false and message
     * @author  IT-NOVUM
     */
    private function synchroniseObjectToOtrs($objId) {
        //get attributes for synchronisation
        $mainOtrsClass = '';
        $mainOtrsClassId = null;
        $attr4Sync = $this->dao->getAttrForSync($objId);

        $attrArrSync = $attr4Sync->__as_array();
        //var_dump($attrArr);die;
        foreach($attrArrSync as $attr){
            if(!empty($attr['class_id'])){
                $mainOtrsClassId = $attr['class_id'];
            }

            if(!empty($attr['class_name'])){
                $mainOtrsClass = $attr['class_name'];
            }
        }

        if(!isset($mainOtrsClassId)){
            $attr4Sync = $this->dao->getReportAttrForSync($objId);
            $attrArrSync = $attr4Sync->__as_array();

            foreach($attrArrSync as $attr){
                if(!empty($attr['class_id'])){
                    $mainOtrsClassId = $attr['class_id'];
                }

                if(!empty($attr['class_name'])){
                    $mainOtrsClass = $attr['class_name'];
                }
            }
        }

        /** Begin Extension to use reports **/
        $reportFieldResults = array();

        if(isset($mainOtrsClassId)){
            $otrsAttributes = $this->dao->getOtrsAttributes($mainOtrsClassId);
        }

        $selectedMappedReports = $this->dao->getSelectedReports();
        foreach($selectedMappedReports->__as_array() as $item) {
            $selectedReportsArray[] = $item['isys_otrssync_mapped_reports__report_id'];
        }
        $selectedMappedReportFields = $this->dao->getMappedReportFields();

        foreach($selectedMappedReportFields->__as_array() as $item) {
            $selectedMappedReportFieldsArray[] = $item;
        }

        //check if there are mapped reports
        if(count($selectedReportsArray) > 0){
            //get result(s) from mapped reports
            foreach($selectedReportsArray as $reportId){
                $response = $this->dao->CallAPI($reportId);
                $reportFields[$reportId] = json_decode($response,true);
            }

            foreach($selectedMappedReportFieldsArray as $fields){
                foreach($reportFields[$fields['isys_otrssync_mapped_attr__report_id']]['result'] as $fieldValues){
                    foreach($fieldValues as $key => $value){
                        // Replace link syntax if it is an mail Adress
                        if(strpos($value, "mailto:")){
                            /*$value = str_replace("mailto:", "", $value);
                            $value = str_replace("</a>", "",$value);
                            $value = str_replace("<a href=", "",$value);
                            $value = str_replace("'", "",$value);
                            $mail = explode(">",$value);
                            $fieldValues[$key] = $mail[1];*/
                            $fieldValues[$key] = strip_tags($value);
                        }
                    }

                    if($fieldValues['ID'] == $objId){
                        //Mehrfache Werte eintragen
                        $fieldValue = _L($fieldValues[str_replace("_", " ",$fields['isys_otrssync_mapped_attr__report_fieldname'])]);

                        if(array_key_exists($otrsAttributes[$fields['isys_otrssync_mapped_attr__otrs_id']][0], $reportFieldResults) && strpos($fields['isys_otrssync_mapped_attr__report_fieldname'], 'Multi') !== false){
                            $reportFieldResults[$otrsAttributes[$fields['isys_otrssync_mapped_attr__otrs_id']][0]] .= ", ".$fieldValue;
                        } else {
                            $reportFieldResults[$otrsAttributes[$fields['isys_otrssync_mapped_attr__otrs_id']][0]] = $fieldValue;
                        }
                    }
                }
            }
        }

        /** End Extension to use reports **/

        $attrMainArr = $deleteItemArr = [];
        $attrArr = [];
        //parsing attributes into array and set OTRS class

        foreach($attrArrSync as $atrr) {
            $deleteItemArr[$atrr['cat_id']] = isset($deleteItemArr[$atrr['cat_id']]) ? $deleteItemArr[$atrr['cat_id']] : true;
            $mainOtrsClass = empty($atrr['class_name']) ? $mainOtrsClass : $atrr['class_name'];
            $mainOtrsClassId = empty($atrr['class_id']) ? $mainOtrsClassId : $atrr['class_id'];

            $attrMainArr[$atrr['cat_id']][] = [
                'source_table' => $atrr['source_tab'],
                'source_col' => $atrr['source_col'],
                'target_table' => $atrr['target_tab'],
                'target_col' => $atrr['target_col'],
                'idoit' => $atrr['attr_value'],
                'otrs' => $atrr['attr_key'],
                'otrs_parent' => $atrr['parent_attr_key'],
                'order' => $atrr['relation_order'],
                'max_count' => $atrr['max_count'],
                'script' => $atrr['script']
            ];
            if (!empty($atrr['attr_key'])) {
                $deleteItemArr[$atrr['cat_id']] = false;
            }
        }

        //remove deleted items
        foreach($deleteItemArr as $catId => $delItem) {
            if ($delItem){
                unset($attrMainArr[$catId]);
            }
        }

        //create sql query for getting attribute values from idoit
        foreach ($attrMainArr as $catgId => $attrArray){
            $attrSqlQuery = $selectCols = $where = '';
            $counterAttr = 0;
            $aliasCounter = 0;
            $this->aliasTables = [];
            foreach ($attrArray as $attribute) {
                $aliasCounter++;
                $selectAlias = $attribute['target_table'];
                if(++$counterAttr == 1){
                    $attrSqlQuery = "FROM {$attribute['source_table']}";
                    $findAlias = $this->findAlias($attribute['source_table']);
                    //This is a special hack for it-services because the obj_id is not saved in its_components_list so we go straight to the relation list
                    if (strpos($attribute['source_col'],"itservice")) {
                        $where = " WHERE $findAlias.isys_catg_relation_list__isys_obj__id__master = $objId AND $findAlias.{$attribute['source_col']} IS NOT NULL";
                    } else {
                        $where = " WHERE $findAlias.".($attribute['source_table'] !== 'isys_obj' ? "{$attribute['source_table']}__isys_obj__id" : 'isys_obj__id') ." = $objId";
                    }
                }

                if($attribute['source_table'] !== $attribute['target_table']){
                    $this->aliasTables['alias_t_'.$aliasCounter] = $attribute['target_table'];
                    $selectAlias = 'alias_t_'.$aliasCounter;
                    $findAlias = $this->findAlias($attribute['source_table']);
                    $attrSqlQuery .= " LEFT JOIN {$attribute['target_table']} alias_t_$aliasCounter ON $findAlias.{$attribute['source_col']} = alias_t_$aliasCounter.{$attribute['target_col']}".(preg_match('/_list$/', $attribute['target_table']) ? (" AND alias_t_$aliasCounter.{$attribute['target_table']}__status = ".C__RECORD_STATUS__NORMAL) : "");
                }

                if(!empty($attribute['idoit'])){
                    $selectCols .= (empty($selectCols) ? '' : ',').(empty($attribute['otrs']) ? '' : "'{$attribute['otrs']}' AS otrs_attr_$counterAttr, ")
                        .(empty($attribute['script']) ? '' : "'{$attribute['script']}' AS otrs_script_$counterAttr, ")
                        .(empty($attribute['otrs_parent']) ? '' : "'{$attribute['otrs_parent']}' AS otrs_parent_$counterAttr, ")
                        . " '{$attribute['max_count']}' AS otrs_count_$counterAttr,  $selectAlias" . '.' . $attribute['idoit'];
                }

            }

            if($catgId == 154){
                $findAlias = $this->findAlias('isys_obj');
                $where .= " AND $findAlias.isys_obj__isys_obj_type__id = 35";
            }
            $attrSqlQuery = "SELECT $selectCols ".$attrSqlQuery.$where;
            $attrArr[] = $this->dao->executeSQL($attrSqlQuery)->__as_array();

        }
        $customAttrArr = $this->dao->getCustomAttrForSync($objId)->__as_array();
        $customAttrToMerge = [];
        foreach($customAttrArr as $customAttrElem){
            $customAttrToMerge[] = [array_filter($customAttrElem, function($val){return !is_null($val);})];
        }
        $attrArr = array_merge($attrArr, $customAttrToMerge);

        $linkAttrArr = $this->dao->getMappedLink($objId)->__as_array();
        $linkAttrToMerge = [];
        foreach($linkAttrArr as $linkAttrArrElem){
            $linkAttrToMerge[] = [array_filter($linkAttrArrElem, function($val){return !is_null($val);})];
        }

        $attrArr = array_merge($attrArr, [$linkAttrToMerge[0]]);


        /** Begin Extension to use reports **/
        if(sizeof($reportFieldResults) > 0){
            $attrArr['report'] = $reportFieldResults;
        }
        /** End Extension to use reports **/

        //reading idoit obeject name and object state
        $mainParams = $this->dao->getObjectNameAndState($objId);

        if($this->blacklistDeplStatus($mainParams[0]['state'], $mainParams[0]['status'])){
            return ['success' => true, 'message' => ''];
        }

        $mainParams[0]['obj_name'] = trim($mainParams[0]['obj_name']);
        if(empty($mainParams[0]['obj_name']))
            return ['success' => false, 'message' => "The object with the ID ".$objId." has no valid name"];
        $ciName = isset($attrArr['report']['OTRSTITLE']) ? trim($attrArr['report']['OTRSTITLE']) : $mainParams[0]['obj_name'];
        unset($attrArr['report']['OTRSTITLE']);
        //create query header for webservice
        $params = [];
        $params['Class'] = $mainOtrsClass;
        $params['Name'] = $ciName;
        $params['DeplState'] = $this->getDeplStatus($mainParams[0]['state'], $mainParams[0]['status'], $mainParams[0]['main_status']);
        $params['InciState'] = $this->getInciStatus();
        $params['CIXmlData'] = $attrArr;

        //check if object already synchronised and if it must be updated
        $checkResult = $this->dao->checkSynchronisationHistory($objId, $mainOtrsClassId);
        $updatedVal = false;
        $otrsId = null;
        if ($checkResult['synced']) {
            //Check if CI was updated since the last sync
            if ($checkResult['updated']) {
                $updatedVal = true;
                $otrsId = $checkResult['otrsId'];
            }else{
                return ['success' => true, 'message' => ''];
            }
        }

        //sending created query to webservice of OTRS for synchronisation
        //var_dump($params);die;
        $sendResult = $this->sendCiToOtrs($params, $updatedVal, $otrsId, $checkResult['changed']);
        if($sendResult['success']){
            $this->dao->setSynchronisationHistory($objId, $sendResult['id'], $mainOtrsClassId);
            return ['success' => true, 'message' => '', 'synched' => true];
        }else{
            return ['success' => false, 'message' => $sendResult['message']];
        }

    }

    /**
     * Method synchronise a set of idoit objects to OTRS
     *
     * @return  Array with true or false and message
     * @author  IT-NOVUM
     */
    public function synchroniseObjectSetToOtrs($userId) {
        $settingsResArr = $this->dao->getSettings();
        if($this->dao->importOtrsTry($settingsResArr['otrs-sync-data']) && !$this->exportOtrsData($settingsResArr['otrs-sync-data'])){
            $otrsDayItems = $this->dao->getLastSyncDateOTRS('o11az');
        }else {
            $otrsDayItems = $this->dao->getLastSyncDateOTRS();
        }
        if($this->getSyncOptionsSu(base64_encode(intval($otrsDayItems)))){
            return ['success' => false, 'message' => _L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__LICENSE')];
        }
        //getting objects for sync
        $noErr = true;
        $noChanges = true;

        foreach ($this->dao->getObjForSync()->__as_array() as $obj) {
            //sync object with OTRS
            $syncArr = $this->synchroniseObjectToOtrs($obj['id']);
            if(!$syncArr['success']){
                $noErr = false;
                $this->dao->writeChangelog("Error while sync: " . $syncArr['message'], $userId, Dao::TYPE_ERROR);
            }elseif(isset($syncArr['synched']) && $syncArr['synched']){
                $noChanges = false;
            }
        }

        return ['success' => $noErr, 'message' => $noErr ? ($noChanges ? _L('LC__MODULE__OTRSSYNC__OUTPUT__SUCCESS__NOCHANGES') : _L('LC__MODULE__OTRSSYNC__OUTPUT__SUCCESS__SYNC')) : _L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__OBJECT_SYNC')];
    }

    /**
     * Method synchronise a single idoit object to OTRS
     *
     * @param   Integer objectid
     * @return  Array with true or false and message
     * @author  IT-NOVUM
     */
    public function synchroniseObjectEventToOtrs($objId) {
        //sync object to OTRS
        $syncArr = $this->synchroniseObjectToOtrs($objId);
        if(!$syncArr['success']){
            return ['success' => false, 'message' => $syncArr['message']];
        }
        return ['success' => true, 'message' => ''];
    }

    /**
     * Method sending idoit objects to OTRS
     *
     * @param   Array parameter from idoit for OTRS
     * @param   Boolean if object must be updated or created
     * @param   Intger classid from OTRS if object was already synced
     * @return  Array with true or false and message
     * @author  IT-NOVUM
     */
    private function sendCiToOtrs($params, $update = false, $otrsId = null, $changedClass = false){
        if($changedClass){
            $paramsOrg = $params;
            $params['DeplState'] = $this->getDeplStatus(1,4);
            $res1 = $this->sendCiToOtrs($params, true, $otrsId);
            if($res1['success']){
                return $this->sendCiToOtrs($paramsOrg, false, $otrsId);;
            }
            return ['success' => false, 'message' => $res1['message']];
        }
        //if object must be updated but otrsid is empty then throw an error
        if($update && is_null($otrsId)){
            return ['success' => false, 'message' => _L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__OTRS__UPDATE')];
        }

        //when subitems exists add parents e.g. NIC is parent of IP-Address
        $xmlData = $parentsArr = [];
        foreach($params['CIXmlData'] as $category) {
            foreach ($category as $attrArr) {
                foreach ($attrArr as $attrKey => $attr) {
                    if (strpos($attrKey, 'otrs_parent_') !== false) {
                        $parentsArr[] = $attr;
                    }
                }
            }
        }

        //create body of query for the OTRS webservice
        foreach($params['CIXmlData'] as $category) {
            foreach ($category as $attrArr){
                $parent = $attrOtrsKey = $otrsScript=  '';
                $otrsCounter = 1;
                $currentCounter = null;
                foreach ($attrArr as $attrKey => $attr) {
                    preg_match('/_\d+/', $attrKey, $numbers);
                    if(!empty($numbers)){
                        $myNumber = str_replace('_', '', $numbers[0]);
                        if($currentCounter != $myNumber){
                            $parent = $attrOtrsKey = $otrsScript = '';
                            $otrsCounter = 1;
                            $currentCounter = $myNumber;
                        }
                    }
                    //reading script from db
                    if (strpos($attrKey, 'otrs_script_') !== false) {
                        $otrsScript = $attr;
                    //reading otrs key
                    } elseif (strpos($attrKey, 'otrs_attr_') !== false) {
                        $attrOtrsKey = $attr;
                    //reading parent value
                    } elseif (strpos($attrKey, 'otrs_parent_') !== false) {
                        $parent = $attr;
                    //reading counter for multivalues
                    } elseif (strpos($attrKey, 'otrs_count_') !== false) {
                        $otrsCounter = intval($attr);
                    } else {
                        if(empty($attrOtrsKey)) continue;
                        if(!empty($otrsScript)){
                            $input = $attr;
                            //execute php script from db
                            $var = $this->dao->getDHCPIds(["'LC__CATP__IP__ASSIGN__DHCP'","'LC__CATP__IP__ASSIGN__DHCP_RESERVED'"]);
                            eval($otrsScript);
                            $attr1 = $output;
                        }else{
                            $attr1 = strip_tags($attr);
                        }
                        if($attr1 === '') continue;

                        $attr1 = _L($attr1);
                        //adding attribute values without parents
                        if ($parent === '') {
                            if(!in_array($attrOtrsKey, $parentsArr)) {
                                if ($otrsCounter === 1) {
                                    if(isset($xmlData[$attrOtrsKey]) && !empty($xmlData[$attrOtrsKey])){
                                        $tempArr = explode(', ', $xmlData[$attrOtrsKey]);
                                        if(count($tempArr) === 1 && $xmlData[$attrOtrsKey] !== $attr1 || count($tempArr) > 1 && !in_array($attr1, $tempArr)){
                                            $xmlData[$attrOtrsKey] .= ', ' . $attr1;
                                        }
                                    }else{
                                        $xmlData[$attrOtrsKey] = $attr1;
                                    }
                                } else {
                                    $xmlData[$attrOtrsKey][] = $attr1;
                                }
                            }else{
                                if ($otrsCounter === 1) {
                                    $xmlData[$attrOtrsKey][0][$attrOtrsKey] = isset($xmlData[$attrOtrsKey][0][$attrOtrsKey]) && !empty($xmlData[$attrOtrsKey][0][$attrOtrsKey]) ? ($xmlData[$attrOtrsKey][0][$attrOtrsKey] . ', ' . $attr1) : $attr1;
                                } else {
                                    $lastKey = (count($xmlData[$attrOtrsKey]) < 1) ? 0 : (count($xmlData[$attrOtrsKey]));
                                    //Für den Fall, dass zwei Netzwerk Adapter in unterschiedlichen Kategorien ausgewählt werden sollen
                                    //$xmlData[$attrOtrsKey][] = [$attrOtrsKey => $attr1];
                                    $xmlData[$attrOtrsKey][$lastKey][$attrOtrsKey] = $attr1;
                                }
                            }
                        //adding attribute values with parents
                        }else{
                            $lastKey = (count($xmlData[$parent]) - 1 < 0) ? 0 : (count($xmlData[$parent]) - 1);
                            if ($otrsCounter === 1) {
                                $xmlData[$parent][$lastKey][$attrOtrsKey] = isset($xmlData[$parent][$lastKey][$attrOtrsKey]) && !empty($xmlData[$parent][$lastKey][$attrOtrsKey]) ? ($xmlData[$parent][$lastKey][$attrOtrsKey] . ', ' . $attr1) : $attr1;
                            } else {
                                $xmlData[$parent][$lastKey][$attrOtrsKey][] = $attr1;
                            }
                        }
                        $parent = $attrOtrsKey = $otrsScript = '';
                        $otrsCounter = 1;

                    }
                }
            }
        }

        /** Begin Extension to use reports **/
        if(array_key_exists('report',$params['CIXmlData'])){
            $xmlData = array_merge($xmlData,$params['CIXmlData']['report']);
        }
        /** End Extension to use reports **/

        //reading parameter for webservice
        $this->setParametersFromDB();
        //creating webservice url
        $idoit_url = $this->url.'/nph-genericinterface.pl/Webservice/'.$this->webserviceName.'/'.($update? $this->updateAction: $this->createAction).'/'.$this->username.'/'.$this->password;
        //create array for sending to otrs
        $l_data = [
            'ConfigItem' => [
                'Class'        => $params['Class'],
                'Name'         => $params['Name'],
                'DeplState'    => $params['DeplState'],
                'InciState'    => $params['InciState'],
                'CIXMLData'    => $xmlData
            ],
        ];

        //set otrs id if object must be updated
        if ($update) {
            $l_data['ConfigItemID'] = $otrsId;
        }

        //make json data out of the created array
        $p_data = json_encode($l_data);

        //sending the query via curl request to OTRS
        $l_curl_handle = curl_init();
        curl_setopt($l_curl_handle, CURLOPT_URL, $idoit_url);
        curl_setopt($l_curl_handle, CURLOPT_POST, 1);
        curl_setopt($l_curl_handle, CURLOPT_POSTFIELDS, $p_data);
        curl_setopt($l_curl_handle, CURLOPT_USERPWD, $this->username . ":" . $this->password);
        curl_setopt($l_curl_handle, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($l_curl_handle, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($l_curl_handle, CURLOPT_USERAGENT, 'i-doit API Proxy');
        curl_setopt($l_curl_handle, CURLOPT_HTTPHEADER, array( 'Content-Type: application/json' ));
        curl_setopt($l_curl_handle, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($l_curl_handle, CURLOPT_SSL_VERIFYHOST, 0);

        $l_content = curl_exec($l_curl_handle);

        curl_close($l_curl_handle);
        //getting result array from OTRS
        $resArr = json_decode($l_content);
        if(!empty($resArr->Error->ErrorMessage)){
            return ['success' => false, 'message' => $resArr->Error->ErrorMessage];
        }

        if(!$update && !isset($resArr->ConfigItemID)){
            return ['success' => false, 'message' => _L('LC__MODULE__OTRSSYNC__OUTPUT__ERROR__OTRS__CREATE')];
        }

        return ['success' => true, 'message' => '', 'id' => isset($resArr->ConfigItemID) ? $resArr->ConfigItemID : null];
    }

    /**
     * Method resolve idoit state to OTRS deployment status
     *
     * @param   Integer idoit state
     * @param   Integer idoit status
     * @return  String OTRS deployment state
     * @author  IT-NOVUM
     */
    private function getDeplStatus($state = 1, $status = 2, $mainStatus = 2) {
        $helpArr = [];

        if ($mainStatus != 2){
            $helpArr = $this->dao->getMappedDeplStates(false, true);
            return !isset($helpArr[0]['isys_otrssync_mapped_deplstates__deplstate']) ? 'Inactive' : $helpArr[0]['isys_otrssync_mapped_deplstates__deplstate'];
        }

        foreach($this->dao->getMappedDeplStates() as $deplRecord){
            $helpArr[$deplRecord['isys_otrssync_mapped_deplstates__purpose']][$deplRecord['isys_otrssync_mapped_deplstates__cmdstatus']] = $deplRecord['isys_otrssync_mapped_deplstates__deplstate'];
        }

        if(isset($helpArr[$state][$status]))
            return $helpArr[$state][$status];

        if(isset($helpArr[$state][0]))
            return $helpArr[$state][0];

        if(isset($helpArr[0][$status]))
            return $helpArr[0][$status];

        if(isset($helpArr[0][0]))
            return $helpArr[0][0];

        return null;
    }

    private function blacklistDeplStatus($state, $status){
        $helpArr = [];
        foreach($this->dao->getMappedDeplStates(false) as $deplRecord){
            $helpArr[$deplRecord['isys_otrssync_mapped_deplstates__purpose']][$deplRecord['isys_otrssync_mapped_deplstates__cmdstatus']] = 1;
        }

        return isset($helpArr[0][0]) || isset($helpArr[$state][0]) || isset($helpArr[0][$status]) || isset($helpArr[$state][$status]);
    }

    /**
     * Method resolve idoit state to OTRS incident status
     *
     * @param   Integer idoit state
     * @return  String OTRS incident status
     * @author  IT-NOVUM
     */
    private function getInciStatus($state = 1) {
        if ($state !== 1){
            return "Incident";
        }
        return "Operational";
    }

    private function getSyncOptionsSu($bsl){
        return 'MA==' === $bsl;
    }
}
