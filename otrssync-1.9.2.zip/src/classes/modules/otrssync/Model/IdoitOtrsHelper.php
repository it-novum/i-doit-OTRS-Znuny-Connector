<?php
namespace idoit\Module\Otrssync\Model;
use idoit\Exception\Exception;

/**
 * i-doit OTRSSYNC IdoitOtrsHelper
 *
 * @package     Modules
 * @subpackage  OTRSSYNC\Model
 * @author      IT-Novum
 * @copyright   IT-Novum GmbH
 */

class IdoitOtrsHelper {

    private $mailer;

    /**
     * Constructor which initiates the phpmailer
     *
     * @param   Object with phpmailer
     * @author  IT-NOVUM
     */
    public function __construct($mailer){
        $this->mailer = $mailer;
    }

    /**
     * Method parses OTRS classdefinition for attributes
     *
     * @param   String OTRS classdefition
     * @throws  Exception
     * @return  array with parsed attributes
     * @author  IT-NOVUM
     */
    public function parseDefinition($definition){
        $resultArray = array();
        if(empty($definition)){
            return $resultArray;
        }

        $definition = str_replace("---", "", $definition);
        $definition = str_replace(" - ", "++", $definition);
        $definitionArray = explode("- ", $definition);

        foreach($definitionArray as $defBlock){
            $defBlock = str_replace("Key: ", "", $defBlock);
            $namePos = strpos($defBlock, "Name: ");
            $inputPos = strpos($defBlock, "Input:");
            $subPos = strpos($defBlock, "Sub:");
            $maxCountPos = strpos($defBlock, "CountMax: ");
            $fieldKey =  str_replace(["\r", "\n", " "], "",substr($defBlock,0, $namePos));
            $fieldName = str_replace(["Name: ", "\r", "\n", "Input:", "Searchable: 1", " "], "", substr($defBlock, $namePos, $inputPos - $namePos));
            $fieldMaxCount = 1;
            if($maxCountPos !== false){
                $fieldMaxCount = substr($defBlock, $maxCountPos, 12);
                $fieldMaxCount = str_replace(["CountMax: ", "\r", "\n", " "], "", $fieldMaxCount);
            }
            $subArray = [];
            if($subPos !== false) {
                $fieldSubField = substr($defBlock, $subPos);
                $subFieldArray = explode("++", $fieldSubField);
                foreach($subFieldArray as $subField) {
                    if (strpos($subField, "Sub:") === false) {
                        $namePos = strpos($subField, "Name: ");
                        $inputPos = strpos($subField, "Input:");
                        $maxCountPos = strpos($subField, "CountMax: ");
                        $subFieldKey = str_replace(["\r", "\n", " "], "", substr($subField, 0, $namePos));
                        $subFieldName = str_replace(["Name: ", "\r", "\n", "Input:", "Searchable: 1", " "], "", substr($subField, $namePos, $inputPos - $namePos));
                        $subFieldMaxCount = 1;
                        if ($maxCountPos !== false) {
                            $subFieldMaxCount = substr($subField, $maxCountPos, 12);
                            $subFieldMaxCount = str_replace(["CountMax: ", "\r", "\n", " "], "", $subFieldMaxCount);
                        }
                        $subArray[] = [
                            'Key' => $subFieldKey,
                            'Name' => $subFieldName,
                            'CountMax' => $subFieldMaxCount,
                        ];
                    }
                }
            }

            if($fieldKey !== "" && $fieldName !== ""){
                $resultArray[] = [
                    'Key' => $fieldKey,
                    'Name' => $fieldName,
                    'CountMax' => $fieldMaxCount,
                    'Sub' => $subArray
                ];
            }

        }

        return $resultArray;

        /*die();
        //Replace chars which are not allowed
        $formatedD = str_replace(["{", "}"], ["[", "]"], $definition);
        $arrayedD = preg_replace('/([a-zA-Z0-9]+) =>/', "'$1' =>", $formatedD);
        $clearedFromComments = preg_replace("/#.*\\\n/", '', $arrayedD);
        try {
            //Put parsed definition in a php file
            $fp = fopen('otrs_tmp.php', "w");
            fwrite($fp, '<?php return ' . $clearedFromComments . ' ?>');
            fclose($fp);
            if(stripos(shell_exec('php -l otrs_tmp.php'), 'no syntax error') === false)
                throw new Exception('');
            //include the php file with the definition as an php array
            $arrayPHP = include 'otrs_tmp.php';
            unlink('otrs_tmp.php');
            if (!is_array($arrayPHP))
                throw new Exception('');


            error_log(print_r($arrayPHP, TRUE));
            return $arrayPHP;
        }catch(Exception $ee){
            return false;
        }
*/
    }

    /**
     * Method return the translationkey for the sync intervall
     *
     * @param   String intervall key
     * @return  String translationkey for intervall
     * @author  IT-NOVUM
     */
    public function resolveSyncIntervall($key){
        switch ($key){
            case 'day':
                return _L("LC__MODULE__OTRSSYNC__OUTPUT__SYNC__DAY");
            case '10':
                return _L("LC__MODULE__OTRSSYNC__OUTPUT__SYNC__TEN");
            case '15':
                return _L("LC__MODULE__OTRSSYNC__OUTPUT__SYNC__FIFTEEN");
            case '30':
                return _L("LC__MODULE__OTRSSYNC__OUTPUT__SYNC__THIRTY");
            case '60':
                return _L("LC__MODULE__OTRSSYNC__OUTPUT__SYNC__SIXTY");
            default:
                return _L("LC__MODULE__OTRSSYNC__OUTPUT__SYNC__NONE");
        }
    }

    /**
     * Method sends an email to a given contact with the given subject and content
     *
     * @param   Array of contacts
     * @param   String subject
     * @param   String content body
     * @throws  Exception
     * @author  IT-NOVUM
     */
    public function send_email($p_contacts, $p_subject, $p_body)
    {
        try
        {
            $this->mailer->SMTPDebug = 0;
            $this->mailer->set_charset('UTF-8');
            $this->mailer->set_content_type('text/plain');
            $this->mailer->set_backend('smtp');
            $p_contacts = explode(",", $p_contacts);
            foreach ($p_contacts as $l_contact)
            {
                $this->mailer->AddAddress($l_contact);
            } //foreach contact

            // Max. line length:
            $l_lengths = array_map('strlen', explode(PHP_EOL, $p_body));
            sort($l_lengths, SORT_NUMERIC);
            $l_max_length       = end($l_lengths);
            $this->mailer->WordWrap = $l_max_length;

            // Fetch subject prefix that's already set in mailer and append our
            // subject:
            $l_subject = $this->mailer->get_subject() . $p_subject;
            $this->mailer->set_subject($l_subject);

            $this->mailer->set_body($p_body);
            $this->mailer->add_default_signature();

            if ($this->mailer->send()) {
                return true;
            } else {
                return false;
            }
        }
        catch (Exception $e)
        {
            throw new Exception($e->getMessage());
        }
    }

    /**
     * Method creates cronjobs for autosync with otrs and cleaning changelog
     *
     * @param   String action for changelog or autosync
     * @param   String intervall
     * @param   String delete true or false
     * @author  IT-NOVUM
     */
    public function createCronJob($action, $intervall, $delete){
        global $g_config;
        $database = $GLOBALS['g_comp_database']->get_db_name();

        //check if cronjob for changelog or synchronisation musst be created
        if ($action === "changelog"){
            $needle = "isys_module_otrssync_sync.php delete ".$database;
        } else {
            $needle = "isys_module_otrssync_sync.php synchronise ".$database;
        }

        $rows = array();
        $cronJob = "";
        $result = "";
        //Reading excisting cronjobs and save all excluding the the cronjob what should be created
        exec('crontab -l', $rows);
        if (count($rows) > 0) {
            foreach($rows as $row) {
                if (strpos($row, $needle) === false) {
                    $result = $row.PHP_EOL;
                }
            }
        }

        //create an empty file
        $file = __DIR__.DS.'PHP_CRONTAB';
        $handle = fopen($file, 'w');

        fwrite($handle, $cronJob);
        fclose($handle);
        //deleting crontab with all cronjobs
        exec("crontab $file");

        $handle = fopen($file, 'w');
        fwrite($handle, $result);
        //check if cronjob should be deleted, if it should be deleted don't recreate it else create it
        if ($delete === false) {
            fwrite($handle, $this->getTimeIntervallCronjob($intervall)." /usr/bin/php -f ".$g_config['base_dir']."src/classes/modules/otrssync/".$needle." &> /dev/null".PHP_EOL);
        }

        fclose($handle);
        //put cronjobs into crontab
        exec("crontab $file");
        unlink($file);
    }

    /**
     * Method translate human readable intervall into cronjob intervall
     *
     * @param   String human readable intervall
     * @return  String cronjob intervall
     * @author  IT-NOVUM
     */
    private function getTimeIntervallCronjob($intervall){
        switch($intervall){
            case 'day':
                return "0 0 * * *";
            case 'month':
                return "0 0 1 * *";
            case 'year':
                return "0 0 1 12 *";
            case 'week':
                return "0 0 * * 1";
            case '10':
                return "*/10 * * * *";
            case '15':
                return "*/15 * * * *";
            case '30':
                return "*/30 * * * *";
            case '60':
                return "0 */1 * * *";
            default:
                return "";
        }
    }
}
